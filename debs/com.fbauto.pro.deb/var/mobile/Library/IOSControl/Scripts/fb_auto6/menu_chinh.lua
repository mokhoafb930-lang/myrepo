-- ================================================================
-- FILE: menu_chinh.lua - CHẠY TỔNG HỢP + MENU CHÍNH (Đầy đủ 100% parity)
-- ================================================================

-- ========== HÀM TRỢ GIÚP XEM FILE ==========
function xemNoiDungFile(path, title)
    local f = io.open(path, "r")
    if not f then toast("⚠️ File không tồn tại!") return end
    local lines = {}
    local count = 0
    for line in f:lines() do
        count = count + 1
        if count <= 20 then table.insert(lines, line) end
    end
    f:close()

    local content = table.concat(lines, "\n")
    if count > 20 then content = content .. "\n... và " .. (count - 20) .. " UID khác" end
    if content == "" then content = "(File trống)" end

    dialogChoice(title .. "\n\n" .. content, "Đóng ❌")
end

-- ========== CHẠY TỔNG HỢP RUNNER ==========
function chayTongHopRunner()
    _G.DANG_CHAY_LIEN_HOAN = true
    local danhSachNick = layDanhSachCrane()
    local totalNicks = math.min(#danhSachNick, LH_SO_NICK or 1)
    if totalNicks == 0 then
        _G.DANG_CHAY_LIEN_HOAN = false
        toast("⚠️ Không có phân vùng Crane nào!")
        return
    end

    logScreen("🚀 BẮT ĐẦU CHẠY TỔNG HỢP CHO " .. totalNicks .. " NICK", true)
    local original_BAT_DAU = NICK_BAT_DAU

    for lan = 1, totalNicks do
        _G.DA_RESET_MANG = false
        _G.CO_LOI_SOMETHING = false
        local offset = (original_BAT_DAU > 0) and (original_BAT_DAU - 1) or 0
        local idx_in_list = ((lan - 1 + offset) % #danhSachNick) + 1
        local hien_thi_stt = ((lan - 1 + offset) % #danhSachNick) + 1 -- Hiển thị 1, 2, 3...
        local tenPhanVung = danhSachNick[idx_in_list]

        log("")
        logScreen("🔄 [NICK " .. lan .. "/" .. totalNicks .. "] BẮT ĐẦU CHUỖI TÁC VỤ", true)
        log("📂 Phân vùng: " .. tenPhanVung .. " (STT: " .. hien_thi_stt .. ")")

        resetMang()
        chuyenNick(tenPhanVung)

        local breakDueToError = false
        _G.CO_LOI_SOMETHING = false -- Reset lỗi cho Nick mới
        _G.DA_CHECK_LOGIN = false   -- Reset ghi nhớ check login cho Nick mới

        -- Run Farm if enabled
        if BAT_LH_FARM == 1 then
            logScreen("🚜 Chạy Farm cho Nick STT " .. hien_thi_stt, true)
            local old_LAP = SO_LAN_LAP
            NICK_BAT_DAU = hien_thi_stt
            SO_LAN_LAP = 1
            thucHienFarm()
            SO_LAN_LAP = old_LAP
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook() -- Đảm bảo đóng sau farm
        end

        -- Run Ket ban UID if enabled
        if not breakDueToError and BAT_LH_KBUID == 1 then
            logScreen("👤 Chạy Kết bạn UID cho Nick STT " .. hien_thi_stt, true)
            local old_NICK_UID = SO_NICK_UID
            NICK_BAT_DAU = hien_thi_stt
            SO_NICK_UID = 1
            thucHienKetBanUID()
            SO_NICK_UID = old_NICK_UID
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end
        if not breakDueToError and BAT_LH_KBGY == 1 then
            logScreen("👥 Chạy Kết bạn gợi ý cho Nick STT " .. hien_thi_stt, true)
            local old_KB_GY = SO_NICK_KB_GY
            NICK_BAT_DAU = hien_thi_stt
            SO_NICK_KB_GY = 1
            thucHienKetBanGoiY()
            SO_NICK_KB_GY = old_KB_GY
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run Chap nhan ket ban if enabled
        if not breakDueToError and BAT_LH_CNKB == 1 then
            logScreen("🤝 Chạy Chấp nhận kết bạn cho Nick STT " .. hien_thi_stt, true)
            local old_CNKB = SO_NICK_CNKB
            NICK_BAT_DAU = hien_thi_stt
            SO_NICK_CNKB = 1
            thucHienChapNhanKetBan()
            SO_NICK_CNKB = old_CNKB
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run CMT if enabled
        if not breakDueToError and BAT_LH_CMT == 1 then
            logScreen("💬 Chạy CMT bài viết cho Nick STT " .. hien_thi_stt, true)
            local old_CMT = CMT_SO_NICK
            NICK_BAT_DAU = hien_thi_stt
            CMT_SO_NICK = 1
            thucHienCMTBaiViet()
            CMT_SO_NICK = old_CMT
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run Share if enabled
        if not breakDueToError and BAT_LH_SHARE == 1 then
            logScreen("🚀 Chạy Share bài viết cho Nick STT " .. hien_thi_stt, true)
            local old_SHARE = SHARE_SO_NICK
            NICK_BAT_DAU = hien_thi_stt
            SHARE_SO_NICK = 1
            thucHienShareBaiViet()
            SHARE_SO_NICK = old_SHARE
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run Tương tác if enabled
        if not breakDueToError and BAT_LH_INTERACT == 1 then
            logScreen("🎯 Chạy Tương tác bài viết cho Nick STT " .. hien_thi_stt, true)
            local old_INTERACT = INTERACT_NICKS
            NICK_BAT_DAU = hien_thi_stt
            INTERACT_NICKS = 1
            thucHienInteractPost()
            INTERACT_NICKS = old_INTERACT
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run Tham gia nhóm if enabled
        if not breakDueToError and BAT_LH_JOIN_GROUP == 1 then
            logScreen("🌐 Tham gia nhóm cho Nick STT " .. hien_thi_stt, true)
            NICK_BAT_DAU = hien_thi_stt
            thucHienJoinGroup("LH")
            if _G.CO_LOI_SOMETHING then breakDueToError = true end
            dongFacebook()
        end

        -- Run Luot Like if enabled
        if not breakDueToError and BAT_LH_LUOT_LIKE == 1 then
            logScreen("👍 Lướt Newsfeed Like cho Nick STT " .. hien_thi_stt, true)
            dongFacebook() 
            if not moFacebook() then
                log("❌ Không mở được FB để lướt Like")
            else
                luotNewsfeedCoLike(LH_NF_LIKE_SO_BAI, LH_NF_LIKE_SO_LIKE, LH_NF_LIKE_NGHI)
                dongFacebook() 
            end
        end

        -- Đảm bảo đóng FB cuối cùng (nếu còn sót)
        dongFacebook()

        if breakDueToError then
            logScreen("❌ Đã xảy ra lỗi Something! Dừng chuỗi tác vụ cho Nick này.", true)
        else
            logScreen("✅ Hoàn thành chuỗi tác vụ cho nick STT " .. hien_thi_stt, true)
        end

        if lan < totalNicks then
            nghi(THOI_GIAN_NGHI, "Nghỉ giải lao giữa các Nick")
        end
    end

    NICK_BAT_DAU = original_BAT_DAU
    _G.DANG_CHAY_LIEN_HOAN = false
    logScreen("🎉 HOÀN TẤT TẤT CẢ CÁC NICK TRONG CHẠY TỔNG HỢP", true)
end

-- ========== MENU CHẠY TỔNG HỢP (Chi tiết menu con) ==========
function menuChayTongHop()
    while true do
        local title = "🔄 CHẠY TỔNG HỢP\n"
            .. "Chọn các chức năng muốn chạy:"

        local choice = dialogChoice(title,
            "1. Nuôi nick (Farm): " .. (BAT_LH_FARM == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "2. Kết bạn UID: " .. (BAT_LH_KBUID == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "3. Kết bạn gợi ý: " .. (BAT_LH_KBGY == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "4. Chấp nhận KB: " .. (BAT_LH_CNKB == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "5. Comment bài viết: " .. (BAT_LH_CMT == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "6. Share bài viết: " .. (BAT_LH_SHARE == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "7. Tương tác bài viết: " .. (BAT_LH_INTERACT == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "8. Tham gia nhóm: " .. (BAT_LH_JOIN_GROUP == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "9. Lướt Newsfeed có Like: " .. (BAT_LH_LUOT_LIKE == 1 and "BẬT 🟢" or "TẮT ⚪") .. " ->",
            "───────────────────────────",
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU .. " (STT)",
            "🔢 Số nick chạy: " .. LH_SO_NICK .. " nick",
            "⏳ Thời gian nghỉ: " .. THOI_GIAN_NGHI .. " giây",
            "───────────────────────────",
            "🚀 BẮT ĐẦU CHẠY TỔNG HỢP",
            "◀️ Quay lại"
        )

        if not choice or choice:find("Quay lại") then
            break
        elseif choice:find("Nuôi nick") then
            while true do
                local title = "🚜 CÀI ĐẶT NUÔI NICK (FARM)\n"
                local opt = dialogChoice(title,
                    "1. Bật/Tắt Nuôi nick (Farm): " .. (BAT_LH_FARM == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "2. Thêm Avatar: " .. (BAT_AVATAR == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "3. Thêm Ảnh bìa: " .. (BAT_ANH_BIA == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "4. Đăng bài (Ảnh + Text): " .. (BAT_DANG_BAI == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "5. Đăng bài (Chỉ Text): " .. (BAT_DANG_BAI_TEXT == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "6. Đăng Story: " .. (BAT_DANG_STORY == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "7. Lướt Newsfeed: " .. (BAT_LUOT_NEWSFEED == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "8. Sửa Profile: " .. (BAT_EDIT_PROFILE == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "9. Xem Watch: " .. (BAT_WATCH == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "───────────────────────────",
                    "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG",
                    "◀️ Quay lại"
                )
                if not opt or opt:find("Quay lại") then break end

                if opt:find("Bật/Tắt Nuôi nick") then BAT_LH_FARM = (BAT_LH_FARM == 1 and 0 or 1)
                elseif opt:find("Avatar") then BAT_AVATAR = (BAT_AVATAR == 1 and 0 or 1)
                elseif opt:find("Ảnh bìa") then BAT_ANH_BIA = (BAT_ANH_BIA == 1 and 0 or 1)
                elseif opt:find("Đăng bài (Ảnh + Text)", 1, true) then BAT_DANG_BAI = (BAT_DANG_BAI == 1 and 0 or 1)
                elseif opt:find("Đăng bài (Chỉ Text)", 1, true) then BAT_DANG_BAI_TEXT = (BAT_DANG_BAI_TEXT == 1 and 0 or 1)
                elseif opt:find("Đăng Story") then BAT_DANG_STORY = (BAT_DANG_STORY == 1 and 0 or 1)
                elseif opt:find("Newsfeed") then BAT_LUOT_NEWSFEED = (BAT_LUOT_NEWSFEED == 1 and 0 or 1)
                elseif opt:find("Profile") then BAT_EDIT_PROFILE = (BAT_EDIT_PROFILE == 1 and 0 or 1)
                elseif opt:find("Xem Watch") then BAT_WATCH = (BAT_WATCH == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local opt_farm = dialogChoice("🚜 THÔNG SỐ RIÊNG NUÔI NICK\n",
                            "1. Thời gian lướt: " .. THOI_GIAN_LUOT .. " giây",
                            "2. Số lần lướt: " .. SO_LAN_LUOT .. " lần",
                            "3. Số video Watch: " .. WATCH_SO_LUONG .. " video",
                            "4. TG xem Watch: " .. WATCH_THOI_GIAN .. " giây",
                            "◀️ Quay lại"
                        )
                        if not opt_farm or opt_farm:find("Quay lại") then break end
                        if opt_farm:find("Thời gian lướt") then
                            local input = dialogInput("Thời gian lướt", "Nhập số giây:", tostring(THOI_GIAN_LUOT))
                            if input and tonumber(input) then THOI_GIAN_LUOT = math.floor(tonumber(input)) end
                        elseif opt_farm:find("Số lần lướt") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần:", tostring(SO_LAN_LUOT))
                            if input and tonumber(input) then SO_LAN_LUOT = math.floor(tonumber(input)) end
                        elseif opt_farm:find("Số video Watch") then
                            local input = dialogInput("Số video Watch", "Nhập số video:", tostring(WATCH_SO_LUONG))
                            if input and tonumber(input) then WATCH_SO_LUONG = math.floor(tonumber(input)) end
                        elseif opt_farm:find("TG xem Watch") then
                            local input = dialogInput("Thời gian xem Watch", "Nhập số giây:", tostring(WATCH_THOI_GIAN))
                            if input and tonumber(input) then WATCH_THOI_GIAN = math.floor(tonumber(input)) end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Kết bạn UID") then
            while true do
                local title = "👤 KẾT BẠN THEO UID\n"
                local opt = dialogChoice(title,
                    "1. Bật/Tắt Kết bạn UID: " .. (BAT_LH_KBUID == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "───────────────────────────",
                    "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG",
                    "◀️ Quay lại"
                )
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_KBUID = (BAT_LH_KBUID == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local soUIDCon = 0
                        local fuid = io.open(UID_FRIEND_FILE, "r")
                        if fuid then for _ in fuid:lines() do soUIDCon = soUIDCon + 1 end fuid:close() end
                        local opt_kb_uid = dialogChoice("👤 THÔNG SỐ KẾT BẠN UID\n",
                            "1. Số UID kết bạn/nick: " .. SO_UID_MOI_NICK .. " UID",
                            "2. Nghỉ giữa các lần: " .. THOI_GIAN_NGHI_UID .. " giây",
                            "3. Xóa UID khi chạy: " .. (BAT_XOA_UID == 1 and "BẬT 🟢" or "TẮT ⚪"),
                            "───────────────────────────",
                            "📋 Dán list UID kết bạn", "👁️ Xem danh sách UID", "🗑️ Xóa tất cả UID",
                            "📂 Đổi file UID: " .. (UID_FRIEND_FILE or "Chưa có") .. " (" .. soUIDCon .. " UID)",
                            "◀️ Quay lại"
                        )
                        if not opt_kb_uid or opt_kb_uid:find("Quay lại") then break end
                        if opt_kb_uid:find("Số UID") then
                            local input = dialogInput("Số UID kết bạn", "Nhập số lượng:", tostring(SO_UID_MOI_NICK))
                            if input and tonumber(input) then SO_UID_MOI_NICK = math.floor(tonumber(input)) end
                        elseif opt_kb_uid:find("Nghỉ") then
                            local input = dialogInput("Thời gian nghỉ", "Nhập số giây:", tostring(THOI_GIAN_NGHI_UID))
                            if input and tonumber(input) then THOI_GIAN_NGHI_UID = math.floor(tonumber(input)) end
                        elseif opt_kb_uid:find("Xóa UID khi chạy") then BAT_XOA_UID = (BAT_XOA_UID == 1 and 0 or 1)
                        elseif opt_kb_uid:find("Dán list UID") then
                            local clip = getClipboard() or ""
                            if clip == "" then toast("⚠️ Clipboard trống!")
                            else
                                local lines = {}
                                for line in string.gmatch(clip, "[^\r\n]+") do
                                    local uid = line:match("^%s*(.-)%s*$")
                                    if uid ~= "" then table.insert(lines, uid) end
                                end
                                if #lines > 0 then
                                    local confirm = dialogChoice("📋 PHÁT HIỆN " .. #lines .. " UID\n\nThêm toàn bộ?", "✅ Thêm ngay!", "◀️ Hủy")
                                    if confirm and confirm:find("Thêm ngay") then
                                        local f = io.open(UID_FRIEND_FILE, "a")
                                        if f then
                                            for _, u in ipairs(lines) do f:write(u .. "\n") end
                                            f:close()
                                            toast("✅ Đã thêm " .. #lines .. " UID")
                                        end
                                    end
                                end
                            end
                        elseif opt_kb_uid:find("Xem danh sách") then
                            local allLines = {}
                            local f = io.open(UID_FRIEND_FILE, "r")
                            if f then for line in f:lines() do if line ~= "" then table.insert(allLines, line) end end f:close() end
                            if #allLines == 0 then toast("📭 File rỗng!")
                            else
                                local page = 1 local pageSize = 30
                                while true do
                                    local startIdx = (page - 1) * pageSize + 1
                                    local endIdx = math.min(page * pageSize, #allLines)
                                    local displayLines = {} for i = startIdx, endIdx do table.insert(displayLines, i .. ". " .. allLines[i]) end
                                    local totalPage = math.ceil(#allLines / pageSize)
                                    local c = dialogChoice("👤 DANH SÁCH UID KẾT BẠN\n📊 Tổng: " .. #allLines .. " UID\n────────────────\n" .. table.concat(displayLines, "\n"), "OK ✅", "Trang tiếp ➡️", "⬅️ Trang trước")
                                    if not c or c:find("OK") then break elseif c:find("Trang tiếp") and page < totalPage then page = page + 1 elseif c:find("Trang trước") and page > 1 then page = page - 1 end
                                end
                            end
                        elseif opt_kb_uid:find("Xóa tất cả UID") then
                            local confirm = dialogChoice("⚠️ XÁC NHẬN XÓA\n\nXóa toàn bộ danh sách UID kết bạn?", "✅ Xóa sạch!", "◀️ Hủy")
                            if confirm and confirm:find("Xóa sạch") then
                                local f = io.open(UID_FRIEND_FILE, "w")
                                if f then f:close() toast("🗑️ Đã xóa sạch UID") end
                            end
                        elseif opt_kb_uid:find("Đổi file UID") then
                            local input = dialogInput("File UID", "Nhập đường dẫn file UID:", UID_FRIEND_FILE or "")
                            if input and input ~= "" then UID_FRIEND_FILE = input end
                        end
                    end
                end
            end
        elseif choice:find("Kết bạn gợi ý") then
            while true do
                local title = "👥 KẾT BẠN GỢI Ý\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Kết bạn gợi ý: " .. (BAT_LH_KBGY == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_KBGY = (BAT_LH_KBGY == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local opt_kb_gy = dialogChoice("👥 THÔNG SỐ KẾT BẠN GỢI Ý\n", "1. Số lượng kết bạn: " .. SO_LUONG_KB_GY .. " người", "2. Thời gian nghỉ giữa các lần: " .. DELAY_KB_GY .. " giây", "3. Số lần lướt tối đa: " .. MAX_LUOT_KB_GY .. " lần", "◀️ Quay lại")
                        if not opt_kb_gy or opt_kb_gy:find("Quay lại") then break end
                        if opt_kb_gy:find("Số lượng") then
                            local input = dialogInput("Số lượng kết bạn", "Nhập số lượng:", tostring(SO_LUONG_KB_GY))
                            if input and tonumber(input) then SO_LUONG_KB_GY = math.floor(tonumber(input)) end
                        elseif opt_kb_gy:find("Thời gian") then
                            local input = dialogInput("Thời gian nghỉ", "Nhập số giây:", tostring(DELAY_KB_GY))
                            if input and tonumber(input) then DELAY_KB_GY = math.floor(tonumber(input)) end
                        elseif opt_kb_gy:find("Số lần lướt") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần:", tostring(MAX_LUOT_KB_GY))
                            if input and tonumber(input) then MAX_LUOT_KB_GY = math.floor(tonumber(input)) end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Chấp nhận KB") then
            while true do
                local title = "🤝 CHẤP NHẬN KẾT BẠN\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Chấp nhận KB: " .. (BAT_LH_CNKB == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_CNKB = (BAT_LH_CNKB == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local opt_cnkb = dialogChoice("🤝 THÔNG SỐ CHẤP NHẬN KB\n", "1. Số lượng chấp nhận: " .. SO_NICK_CNKB .. " người", "2. Thời gian nghỉ: " .. DELAY_CNKB .. " giây", "3. Số lần lướt tối đa: " .. MAX_LUOT_CNKB .. " lần", "◀️ Quay lại")
                        if not opt_cnkb or opt_cnkb:find("Quay lại") then break end
                        if opt_cnkb:find("Số lượng") then
                            local input = dialogInput("Số lượng chấp nhận", "Nhập số lượng:", tostring(SO_NICK_CNKB))
                            if input and tonumber(input) then SO_NICK_CNKB = math.floor(tonumber(input)) end
                        elseif opt_cnkb:find("Thời gian") then
                            local input = dialogInput("Thời gian nghỉ", "Nhập số giây:", tostring(DELAY_CNKB))
                            if input and tonumber(input) then DELAY_CNKB = math.floor(tonumber(input)) end
                        elseif opt_cnkb:find("Số lần lướt") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần:", tostring(MAX_LUOT_CNKB))
                            if input and tonumber(input) then MAX_LUOT_CNKB = math.floor(tonumber(input)) end
                        end
                    end
                end
            end
        elseif choice:find("Comment bài viết") then
            while true do
                local title = "💬 COMMENT BÀI VIẾT\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Comment: " .. (BAT_LH_CMT == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_CMT = (BAT_LH_CMT == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local items_cmt = {
                            "1. Link bài viết: " .. (CMT_URL or "Chưa có"),
                            "2. Chế độ: " .. (CMT_MODE == "random" and "Ngẫu nhiên" or "Tuần tự"),
                            "3. Số lần lướt tìm: " .. CMT_MAX_ATTEMPTS .. " lần",
                            "4. Delay giữa các lần: " .. CMT_SCROLL_DELAY .. " giây",
                            "◀️ Quay lại"
                        }
                        local opt_cmt = dialogChoice("💬 THÔNG SỐ COMMENT", unpack(items_cmt))
                        if not opt_cmt or opt_cmt:find("Quay lại") then break end

                        if opt_cmt:find("Link bài viết") then
                            local input = dialogInput("URL bài viết", "Nhập URL:", CMT_URL or "")
                            if input and input ~= "" then CMT_URL = input end
                        elseif opt_cmt:find("Chế độ") then
                            CMT_MODE = (CMT_MODE == "random" and "sequential" or "random")
                        elseif opt_cmt:find("lướt tìm") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần lướt tối đa:", tostring(CMT_MAX_ATTEMPTS))
                            if input and tonumber(input) then CMT_MAX_ATTEMPTS = math.floor(tonumber(input)) end
                        elseif opt_cmt:find("Delay") then
                            local input = dialogInput("Delay", "Giây nghỉ giữa các lần cuộn:", tostring(CMT_SCROLL_DELAY))
                            if input and tonumber(input) then CMT_SCROLL_DELAY = math.floor(tonumber(input)) end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Share bài viết") then
            while true do
                local title = "🚀 CHIA SẺ BÀI VIẾT\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Share: " .. (BAT_LH_SHARE == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_SHARE = (BAT_LH_SHARE == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local items_share = {
                            "1. Link bài viết: " .. (SHARE_URL or "Chưa có"),
                            "2. Số lần lướt tìm: " .. SHARE_MAX_ATTEMPTS .. " lần",
                            "3. Delay giữa các lần: " .. SHARE_SCROLL_DELAY .. " giây",
                            "◀️ Quay lại"
                        }
                        local opt_share = dialogChoice("🚀 THÔNG SỐ SHARE", unpack(items_share))
                        if not opt_share or opt_share:find("Quay lại") then break end

                        if opt_share:find("Link bài viết") then
                            local input = dialogInput("URL bài viết", "Nhập URL:", SHARE_URL or "")
                            if input and input ~= "" then SHARE_URL = input end
                        elseif opt_share:find("lướt tìm") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần lướt tối đa:", tostring(SHARE_MAX_ATTEMPTS))
                            if input and tonumber(input) then SHARE_MAX_ATTEMPTS = math.floor(tonumber(input)) end
                        elseif opt_share:find("Delay") then
                            local input = dialogInput("Delay", "Giây nghỉ giữa các lần cuộn:", tostring(SHARE_SCROLL_DELAY))
                            if input and tonumber(input) then SHARE_SCROLL_DELAY = math.floor(tonumber(input)) end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Tương tác bài viết") then
            while true do
                local title = "🎯 TƯƠNG TÁC BÀI VIẾT\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Tương tác: " .. (BAT_LH_INTERACT == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end
                if opt:find("Bật/Tắt") then BAT_LH_INTERACT = (BAT_LH_INTERACT == 1 and 0 or 1)
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local selected = {}
                        if INTERACT_LIKE == 1 then table.insert(selected, "👍") end
                        if INTERACT_TYM == 1 then table.insert(selected, "❤️") end
                        if INTERACT_THUONG == 1 then table.insert(selected, "🥰") end
                        if INTERACT_HAHA == 1 then table.insert(selected, "😆") end
                        if INTERACT_BUON == 1 then table.insert(selected, "😢") end
                        local emojiStr = (#selected > 0) and table.concat(selected, "") or "Chưa chọn"

                        local items_int = {
                            "1. Link bài viết: " .. (INTERACT_URL or "Chưa có"),
                            "2. Random cảm xúc: " .. (INTERACT_RANDOM == 1 and "BẬT 🟢" or "TẮT ⚪"),
                            "3. Cảm xúc đã chọn: " .. emojiStr,
                            "4. Số lần lướt tìm: " .. INTERACT_MAX_ATTEMPTS .. " lần",
                            "5. Delay giữa các lần: " .. INTERACT_SCROLL_DELAY .. " giây",
                            "◀️ Quay lại"
                        }
                        local opt_int = dialogChoice("🎯 THÔNG SỐ TƯƠNG TÁC", unpack(items_int))
                        if not opt_int or opt_int:find("Quay lại") then break end

                        if opt_int:find("Link bài viết") then
                            local input = dialogInput("URL bài viết", "Nhập URL:", INTERACT_URL or "")
                            if input and input ~= "" then INTERACT_URL = input end
                        elseif opt_int:find("Random cảm xúc") then 
                            INTERACT_RANDOM = (INTERACT_RANDOM == 1 and 0 or 1)
                        elseif opt_int:find("Cảm xúc đã chọn") then
                            while true do
                                local e_items = {
                                    (INTERACT_LIKE == 1 and "✅" or "❌") .. " Like 👍",
                                    (INTERACT_TYM == 1 and "✅" or "❌") .. " Tym ❤️",
                                    (INTERACT_THUONG == 1 and "✅" or "❌") .. " Thương 🥰",
                                    (INTERACT_HAHA == 1 and "✅" or "❌") .. " Haha 😆",
                                    (INTERACT_BUON == 1 and "✅" or "❌") .. " Buồn 😢",
                                    "◀️ Xong"
                                }
                                local e_choice = dialogChoice("🎭 CHỌN CẢM XÚC", unpack(e_items))
                                if not e_choice or e_choice:find("Xong") then break end
                                if e_choice:find("Like") then INTERACT_LIKE = (INTERACT_LIKE == 1 and 0 or 1)
                                elseif e_choice:find("Tym") then INTERACT_TYM = (INTERACT_TYM == 1 and 0 or 1)
                                elseif e_choice:find("Thương") then INTERACT_THUONG = (INTERACT_THUONG == 1 and 0 or 1)
                                elseif e_choice:find("Haha") then INTERACT_HAHA = (INTERACT_HAHA == 1 and 0 or 1)
                                elseif e_choice:find("Buồn") then INTERACT_BUON = (INTERACT_BUON == 1 and 0 or 1)
                                end
                            end
                        elseif opt_int:find("lướt tìm") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần lướt tối đa:", tostring(INTERACT_MAX_ATTEMPTS))
                            if input and tonumber(input) then INTERACT_MAX_ATTEMPTS = math.floor(tonumber(input)) end
                        elseif opt_int:find("Delay") then
                            local input = dialogInput("Delay", "Giây nghỉ giữa các lần cuộn:", tostring(INTERACT_SCROLL_DELAY))
                            if input and tonumber(input) then INTERACT_SCROLL_DELAY = math.floor(tonumber(input)) end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Tham gia nhóm") then
            while true do
                local title = "🌐 THIẾT LẬP THAM GIA NHÓM (LIÊN HOÀN)\n"
                local opt = dialogChoice(title, "1. Bật/Tắt Tham gia nhóm: " .. (BAT_LH_JOIN_GROUP == 1 and "BẬT 🟢" or "TẮT ⚪"), "───────────────────────────", "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG", "◀️ Quay lại")
                if not opt or opt:find("Quay lại") then break end

                if opt:find("Bật/Tắt") then 
                    BAT_LH_JOIN_GROUP = (BAT_LH_JOIN_GROUP == 1 and 0 or 1)
                    luuCauHinh()
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local soUIDCon = demUIDNhomTrongFile()
                        local opt_g = dialogChoice("🌐 THÔNG SỐ THAM GIA NHÓM (LIÊN HOÀN)\n", 
                            "1. Số nhóm mỗi nick: " .. JG_SL_LH .. " nhóm", 
                            "2. Thời gian nghỉ: " .. JG_TG_LH .. " giây", 
                            "3. Xóa UID nhóm khi chạy: " .. (BAT_XOA_UID_NHOM == 1 and "BẬT 🟢" or "TẮT ⚪"),
                            "───────────────────────────",
                            "📋 Dán list UID nhóm", "👁️ Xem danh sách nhóm", "🗑️ Xóa tất cả UID nhóm",
                            "📂 Đổi file UID: " .. (GROUP_UID_FILE or "Chưa có") .. " (" .. soUIDCon .. " UID)",
                            "📜 Xem Log", "🧹 Xóa Log",
                            "◀️ Quay lại")
                        if not opt_g or opt_g:find("Quay lại") then break end
                        if opt_g:find("Số nhóm") then
                            local input = dialogInput("Số nhóm", "Nhập số lượng:", tostring(JG_SL_LH))
                            if input and tonumber(input) then JG_SL_LH = math.floor(tonumber(input)) end
                        elseif opt_g:find("Thời gian") then
                            local input = dialogInput("Thời gian nghỉ", "Nhập số giây:", tostring(JG_TG_LH))
                            if input and tonumber(input) then JG_TG_LH = math.floor(tonumber(input)) end
                        elseif opt_g:find("Xóa UID nhóm") then
                            BAT_XOA_UID_NHOM = (BAT_XOA_UID_NHOM == 1 and 0 or 1)
                        elseif opt_g:find("Dán list UID") then
                            local clip = getClipboard() or ""
                            if clip == "" then toast("⚠️ Clipboard trống!")
                            else
                                local lines = {}
                                for line in string.gmatch(clip, "[^\r\n]+") do
                                    local uid = line:match("^%s*(.-)%s*$")
                                    if uid ~= "" then table.insert(lines, uid) end
                                end
                                if #lines > 0 then
                                    local confirm = dialogChoice("📋 PHÁT HIỆN " .. #lines .. " UID\n\nThêm toàn bộ?", "✅ Thêm ngay!", "◀️ Hủy")
                                    if confirm and confirm:find("Thêm ngay") then
                                        local f = io.open(GROUP_UID_FILE, "a")
                                        if f then for _, uid in ipairs(lines) do f:write(uid .. "\n") end f:close() toast("✅ Đã thêm!") end
                                    end
                                end
                            end
                        elseif opt_g:find("Xem danh sách") then
                            local allLines = {}
                            local f = io.open(GROUP_UID_FILE, "r")
                            if f then for line in f:lines() do if line ~= "" then table.insert(allLines, line) end end f:close() end
                            if #allLines == 0 then toast("📭 File rỗng!")
                            else
                                local page = 1 local pageSize = 50
                                while true do
                                    local startIdx = (page - 1) * pageSize + 1
                                    local endIdx = math.min(page * pageSize, #allLines)
                                    local displayLines = {} for i = startIdx, endIdx do table.insert(displayLines, i .. ". " .. allLines[i]) end
                                    local totalPage = math.ceil(#allLines / pageSize)
                                    local c = dialogChoice("📂 DANH SÁCH NHÓM\n📊 Tổng: " .. #allLines .. " UID\n────────────────\n" .. table.concat(displayLines, "\n"), "OK ✅", "Trang tiếp ➡️", "⬅️ Trang trước")
                                    if not c or c:find("OK") then break elseif c:find("Trang tiếp") and page < totalPage then page = page + 1 elseif c:find("Trang trước") and page > 1 then page = page - 1 end
                                end
                            end
                        elseif opt_g:find("Xóa tất cả UID") then
                            local confirm = dialogChoice("🗑️ XÓA HẾT UID NHÓM?", "Xóa sạch!", "Hủy")
                            if confirm and confirm:find("Xóa sạch") then local f = io.open(GROUP_UID_FILE, "w") if f then f:close() toast("✅ Đã xóa!") end end
                        elseif opt_g:find("Đổi file UID") then
                            local input = dialogInput("File UID", "Đường dẫn:", GROUP_UID_FILE)
                            if input and input ~= "" then GROUP_UID_FILE = input end
                        elseif opt_g:find("Xem Log") then
                            local f = io.open(GROUP_LOG_FILE, "r")
                            if f then
                                local lines = {} for line in f:lines() do table.insert(lines, line) if #lines > 100 then table.remove(lines, 1) end end f:close()
                                dialogChoice("📜 LOG THAM GIA NHÓM\n\n" .. table.concat(lines, "\n"), "OK ✅")
                            end
                        elseif opt_g:find("Xóa Log") then
                            local f = io.open(GROUP_LOG_FILE, "w") if f then f:close() toast("✅ Đã xóa!") end
                        end
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("9. Lướt Newsfeed có Like") then
            while true do
                local title = "👍 LƯỚT NEWSFEED CÓ LIKE (LIÊN HOÀN)\n"
                local opt = dialogChoice(title, 
                    "1. Bật/Tắt Lướt Like: " .. (BAT_LH_LUOT_LIKE == 1 and "BẬT 🟢" or "TẮT ⚪"),
                    "───────────────────────────",
                    "⚙️ CẤU HÌNH THÔNG SỐ RIÊNG",
                    "◀️ Quay lại"
                )
                if not opt or opt:find("Quay lại") then break end

                if opt:find("Bật/Tắt") then 
                    BAT_LH_LUOT_LIKE = (BAT_LH_LUOT_LIKE == 1 and 0 or 1)
                    luuCauHinh()
                elseif opt:find("CẤU HÌNH THÔNG SỐ RIÊNG") then
                    while true do
                        local opt_like = dialogChoice("👍 THÔNG SỐ LƯỚT LIKE (LIÊN HOÀN)\n",
                            "1. Số lần lướt: " .. LH_NF_LIKE_SO_BAI .. " lần",
                            "2. Số bài để thả Like: " .. LH_NF_LIKE_SO_LIKE .. " bài",
                            "3. Nghỉ giữa lần lướt: " .. LH_NF_LIKE_NGHI .. " giây",
                            "◀️ Quay lại"
                        )
                        if not opt_like or opt_like:find("Quay lại") then break end
                        if opt_like:find("Số lần lướt") then
                            local input = dialogInput("Số lần lướt", "Nhập số lần lướt:", tostring(LH_NF_LIKE_SO_BAI))
                            if input and tonumber(input) then LH_NF_LIKE_SO_BAI = math.floor(tonumber(input)) end
                        elseif opt_like:find("Số bài để thả Like") then
                            local input = dialogInput("Số bài để thả Like", "Nhập số bài muốn Like:", tostring(LH_NF_LIKE_SO_LIKE))
                            if input and tonumber(input) then LH_NF_LIKE_SO_LIKE = math.floor(tonumber(input)) end
                        elseif opt_like:find("Thời gian nghỉ") then
                            local input = dialogInput("Thời gian nghỉ", "Nhập số giây nghỉ giữa lần lướt:", tostring(LH_NF_LIKE_NGHI))
                            if input and tonumber(input) then LH_NF_LIKE_NGHI = math.floor(tonumber(input)) end
                        end
                        ganGiaTri("LH_NF_LIKE_SO_BAI", LH_NF_LIKE_SO_BAI)
                        ganGiaTri("LH_NF_LIKE_SO_LIKE", LH_NF_LIKE_SO_LIKE)
                        ganGiaTri("LH_NF_LIKE_NGHI", LH_NF_LIKE_NGHI)
                        luuCauHinh()
                    end
                end
            end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT nick bắt đầu chạy:", tostring(NICK_BAT_DAU))
            if input and tonumber(input) then NICK_BAT_DAU = math.max(1, math.floor(tonumber(input))) end
        elseif choice:find("Số nick chạy") then
            local input = dialogInput("Số nick chạy", "Nhập số lượng nick:", tostring(LH_SO_NICK))
            if input and tonumber(input) then LH_SO_NICK = math.floor(tonumber(input)) end
        elseif choice:find("Thời gian nghỉ") then
            local input = dialogInput("Thời gian nghỉ", "Nghỉ giữa các nick (giây):", tostring(THOI_GIAN_NGHI))
            if input and tonumber(input) then THOI_GIAN_NGHI = math.floor(tonumber(input)) end
        elseif choice:find("BẮT ĐẦU CHẠY TỔNG HỢP") then
            local soBatLH = 0
            if BAT_LH_FARM == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_KBUID == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_KBGY == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_CNKB == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_CMT == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_SHARE == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_INTERACT == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_JOIN_GROUP == 1 then soBatLH = soBatLH + 1 end
            if BAT_LH_LUOT_LIKE == 1 then soBatLH = soBatLH + 1 end

            if soBatLH == 0 then
                toast("⚠️ Vui lòng chọn ít nhất một chức năng để chạy!")
            else
                local confirm = dialogChoice("🚀 XÁC NHẬN CHẠY TỔNG HỢP\n\n🔢 Chạy: " .. LH_SO_NICK .. " nick\n⏳ Nghỉ: " .. THOI_GIAN_NGHI .. "s", "✅ Chạy ngay!", "◀️ Quay lại")
                if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "chay_tong_hop" end
            end
        end
    end
end

-- ========== CÁC MENU CON CỦA FARM ==========
function menuToggle()
    while true do
        local items = {}
        for _, feat in ipairs(GUI_FEATURES) do
            local val = layGiaTri(feat[2])
            local icon = (val == 1) and "✅" or "❌"
            table.insert(items, icon .. " " .. feat[1])
        end
        table.insert(items, "──────────────")
        table.insert(items, "🟢 Bật tất cả")
        table.insert(items, "🔴 Tắt tất cả")
        table.insert(items, "◀️ Quay lại")

        local choice = dialogChoice("⚙️ BẬT/TẮT CHỨC NĂNG", unpack(items))
        if not choice or choice:find("Quay lại") then break end

        if choice:find("Bật tất cả") then
            for _, feat in ipairs(GUI_FEATURES) do ganGiaTri(feat[2], 1) end
            luuCauHinh()
        elseif choice:find("Tắt tất cả") then
            for _, feat in ipairs(GUI_FEATURES) do ganGiaTri(feat[2], 0) end
            luuCauHinh()
        else
            for _, feat in ipairs(GUI_FEATURES) do
                if choice:find(feat[1], 1, true) then
                    local val = layGiaTri(feat[2])
                    ganGiaTri(feat[2], (val == 1) and 0 or 1)
                    luuCauHinh()
                    break
                end
            end
        end
    end
end

function menuSettings()
    while true do
        local items = {}
        for _, setting in ipairs(GUI_SETTINGS) do
            table.insert(items, "🔢 " .. setting[1] .. ": " .. layGiaTri(setting[2]) .. " " .. setting[3])
        end
        table.insert(items, "◀️ Quay lại")

        local choice = dialogChoice("🔢 CÀI ĐẶT THÔNG SỐ FARM", unpack(items))
        if not choice or choice:find("Quay lại") then break end

        for _, setting in ipairs(GUI_SETTINGS) do
            if choice:find(setting[1], 1, true) then
                local input = dialogInput(setting[1], "Nhập giá trị mới (" .. setting[3] .. "):", tostring(layGiaTri(setting[2])))
                if input and tonumber(input) then
                    ganGiaTri(setting[2], math.floor(tonumber(input)))
                    luuCauHinh()
                end
                break
            end
        end
    end
end

function menuWatch()
    while true do
        local title = "🎬 CHẾ ĐỘ XEM WATCH ĐỘC LẬP\n"
        local choice = dialogChoice(title,
            "1. Số video xem/nick: " .. WATCH_SL_SA .. " video",
            "2. TG xem tối đa: " .. WATCH_TG_SA .. " giây",
            "3. Nick bắt đầu (STT): " .. NICK_BAT_DAU,
            "4. Số nick muốn chạy: " .. WATCH_SO_NICK .. " nick",
            "🚀 BẮT ĐẦU CHẠY XEM WATCH",
            "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return nil end

        if choice:find("Số video") then
            local input = dialogInput("Số video", "Nhập số lượng:", tostring(WATCH_SL_SA))
            if input and tonumber(input) then WATCH_SL_SA = math.floor(tonumber(input)) end
        elseif choice:find("TG xem") then
            local input = dialogInput("Thời gian xem", "Nhập số giây:", tostring(WATCH_TG_SA))
            if input and tonumber(input) then WATCH_TG_SA = math.floor(tonumber(input)) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT nick bắt đầu:", tostring(NICK_BAT_DAU))
            if input and tonumber(input) then NICK_BAT_DAU = math.max(1, math.floor(tonumber(input))) end
        elseif choice:find("Số nick") then
            local input = dialogInput("Số nick", "Nhập số lượng:", tostring(WATCH_SO_NICK))
            if input and tonumber(input) then WATCH_SO_NICK = math.floor(tonumber(input)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            luuCauHinh()
            return "xem_watch_standalone"
        end
    end
end

-- ========== MENU CHÍNH ==========
function menuChinh()
    local f = io.open(CONFIG_PATH, "r")
    if f then f:close() taiCauHinh() log("📂 Tự động tải config đã lưu") end

    while true do
        local soBat = 0
        if BAT_AVATAR == 1 then soBat = soBat + 1 end
        if BAT_ANH_BIA == 1 then soBat = soBat + 1 end
        if BAT_DANG_BAI == 1 then soBat = soBat + 1 end
        if BAT_DANG_BAI_TEXT == 1 then soBat = soBat + 1 end
        if BAT_DANG_STORY == 1 then soBat = soBat + 1 end
        if BAT_LUOT_NEWSFEED == 1 then soBat = soBat + 1 end
        if BAT_EDIT_PROFILE == 1 then soBat = soBat + 1 end
        if BAT_WATCH == 1 then soBat = soBat + 1 end

        local soMax = 8
        local title = "📱 Facebook Auto\n"
            .. "· Farm bật: " .. soBat .. "/" .. soMax .. "  · Lặp: " .. SO_LAN_LAP .. " lần"

        local choice = dialogChoice(title,
            "🚜 1. NUÔI NICK (FARM) ->",
            "🔄 2. CHẠY TỔNG HỢP (LIÊN HOÀN)",
            "👤 3. KẾT BẠN THEO UID",
            "👥 4. KẾT BẠN GỢI Ý",
            "🤝 5. CHẤP NHẬN KẾT BẠN",
            "🎬 6. XEM WATCH ->",
            "🔑 7. NẠP NICK HỆ THỐNG",
            "🎯 8. TƯƠNG TÁC BÀI VIẾT",
            "💬 9. CMT BÀI VIẾT ->",
            "🚀 10. CHIA SẺ BÀI VIẾT",
            "🌐 11. THAM GIA NHÓM ->",
            "🛠️ 12. QUẢN LÝ HỆ THỐNG ->",
            "❌ THOÁT"
        )

        if not choice or choice:find("THOÁT") then return "exit" end

        if choice:find("NUÔI NICK") then
            while true do
                local opt_f = dialogChoice("🚜 MENU NUÔI NICK (FARM)\n",
                    "⚙️ 1. Bật/Tắt chức năng Farm",
                    "🔢 2. Cài đặt thông số Farm",
                    "📋 3. Xem cấu hình hiện tại",
                    "💾 4. Lưu cấu hình",
                    "📂 5. Tải cấu hình",
                    "🚀 6. BẮT ĐẦU CHẠY FARM",
                    "◀️ Quay lại"
                )
                if not opt_f or opt_f:find("Quay lại") then break end

                if opt_f:find("Bật/Tắt") then menuToggle()
                elseif opt_f:find("Cài đặt thông số") then menuSettings()
                elseif opt_f:find("Xem cấu hình") then dialogChoice("📋 CẤU HÌNH HIỆN TẠI\n\n" .. tomTatCauHinh(), "OK ✅")
                elseif opt_f:find("Lưu cấu hình") then luuCauHinh()
                elseif opt_f:find("Tải cấu hình") then taiCauHinh()
                elseif opt_f:find("BẮT ĐẦU CHẠY") then
                    if soBat == 0 then toast("⚠️ Chưa bật chức năng nào!")
                    else
                        local confirm = dialogChoice("🚀 XÁC NHẬN FARM\n\n" .. tomTatCauHinh(), "✅ Chạy ngay!", "◀️ Quay lại")
                        if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "farm" end
                    end
                end
            end
        elseif choice:find("CHẠY TỔNG HỢP") then
            local res = menuChayTongHop()
            if res == "chay_tong_hop" then return "chay_tong_hop" end
        elseif choice:find("KẾT BẠN THEO UID") then
            local res = menuKetBanUID()
            if res == "ket_ban_uid" then return "ket_ban_uid" end
        elseif choice:find("KẾT BẠN GỢI Ý") then
            local res = menuKetBanGoiY()
            if res == "ket_ban_goi_y" then return "ket_ban_goi_y" end
        elseif choice:find("CHẤP NHẬN KẾT BẠN") then
            local res = menuChapNhanKetBan()
            if res == "chap_nhan_kb" then return "chap_nhan_kb" end
        elseif choice:find("XEM WATCH") then
            local res = menuWatch()
            if res == "xem_watch_standalone" then return "xem_watch_standalone" end
        elseif choice:find("NẠP NICK") then
            local res = menuNapNick()
            if res == "nap_nick" then return "nap_nick" end
        elseif choice:find("TƯƠNG TÁC BÀI VIẾT") then
            local res = menuInteractPost()
            if res == "interact_post" then return "interact_post" end
        elseif choice:find("CMT BÀI VIẾT") then
            local res = menuCMTBaiViet()
            if res == "cmt_bai_viet" then return "cmt_bai_viet" end
        elseif choice:find("CHIA SẺ BÀI VIẾT") then
            local res = menuShareBaiViet()
            if res == "share_bai_viet" then return "share_bai_viet" end
        elseif choice:find("THAM GIA NHÓM") then
            local res = menuJoinGroup()
            if res == "join_group" then return "join_group" end
        elseif choice:find("QUẢN LÝ HỆ THỐNG") then
            while true do
                local opt_h = dialogChoice("🛠️ QUẢN LÝ HỆ THỐNG\n",
                    "🏗️ 1. Quản lý phân vùng Crane",
                    "📂 2. Tạo file nội dung mẫu",
                    "🗑️ 3. Xóa toàn bộ file cấu hình",
                    "🛡️ 4. Xem hạn sử dụng (Key)",
                    "◀️ Quay lại"
                )
                if not opt_h or opt_h:find("Quay lại") then break end

                if opt_h:find("Quản lý phân vùng") then menuCrane()
                elseif opt_h:find("Tạo file nội dung") then taoTatCaFileNoiDung()
                elseif opt_h:find("Xóa toàn bộ file") then xoaTatCaFile()
                elseif opt_h:find("Xem hạn sử dụng") then
                    local now = os.time()
                    local exp = _G.EXP_TIMESTAMP or 0
                    if exp > now then
                        local diff = exp - now
                        local days = math.floor(diff / (24 * 60 * 60))
                        local msg = string.format("Mã máy: %s\nHSD: %s\nCòn lại: %d ngày", getSN(), os.date("%d/%m/%Y %H:%M:%S", exp), days)
                        dialogInput("🛡️ THÔNG TIN BẢN QUYỀN", msg, getSN())
                    else
                        dialogChoice("❌ Bản quyền đã hết hạn hoặc chưa kích hoạt!", "OK")
                    end
                end
            end
        end
    end
end

function tomTatCauHinh()
    local lines = {}
    table.insert(lines, "── CHỨC NĂNG FARM ──")
    for _, feat in ipairs(GUI_FEATURES) do
        local val = layGiaTri(feat[2])
        local status = (val == 1) and "✅ BẬT" or "❌ TẮT"
        table.insert(lines, feat[1] .. ": " .. status)
    end
    table.insert(lines, "")
    table.insert(lines, "── THÔNG SỐ FARM ──")
    for _, setting in ipairs(GUI_SETTINGS) do
        table.insert(lines, "🔢 " .. setting[1] .. ": " .. layGiaTri(setting[2]) .. " " .. setting[3])
    end
    table.insert(lines, "")
    table.insert(lines, "── NẠP NICK ──")
    table.insert(lines, "📂 File: " .. ACCOUNT_FILE)
    table.insert(lines, "🔢 Số nick: " .. SO_NICK_CAN_DANG_NHAP)
    table.insert(lines, "")
    table.insert(lines, "── KẾT BẠN GỢI Ý ──")
    table.insert(lines, "🔢 SL/Nick: " .. SO_LUONG_KB_GY)
    table.insert(lines, "")
    table.insert(lines, "── CHẤP NHẬN KẾT BẠN ──")
    table.insert(lines, "👥 Nick chạy: " .. SO_NICK_CNKB)
    table.insert(lines, "⏳ Delay: " .. DELAY_CNKB .. "s")
    return table.concat(lines, "\n")
end

print("✅ menu_chinh.lua đã nạp (Đầy đủ 100%)")