-- ================================================================
-- FILE: chap_nhan_kb.lua - CHẤP NHẬN KẾT BẠN
-- Nguồn: fb_auto_new.lua dòng 1782-1991
-- ================================================================

-- ========== MENU CHẤP NHẬN KẾT BẠN ==========
function menuChapNhanKetBan()
    while true do
        local title = "🤝 Chấp nhận kết bạn\n"
            .. "· Nick: " .. SO_NICK_CNKB .. "  · Nghỉ: " .. DELAY_CNKB .. "s\n"
            .. "· Lướt tối đa: " .. MAX_LUOT_CNKB .. " lần"
        local choice = dialogChoice(title,
            "👥 Đổi số nick cần chạy",
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "⏳ Đổi thời gian nghỉ",
            "📜 Đổi số lần lướt tối đa",
            "──────────────",
            "🚀 BẮT ĐẦU CHẠY",
            "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Đổi số nick") then
            local input = dialogInput("Số nick cần chạy", "Hiện tại: " .. SO_NICK_CNKB)
            if input and tonumber(input) then SO_NICK_CNKB = math.floor(tonumber(input)) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT nick bắt đầu chạy:", tostring(NICK_BAT_DAU))
            if input then
                local num = tonumber(input)
                if num and num >= 0 then NICK_BAT_DAU = math.max(1, math.floor(num)) toast("🚩 Nick bắt đầu: " .. NICK_BAT_DAU)
                else toast("⚠️ Giá trị không hợp lệ!") end
            end
        elseif choice:find("Đổi thời gian") then
            local input = dialogInput("Thời gian nghỉ (giây)", "Hiện tại: " .. DELAY_CNKB)
            if input and tonumber(input) then DELAY_CNKB = math.floor(tonumber(input)) end
        elseif choice:find("Đổi số lần lướt") then
            local input = dialogInput("Lướt tối đa không thấy nút", "Hiện tại: " .. MAX_LUOT_CNKB)
            if input and tonumber(input) then MAX_LUOT_CNKB = math.floor(tonumber(input)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            local confirm = dialogChoice(
                "🚀 XÁC NHẬN CHẠY CHẤP NHẬN\n\n👥 Chạy: " .. SO_NICK_CNKB .. " nick\n⏳ Nghỉ: " .. DELAY_CNKB .. "s",
                "✅ Chạy ngay!", "◀️ Quay lại"
            )
            if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "chap_nhan_kb" end
        end
    end
end

-- ========== TÌM VÀ TAP FRIENDS ==========
local function timVaTapFriends()
    log("🔍 Tim Friends...")
    if findText("Friends", 3) then
        tapText("Friends", 5, 1) log("✅ Da tap Friends truc tiep") sleep(2) return true
    end
    log("⚠️ Khong tim thay Friends, tim Menu...")
    if findText("Menu", 3) then
        tapText("Menu", 5, 1) log("✅ Da tap Menu") sleep(2)
        if findText("Friends", 3) then
            tapText("Friends", 5, 1) log("✅ Da tap Friends qua Menu") sleep(2) return true
        end
    end
    logScreen("❌ KHÔNG TÌM THẤY MỤC BẠN BÈ", true)
    return false
end

-- ========== TÌM NÚT CONFIRM BẰNG OCR ==========
local function timTatCaConfirm()
    local danhSach = {}
    local results = ocr({region = {0, 0, 430, 800}, languages = {"en-US"}})
    for _, r in ipairs(results) do
        if string.find(r.text, "Confirm") or string.find(r.text, "confirm") then
            table.insert(danhSach, {x = r.x, y = r.y, text = r.text})
        end
    end
    return danhSach
end

-- ========== LƯỚT MÀN HÌNH ==========
local function luotManHinhCNKB()
    log("📜 Khong tim thay Confirm -> Luot man hinh")
    swipe(296, 599, 215, 300, 1) sleep(2)
end

-- ========== CHẠY CHẤP NHẬN KẾT BẠN ==========
function thucHienChapNhanKetBan()
    logScreen("────────────────────\n🚀 BẮT ĐẦU CHẤP NHẬN KB\n────────────────────", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + SO_NICK_CNKB), true)
    log("👥 Nick sẽ chạy: " .. SO_NICK_CNKB)
    log("⏳ Delay giữa các lần: " .. DELAY_CNKB .. " giây")
    log("📜 Lượt tối đa: " .. MAX_LUOT_CNKB .. " lần")

    local tongChapNhan = 0
    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, SO_NICK_CNKB do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end
        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. SO_NICK_CNKB .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
            resetMang() sleep(1)
            chuyenNick(tenPhanVung)
            nghi(1, "Chuẩn bị vào Facebook")
        end

        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            sleep(1)
            if not timVaTapFriends() then
                log("⏭️ Nick " .. nickIndex .. " khong vao duoc Friends, bo qua")
            else
                sleep(2)
                local daChapNhan = 0
                local luotKhongCo = 0
                while true do
                    logScreen("🔍 Đang tìm lời mời kết bạn...", true)
                    local cacNutConfirm = timTatCaConfirm()
                    if #cacNutConfirm > 0 then
                        luotKhongCo = 0
                        for i = 1, #cacNutConfirm do
                            daChapNhan = daChapNhan + 1
                            logScreen("🤝 Đã chấp nhận: " .. daChapNhan .. " lời mời", true)
                            tap(cacNutConfirm[i].x, cacNutConfirm[i].y)
                            sleep(1)

                            -- KIỂM TRA NGAY XEM CÓ BỊ VÀO NHẦM TRANG CÁ NHÂN KHÔNG
                            if findText("message", 1) or findText("Message", 1) then
                                log("⚠️ Phat hien nhan nham vao Nick, dang quay lai...")
                                if not tapImage("crop_1776705682700.png", 10, 1) then
                                    -- Nếu không tìm thấy ảnh thì nhấn tọa độ dự phòng
                                    tap(25, 41) 
                                    log("✅ Đã quay lại bằng tọa độ")
                                else
                                    log("✅ Đã quay lại bằng hình ảnh")
                                end
                                sleep(1.5)
                                daChapNhan = daChapNhan - 1
                            end

                            sleep(DELAY_CNKB)
                        end
                    else
                        luotKhongCo = luotKhongCo + 1
                        log("⚠️ Khong tim thay Confirm (" .. luotKhongCo .. "/" .. MAX_LUOT_CNKB .. ")")
                        if luotKhongCo >= MAX_LUOT_CNKB then
                            logScreen("⏭️ Không thấy thêm lời mời nào", true)
                            break
                        end
                        logScreen("📜 Đang lướt tìm thêm...", true)
                        luotManHinhCNKB()
                    end
                    sleep(1)
                end
                tongChapNhan = tongChapNhan + daChapNhan
                log("📊 Nick " .. nickIndex .. " da CHAP NHAN: " .. daChapNhan .. " loi moi")
            end
        end
        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook() sleep(1)
            if nickIndex < SO_NICK_CNKB then nghi(5, "Nghỉ giải lao giữa các nick") end
        end
    end

    logScreen("✅ HOÀN TẤT CHẤP NHẬN KẾT BẠN", true)
    log("📊 TỔNG CHẤP NHẬN: " .. tongChapNhan .. " lời mời")
    log("==========================================")
end

print("✅ chap_nhan_kb.lua đã nạp")