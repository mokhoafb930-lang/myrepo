-- ================================================================
-- FILE: ket_ban_goi_y.lua - KẾT BẠN GỢI Ý
-- Nguồn: fb_auto_new.lua dòng 1717-1780, 3421-3588
-- ================================================================

-- ========== MENU KẾT BẠN GỢI Ý ========== (dòng 1717-1780)
function menuKetBanGoiY()
    while true do
        local title = "👥 Kết bạn gợi ý\n"
            .. "· Nick: " .. SO_NICK_KB_GY .. "  · SL/nick: " .. SO_LUONG_KB_GY .. "\n"
            .. "· Nghỉ: " .. DELAY_KB_GY .. "s  · Lướt tối đa: " .. MAX_LUOT_KB_GY .. " lần"
        local choice = dialogChoice(title,
            "👥 Đổi số nick cần chạy",
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "🔢 Đổi số lượng KB/nick",
            "⏳ Đổi thời gian nghỉ",
            "📜 Đổi số lần lướt tối đa",
            "──────────────",
            "🚀 BẮT ĐẦU CHẠY",
            "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Đổi số nick") then
            local input = dialogInput("Số nick cần chạy", "Hiện tại: " .. SO_NICK_KB_GY)
            if input and tonumber(input) then SO_NICK_KB_GY = math.floor(tonumber(input)) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT:", tostring(NICK_BAT_DAU))
            if input then local num = tonumber(input) if num and num >= 0 then NICK_BAT_DAU = math.max(1, math.floor(num)) end end
        elseif choice:find("Đổi số lượng") then
            local input = dialogInput("Số lượng kết bạn mỗi nick", "Hiện tại: " .. SO_LUONG_KB_GY)
            if input and tonumber(input) then SO_LUONG_KB_GY = math.floor(tonumber(input)) end
        elseif choice:find("Đổi thời gian") then
            local input = dialogInput("Thời gian nghỉ (giây)", "Hiện tại: " .. DELAY_KB_GY)
            if input and tonumber(input) then DELAY_KB_GY = math.floor(tonumber(input)) end
        elseif choice:find("Đổi số lần lướt") then
            local input = dialogInput("Lướt tối đa không thấy nút", "Hiện tại: " .. MAX_LUOT_KB_GY)
            if input and tonumber(input) then MAX_LUOT_KB_GY = math.floor(tonumber(input)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            local confirm = dialogChoice(
                "🚀 XÁC NHẬN CHẠY GỢI Ý\n\n👥 Chạy: " .. SO_NICK_KB_GY .. " nick\n🔢 SL: " .. SO_LUONG_KB_GY .. " người/nick",
                "✅ Chạy ngay!", "◀️ Quay lại"
            )
            if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "ket_ban_goi_y" end
        end
    end
end

-- ========== TÌM VÀ TAP FRIENDS (GỢI Ý) ========== (dòng 3425-3448)
local function timVaTapFriendsGY()
    log("🔍 Tim Friends...")
    if findText("Friends") then
        tapText("Friends", 10, 1) log("✅ Da tap Friends") sleep(2) return true
    end
    log("⚠️ Khong tim thay Friends, thu Menu...")
    if findText("Menu") then
        tapText("Menu", 10, 1) log("✅ Da tap Menu") sleep(2)
        if findText("Friends") then
            tapText("Friends", 10, 1) log("✅ Da tap Friends qua Menu") sleep(2) return true
        end
    end
    log("❌ Khong tim thay Friends")
    return false
end

-- ========== KIỂM TRA GỢI Ý ========== (dòng 3450-3469)
local function kiemTraGoiYGY()
    logScreen("🔍 Đang kiểm tra gợi ý kết bạn...", true)
    if not timVaTapFriendsGY() then return false end
    sleep(3)
    if findText("No New Requests") then
        logScreen("⏭️ Không có gợi ý mới", true) return false
    else
        logScreen("✅ Đã thấy danh sách gợi ý", true) return true
    end
end

-- ========== TÌM ADD FRIEND BẰNG OCR ========== (dòng 3471-3484)
local function timTatCaAddFriendOCRGY()
    local danhSach = {}
    local results = ocr({region = {0, 0, 430, 800}, languages = {"en-US"}})
    for _, r in ipairs(results) do
        if string.find(r.text, "Add Friend") or string.find(r.text, "add friend") then
            table.insert(danhSach, {x = r.x, y = r.y, text = r.text})
        end
    end
    return danhSach
end

-- ========== LƯỚT MÀN HÌNH ========== (dòng 3486-3491)
local function luotManHinhGY()
    log("📜 Khong tim thay Add Friend -> Luot man hinh")
    swipe(296, 599, 215, 300, 1) sleep(2)
end

-- ========== THỰC HIỆN KẾT BẠN GỢI Ý ========== (dòng 3493-3588)
function thucHienKetBanGoiY()
    log("")
    logScreen("────────────────────\n🚀 BẮT ĐẦU KẾT BẠN GỢI Ý\n────────────────────", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + SO_NICK_KB_GY), true)
    log("👥 Chạy: " .. SO_NICK_KB_GY .. " nick")
    log("🔢 SL/nick: " .. SO_LUONG_KB_GY .. " người")
    log("⏳ Nghỉ: " .. DELAY_KB_GY .. "s")

    local tongTC_GY = 0
    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, SO_NICK_KB_GY do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end
        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. SO_NICK_KB_GY .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
            resetMang() sleep(1)
            chuyenNick(tenPhanVung) sleep(1)
        end
        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            sleep(10)
            if not kiemTraGoiYGY() then
                log("⏭️ Nick nay khong co goi y, bo qua")
            else
                local daKetBan = 0
                local lanLienTiepKhongCo = 0

                while daKetBan < SO_LUONG_KB_GY do
                    log("📊 Tien do: " .. daKetBan .. "/" .. SO_LUONG_KB_GY)
                    local cacNut = timTatCaAddFriendOCRGY()

                    if #cacNut > 0 then
                        lanLienTiepKhongCo = 0
                        for i = 1, #cacNut do
                            if daKetBan >= SO_LUONG_KB_GY then break end
                            daKetBan = daKetBan + 1
                            logScreen("🤝 Đã nhấn Add (" .. daKetBan .. "/" .. SO_LUONG_KB_GY .. ")", true)
                            tap(cacNut[i].x, cacNut[i].y) sleep(1)

                            if findText("message", 1) or findText("Message", 1) then
                                log("⚠️ Phat hien text 'message', quay lai...")
                                tapImage("crop_1776705682700.png", 10, 1) sleep(1)
                                daKetBan = daKetBan - 1
                            else
                                log("✅ Khong phat hien 'message', tap chinh xac")
                            end

                            if daKetBan < SO_LUONG_KB_GY then
                                nghi(DELAY_KB_GY, "Nghỉ đợi kết bạn gợi ý tiếp")
                            end
                        end
                    else
                        lanLienTiepKhongCo = lanLienTiepKhongCo + 1
                        log("⚠️ Khong tim thay Add Friend (" .. lanLienTiepKhongCo .. "/" .. MAX_LUOT_KB_GY .. ")")
                        if lanLienTiepKhongCo >= MAX_LUOT_KB_GY then
                            logScreen("💀 HẾT GỢI Ý KẾT BẠN!", true)
                            break
                        end
                        luotManHinhGY()
                    end
                    sleep(1)
                end
                tongTC_GY = tongTC_GY + daKetBan
                logScreen("📊 Nick " .. nickIndex .. " xong! Đã kết bạn: " .. daKetBan, true)
            end
        end
        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < SO_NICK_KB_GY then nghi(5, "Nghỉ đổi nick") end
        end
    end

    log("==========================================")
    logScreen("✅ HOÀN TẤT KẾT BẠN GỢI Ý", true)
    log("📊 Tổng cộng: " .. tongTC_GY .. " người")
    log("==========================================")
end

print("✅ ket_ban_goi_y.lua đã nạp")