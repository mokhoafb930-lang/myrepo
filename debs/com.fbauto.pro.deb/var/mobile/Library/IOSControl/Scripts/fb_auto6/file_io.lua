-- ================================================================
-- FILE: file_io.lua - QUẢN LÝ FILE
-- Nguồn: fb_auto_new.lua dòng 78-182
-- ================================================================

-- ========== HÀM ĐỌC NỘI DUNG TỪ FILE TXT ========== (dòng 78-103)
function readLinesFromFile(path, defaultTable)
    local f = io.open(path, "r")
    if not f then
        local fw = io.open(path, "w")
        if fw then
            for _, line in ipairs(defaultTable) do
                fw:write(line .. "\n")
            end
            fw:close()
        end
        return defaultTable
    end

    local lines = {}
    for line in f:lines() do
        local s = line:match("^%s*(.-)%s*$")
        if s and s ~= "" then
            table.insert(lines, s)
        end
    end
    f:close()

    if #lines == 0 then return defaultTable end
    return lines
end

-- ========== HÀM TẠO TẤT CẢ FILE NỘI DUNG MẪU ========== (dòng 105-146)
function taoTatCaFileNoiDung()
    readLinesFromFile(CMT_FILE_PATH, CMT_LIST)
    readLinesFromFile(POST_FILE_PATH, NOI_DUNG_BAI_VIET)
    readLinesFromFile(BIO_FILE_PATH, TIEU_SU_RANDOM)
    readLinesFromFile(CITY_FILE_PATH, DANH_SACH_THANH_PHO)
    readLinesFromFile(WORK_FILE_PATH, DANH_SACH_CONG_VIEC)
    readLinesFromFile(SCHOOL_FILE_PATH, DANH_SACH_TRUONG)
    readLinesFromFile(RELA_FILE_PATH, DANH_SACH_RELATIONSHIP)

    local systemFiles = {
        ACCOUNT_FILE, UID_FRIEND_FILE, THONG_KE_FILE, UID_LOG_FILE,
        FILE_LOG_LL, CONFIG_PATH, CONFIG_FILE_LL, TERMS_FILE, CRANE_IDX_FILE
    }

    for _, path in ipairs(systemFiles) do
        local f = io.open(path, "r")
        if not f then
            local fw = io.open(path, "w")
            if fw then 
                fw:close()
                if path == CONFIG_PATH then luuCauHinh() end
                if path == CONFIG_FILE_LL then luuCauHinhLapLich() end
            end
        else
            f:close()
        end
    end

    toast("✅ Đã tạo TOÀN BỘ file hệ thống & nội dung!")
    dialogChoice("✅ Đã tạo TOÀN BỘ file cần thiết!\n\nToàn bộ file .txt đã được tạo tại thư mục Documents. Khách có thể vào đó để dán Nick, UID hoặc chỉnh sửa nội dung bài đăng.", "Xong ✅")
end

-- ========== HÀM XÓA TẤT CẢ FILE ========== (dòng 148-182)
function xoaTatCaFile()
    local confirm = dialogChoice("⚠️ CẢNH BÁO XÓA FILE\n\nHành động này sẽ xóa sạch TOÀN BỘ file .txt trong Documents để bạn thiết lập lại từ đầu. Bạn có chắc không?", "🔥 Có, xóa sạch hết!", "◀️ Quay lại")
    if confirm and confirm:find("xóa sạch hết") then
        logScreen("🗑️ Đang quét và xóa toàn bộ file .txt...", true)
        os.execute("ls /var/mobile/Documents/ > /var/mobile/Documents/ls_files.tmp")

        local count = 0
        local f = io.open("/var/mobile/Documents/ls_files.tmp", "r")
        if f then
            for line in f:lines() do
                local fileName = line:gsub("^%s*(.-)%s*$", "%1")
                if fileName:lower():find("%.txt$") then
                    if os.remove("/var/mobile/Documents/" .. fileName) then
                        count = count + 1
                    end
                end
            end
            f:close()
        end
        os.remove("/var/mobile/Documents/ls_files.tmp")
        os.execute("rm -f /var/mobile/Documents/*.txt")

        sleep(1)
        logScreen("✅ Đã xóa sạch toàn bộ file .txt", true)
        log("✅ Da xoa sach " .. count .. " file .txt tai Documents")
        toast("🗑️ Đã dọn dẹp sạch bóng thư mục Documents!")
        return true
    end
    return false
end

print("✅ file_io.lua đã nạp")