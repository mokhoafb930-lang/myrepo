-- ================================================================
-- FILE: watch.lua - XEM WATCH / VIDEO (Module mới)
-- ================================================================

-- ========== XEM WATCH / VIDEO ==========
function xemWatch(mode)
    logScreen("🎬 BẮT ĐẦU XEM WATCH (" .. (mode or "Standalone") .. ")", true)

    openURL("fb://watch")
    log("✅ Đã mở Watch (fb://watch)")
    sleep(5)

    -- Lấy thông số theo mode
    local soLanLuot = 5
    local thoiGianMax = 10

    if mode == "FARM" then
        soLanLuot = WATCH_SL_FARM
        thoiGianMax = WATCH_TG_FARM
    elseif mode == "LH" then
        soLanLuot = WATCH_SL_LH
        thoiGianMax = WATCH_TG_LH
    else
        soLanLuot = WATCH_SL_SA
        thoiGianMax = WATCH_TG_SA
    end

    for i = 1, soLanLuot do
        logScreen("📱 Đang xem video " .. i .. "/" .. soLanLuot, true)

        -- Vuốt lên để xem video tiếp theo
        swipe(207, 600, 207, 200, 1)

        -- Chờ xem video (Random từ 3 giây đến thoiGianMax)
        local thoiGianXem = math.random(3, math.max(3, thoiGianMax))
        log("⏳ Xem trong " .. thoiGianXem .. " giây...")
        sleep(thoiGianXem)

        if _G.CO_LOI_SOMETHING then break end
    end

    logScreen("🎉 ĐÃ XEM XONG " .. soLanLuot .. " VIDEO", true)
    return true
end

-- Entry point cho Chạy lẻ
function thucHienWatch()
    logScreen("🚀 CHẠY XEM WATCH ĐỘC LẬP", true)
    local danhSachNick = layDanhSachCrane()

    local slNick = WATCH_SO_NICK or 1

    for nickIndex = 1, slNick do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = (#danhSachNick > 0) and danhSachNick[idx_in_list] or "Default"

        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. slNick .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        resetMang()
        chuyenNick(tenPhanVung)

        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            nghi(5, "Đợi Facebook ổn định")
            xemWatch("SA")
        end

        dongFacebook()
        if nickIndex < slNick then
            nghi(5, "Nghỉ đổi nick")
        end
    end
end

-- Tích hợp vào Farm logic
function farmWatch()
    if BAT_WATCH == 1 then
        xemWatch("FARM")
    end
end

print("✅ watch.lua đã nạp")