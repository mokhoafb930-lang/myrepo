-- ================================================================
-- FILE: crane_manager.lua - QUẢN LÝ PHÂN VÙNG CRANE (dòng 5917-6161 gốc)
-- ================================================================

APP_FB_CRANE = "com.facebook.Facebook"

local function notifyCrane(msg) if msg then toast(msg) log(msg) end end

local function naturalSortCrane(a, b)
    local function padDigits(s) return s:gsub("(%d+)", function(n) return string.format("%010d", tonumber(n)) end) end
    return padDigits(a:lower()) < padDigits(b:lower())
end

local function listContainersCrane(page)
    page = page or 1
    local pageSize = 100
    local tmpFile = "/var/mobile/Documents/crane_list_tmp.txt"
    os.execute(string.format("cranectl --list %s > %s", APP_FB_CRANE, tmpFile))
    local data = {}
    local f = io.open(tmpFile, "r")
    if f then
        for line in f:lines() do
            local active = line:match("^%*")
            local name = line:match("^%s*%*?%s*(.-)%s*%(") or line:match("^%s*%*?%s*(.-)%s*$")
            if name and name ~= "" and not name:find("Container") and not name:find(":") then
                table.insert(data, {name = name, active = active})
            end
        end
        f:close()
        if #data == 0 then dialogChoice("📂 DANH SÁCH\n\n⚠️ Chưa có phân vùng nào!", "Đóng") return end
        local total = #data
        local totalPages = math.ceil(total / pageSize)
        local startIdx = (page - 1) * pageSize + 1
        local endIdx = math.min(page * pageSize, total)
        local buttons = {}
        for i = startIdx, endIdx do
            local label = data[i].active and ("✓ " .. data[i].name .. " (Đang dùng)") or ("  " .. data[i].name)
            table.insert(buttons, label)
        end
        if endIdx < total then table.insert(buttons, "Trang sau ▶️") end
        if page > 1 then table.insert(buttons, "◀️ Trang trước") end
        table.insert(buttons, "Đóng ❌")
        local choice = dialogChoice(string.format("📂 DANH SÁCH PHÂN VÙNG\n(Trang %d/%d - Tổng %d)", page, totalPages, total), unpack(buttons))
        if choice == "Trang sau ▶️" then listContainersCrane(page + 1)
        elseif choice == "◀️ Trang trước" then listContainersCrane(page - 1) end
    else notifyCrane("❌ Lỗi: Không thể truy cập dữ liệu!") end
end

local function createBatchCrane()
    local prefix = dialogInput("➕ Tên Phân Vùng", "Nhập tên (ví dụ: fb)", "fb")
    if not prefix or prefix == "" then return end
    local quantity = tonumber(dialogInput("🔢 Số lượng", "Nhập số lượng:", "10"))
    if not quantity or quantity <= 0 then notifyCrane("⚠️ Số lượng không hợp lệ!") return end
    local confirm = dialogChoice(string.format("🏗️ Tạo %d phân vùng '%s1' đến '%s%d'?", quantity, prefix, prefix, quantity), "✅ Bắt đầu", "Hủy bỏ ❌")
    if confirm == "✅ Bắt đầu" then
        for i = 1, quantity do
            logScreen(string.format("⏳ Đang tạo (%d/%d): %s%d", i, quantity, prefix, i), true)
            os.execute(string.format('cranectl --create %s "%s%d"', APP_FB_CRANE, prefix, i))
            sleep(0.3)
        end
        dialogChoice("✅ Đã tạo " .. quantity .. " phân vùng!", "Tuyệt vời")
    end
end

local function wipeContainerCrane()
    local mode = dialogChoice("🧹 XÓA DỮ LIỆU", "🔥 XÓA TẤT CẢ DỮ LIỆU", "👆 Chọn xóa lẻ", "◀️ Quay lại")
    if not mode or mode:find("Quay lại") then return end
    local tmpFile = "/var/mobile/Documents/crane_list_tmp.txt"
    os.execute(string.format("cranectl --list %s > %s", APP_FB_CRANE, tmpFile))
    local names = {}
    local f = io.open(tmpFile, "r")
    if f then
        for line in f:lines() do
            local name = line:match("^%s*%*?%s*(.-)%s*%(") or line:match("^%s*%*?%s*(.-)%s*$")
            if name and name ~= "" and not name:find("Container") and not name:find(":") then table.insert(names, name) end
        end
        f:close()
    end
    if mode:find("XÓA TẤT CẢ") then
        if #names == 0 then dialogChoice("⚠️ Không có phân vùng!", "Đóng") return end
        local confirm = dialogChoice("⚠️ Xóa dữ liệu TOÀN BỘ " .. #names .. " phân vùng?", "🔥 Xóa hết!", "Hủy bỏ")
        if confirm == "🔥 Xóa hết!" then
            for i, name in ipairs(names) do
                logScreen(string.format("🧹 Xóa dữ liệu (%d/%d): %s", i, #names, name), true)
                os.execute(string.format('cranectl --wipe %s name:"%s"', APP_FB_CRANE, name)) sleep(0.2)
            end
            dialogChoice("✅ Đã làm sạch toàn bộ!", "Xong")
        end
    else
        table.insert(names, "◀️ Quay lại")
        local choice = dialogChoice("🧹 CHỌN PHÂN VÙNG", unpack(names))
        if choice and choice ~= "◀️ Quay lại" then
            os.execute(string.format('cranectl --wipe %s name:"%s"', APP_FB_CRANE, choice))
            notifyCrane("🧹 Đã xóa dữ liệu: " .. choice) wipeContainerCrane()
        end
    end
end

local function deleteContainerCrane()
    local mode = dialogChoice("🗑️ TÙY CHỌN XÓA", "🔥 XÓA TẤT CẢ", "👆 Chọn xóa từng cái", "◀️ Quay lại")
    if not mode or mode:find("Quay lại") then return end
    local tmpFile = "/var/mobile/Documents/crane_list_tmp.txt"
    os.execute(string.format("cranectl --list %s > %s", APP_FB_CRANE, tmpFile))
    local names = {}
    local f = io.open(tmpFile, "r")
    if f then
        for line in f:lines() do
            local name = line:match("^%s*(.-)%s*%(") or line:match("^%s*(.-)%s*$")
            if name and name ~= "" and not name:find("Container") and not name:find(":") and name ~= "Default" then table.insert(names, name) end
        end
        f:close()
    end
    if mode:find("XÓA TẤT CẢ") then
        if #names == 0 then dialogChoice("⚠️ Không có phân vùng!", "Đóng") return end
        local confirm = dialogChoice("⚠️ Xóa TOÀN BỘ " .. #names .. " phân vùng?", "🔥 Đồng ý!", "Hủy bỏ")
        if confirm == "🔥 Đồng ý!" then
            for i, name in ipairs(names) do
                os.execute(string.format('cranectl --delete %s name:"%s"', APP_FB_CRANE, name)) sleep(0.2)
            end
            dialogChoice("✅ Đã xóa sạch!", "Xong")
        end
    else
        table.insert(names, "◀️ Quay lại")
        local choice = dialogChoice("🗑️ CHỌN PHÂN VÙNG", unpack(names))
        if choice and choice ~= "◀️ Quay lại" then
            local confirm = dialogChoice("Xác nhận xóa: " .. choice .. "?", "🔥 Xóa ngay", "Hủy")
            if confirm == "🔥 Xóa ngay" then
                os.execute(string.format('cranectl --delete %s name:"%s"', APP_FB_CRANE, choice))
                notifyCrane("🗑️ Đã xóa: " .. choice) deleteContainerCrane()
            end
        end
    end
end

function menuCrane()
    while true do
        local choice = dialogChoice("🛠️ QUẢN LÝ PHÂN\nVÙNG CRANE",
            "📂 Danh sách phân vùng", "➕ Tạo phân vùng hàng loạt",
            "🧹 Xóa dữ liệu phân vùng", "🗑️ Xóa bỏ phân vùng", "❌ Thoát")
        if not choice or choice == "❌ Thoát" then break end
        if choice:find("Danh sách") then listContainersCrane()
        elseif choice:find("Tạo") then createBatchCrane()
        elseif choice:find("Xóa dữ liệu") then wipeContainerCrane()
        elseif choice:find("Xóa bỏ") then deleteContainerCrane() end
    end
end

print("✅ crane_manager.lua đã nạp")