-- ================================================================
-- FILE: ket_ban_uid.lua - KẾT BẠN THEO UID
-- Nguồn: fb_auto_new.lua dòng 1185-1453, 3251-3419
-- ================================================================

-- (Hàm hỗ trợ file UID đã được chuyển sang nick_manager.lua)

-- ========== MENU KẾT BẠN UID ========== (dòng 1216-1453)
function menuKetBanUID()
    while true do
        local soUIDCon = demUIDTrongFile()
        local filename = UID_FRIEND_FILE:match("([^/]+)$") or UID_FRIEND_FILE
        local title = "👤 Kết bạn theo UID\n"
            .. "· Nick: " .. SO_NICK_UID .. "  · UID/nick: " .. SO_UID_MOI_NICK .. "\n"
            .. "· Nghỉ: " .. THOI_GIAN_NGHI_UID .. "s  · Xóa UID: " .. (BAT_XOA_UID == 1 and "bật" or "tắt") .. "\n"
            .. "· Danh sách: " .. soUIDCon .. " UID  · File: " .. filename
        local choice = dialogChoice(title,
            "📋 Dán list UID kết bạn", "👁️ Xem danh sách UID", "🗑️ Xóa tất cả UID",
            "──────────────",
            "🗑️ Bật/Tắt xóa UID khi chạy", "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "👥 Đổi số nick cần chạy", "🔢 Đổi số UID mỗi nick",
            "⏳ Đổi thời gian nghỉ", "📂 Đổi đường dẫn file",
            "──────────────", "📜 Xem Log kết bạn", "🧹 Xóa Log kết bạn",
            "──────────────", "🚀 BẮT ĐẦU KẾT BẠN", "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Dán list UID") then
            local clip = getClipboard() or ""
            if clip == "" then toast("⚠️ Clipboard trống!")
            else
                local lines = {}
                for line in string.gmatch(clip, "[^\r\n]+") do
                    local uid = line:match("^%s*(.-)%s*$")
                    if uid ~= "" then table.insert(lines, uid) end
                end
                if #lines > 0 then
                    local confirm = dialogChoice("📋 PHÁT HIỆN " .. #lines .. " UID\n\nThêm toàn bộ?", "✅ Có, thêm ngay!", "◀️ Hủy")
                    if confirm and confirm:find("thêm ngay") then
                        for _, uid in ipairs(lines) do ghiUIDVaoFile(uid) end
                        toast("✅ Đã thêm " .. #lines .. " UID! Tổng: " .. demUIDTrongFile())
                    end
                else toast("⚠️ Không tìm thấy UID hợp lệ!") end
            end
        elseif choice:find("Xem danh sách") then
            local allLines = {}
            local f = io.open(UID_FRIEND_FILE, "r")
            if f then for line in f:lines() do if line ~= "" then local uid = line:match("^%s*(.-)%s*$") if uid and uid ~= "" then table.insert(allLines, uid) end end end f:close() end
            if #allLines == 0 then dialogChoice("📂 FILE UID\n\n📭 File rỗng!", "OK ✅")
            else
                local page = 1 local pageSize = 50
                while true do
                    local startIdx = (page - 1) * pageSize + 1
                    local endIdx = math.min(page * pageSize, #allLines)
                    local displayLines = {} for i = startIdx, endIdx do table.insert(displayLines, i .. ". " .. allLines[i]) end
                    local preview = table.concat(displayLines, "\n")
                    local totalPage = math.ceil(#allLines / pageSize)
                    local buttons = {"OK ✅"} if page < totalPage then table.insert(buttons, "Trang tiếp ➡️") end if page > 1 then table.insert(buttons, "⬅️ Trang trước") end
                    local c = dialogChoice("📂 DANH SÁCH UID\n📄 Trang: " .. page .. "/" .. totalPage .. "\n📊 Tổng: " .. #allLines .. " UID\n────────────────\n" .. preview, unpack(buttons))
                    if not c or c:find("OK") then break elseif c:find("Trang tiếp") then page = page + 1 elseif c:find("Trang trước") then page = page - 1 end
                end
            end
        elseif choice:find("Xóa tất cả UID") then
            if soUIDCon == 0 then toast("📭 File đã rỗng!")
            else
                local confirm = dialogChoice("🗑️ XÓA TẤT CẢ UID?\n\nSẽ xóa " .. soUIDCon .. " UID.", "🗑️ Xóa hết!", "◀️ Hủy")
                if confirm and confirm:find("Xóa hết") then
                    local f = io.open(UID_FRIEND_FILE, "w") if f then f:write("") f:close() toast("✅ Đã xóa!") end
                end
            end
        elseif choice:find("Bật/Tắt xóa UID") then BAT_XOA_UID = (BAT_XOA_UID == 1) and 0 or 1
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT:", tostring(NICK_BAT_DAU))
            if input then local num = tonumber(input) if num and num >= 0 then NICK_BAT_DAU = math.max(1, math.floor(num)) end end
        elseif choice:find("Đổi số nick") then
            local input = dialogInput("Số nick", "Hiện tại: " .. SO_NICK_UID) if input then local num = tonumber(input) if num and num > 0 then SO_NICK_UID = math.floor(num) end end
        elseif choice:find("Đổi số UID") then
            local input = dialogInput("Số UID mỗi nick", "Hiện tại: " .. SO_UID_MOI_NICK) if input then local num = tonumber(input) if num and num > 0 then SO_UID_MOI_NICK = math.floor(num) end end
        elseif choice:find("Đổi thời gian") then
            local input = dialogInput("Thời gian nghỉ (giây)", "Hiện tại: " .. THOI_GIAN_NGHI_UID) if input then local num = tonumber(input) if num and num > 0 then THOI_GIAN_NGHI_UID = math.floor(num) end end
        elseif choice:find("Đổi đường dẫn") then
            local input = dialogInput("Đường dẫn file UID", "Hiện tại: " .. UID_FRIEND_FILE) if input and input ~= "" then UID_FRIEND_FILE = input end
        elseif choice:find("Xem Log") then
            local f = io.open(UID_LOG_FILE, "r")
            if not f then dialogChoice("📜 LOG\n\n❌ Chưa có log!", "OK ✅")
            else
                local lines = {} for line in f:lines() do table.insert(lines, line) if #lines > 100 then table.remove(lines, 1) end end f:close()
                if #lines == 0 then dialogChoice("📜 LOG\n\n📭 Log rỗng!", "OK ✅")
                else dialogChoice("📜 LOG KẾT BẠN (100 dòng mới nhất)\n\n" .. table.concat(lines, "\n"), "OK ✅") end
            end
        elseif choice:find("Xóa Log") then
            local confirm = dialogChoice("🧹 XÓA LOG?", "🗑️ Xóa hết!", "◀️ Hủy")
            if confirm and confirm:find("Xóa hết") then local f = io.open(UID_LOG_FILE, "w") if f then f:close() end toast("✅ Đã xóa log!") end
        elseif choice:find("BẮT ĐẦU KẾT BẠN") then
            if soUIDCon == 0 then toast("⚠️ Danh sách rỗng!")
            else
                local confirm = dialogChoice("🚀 XÁC NHẬN\n\n👥 Chạy: " .. SO_NICK_UID .. " nick\n🔢 Mỗi nick: " .. SO_UID_MOI_NICK .. " UID\n⏳ Nghỉ: " .. THOI_GIAN_NGHI_UID .. "s", "✅ Chạy ngay!", "◀️ Quay lại")
                if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "ket_ban_uid" end
            end
        end
    end
end

-- ========== ĐỌC UID ĐẦU TIÊN VÀ XÓA KHỎI FILE ==========
local function layUIDVaXoa()
    log("📂 Đang cập nhật tệp UID...")
    local file = io.open(UID_FRIEND_FILE, "r")
    if not file then return nil end

    local content = file:read("*all")
    file:close()

    if not content or content == "" then return nil end

    local allLines = {}
    for line in string.gmatch(content, "[^\r\n]+") do
        if line ~= "" then table.insert(allLines, line) end
    end

    if #allLines == 0 then return nil end

    local firstLine = allLines[1]:match("^%s*(.-)%s*$")

    local remaining = {}
    for i = 2, #allLines do
        table.insert(remaining, allLines[i])
    end

    local newContent = table.concat(remaining, "\n")
    if newContent ~= "" then newContent = newContent .. "\n" end

    local fileWrite = io.open(UID_FRIEND_FILE, "w")
    if fileWrite then
        fileWrite:write(newContent)
        fileWrite:close()
    end

    return firstLine
end

-- ========== KIỂM TRA CÒN UID ==========
local function conUID()
    local file = io.open(UID_FRIEND_FILE, "r")
    if not file then return false end
    local content = file:read("*all")
    file:close()
    if not content or content == "" then return false end
    for line in string.gmatch(content, "[^\r\n]+") do
        if line ~= "" then return true end
    end
    return false
end

-- ========== HÀM THỰC HIỆN KẾT BẠN UID ==========
function thucHienKetBanUID()
    logScreen("🚀 BẮT ĐẦU KẾT BẠN UID", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + SO_NICK_UID), true)
    log("📂 File: " .. UID_FRIEND_FILE)
    log("👥 Chạy: " .. SO_NICK_UID .. " nick | " .. SO_UID_MOI_NICK .. " UID/nick")

    local ALL_UIDS_F = {}
    local f_uid = io.open(UID_FRIEND_FILE, "r")
    if f_uid then
        for line in f_uid:lines() do
            local u = line:match("^%s*(.-)%s*$")
            if u and u ~= "" then table.insert(ALL_UIDS_F, u) end
        end
        f_uid:close()
    end

    local uidCurrentIdx = 1
    local tongTC = 0
    local tongTB = 0
    local tongLoi = 0

    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, SO_NICK_UID do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end

        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. SO_NICK_UID .. " | 📂 " .. tenPhanVung, true)

        if uidCurrentIdx > #ALL_UIDS_F then
            log("⚠️ Da het UID trong danh sach!")
            break
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            chuyenNick(tenPhanVung)
        end

        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            nghi(10, "Đợi Facebook ổn định")

            local tcNick = 0
            local tbNick = 0
            local loiNick = 0

            for uidIndex = 1, SO_UID_MOI_NICK do
                if uidCurrentIdx > #ALL_UIDS_F then break end

                local uid = ALL_UIDS_F[uidCurrentIdx]
                uidCurrentIdx = uidCurrentIdx + 1

                if BAT_XOA_UID == 1 then layUIDVaXoa() end

                log("")
                log("👉 Nick " .. nickIndex .. " | UID " .. uidIndex .. "/" .. SO_UID_MOI_NICK .. ": " .. uid)
                -- Hiện tiến độ lên màn hình (gọn để không che nút bấm)
                logScreen("📊 Nick " .. nickIndex .. "/" .. SO_NICK_UID .. " | UID " .. uidIndex .. "/" .. SO_UID_MOI_NICK, true)
                sleep(0.5)
                openURL("fb://profile/" .. uid)
                sleep(3)

                if findText("Add Friend") then
                    tapText("Add Friend", 10, 1)
                    sleep(3)

                    if findImage("crop_1776840175322.png", 1, 1) then
                        logScreen("❌ Bị chặn! (" .. uidIndex .. "/" .. SO_UID_MOI_NICK .. ")", true)
                        log("❌ LỖI BLOCK/ERROR")
                        loiNick = loiNick + 1
                        ghiLogUID("Nick " .. nickIndex .. " | UID " .. uid .. " | Loi: Blocks")
                        if findText("OK") then tapText("OK", 10, 1) sleep(2) end
                    else
                        logScreen("✅ TC: " .. (tcNick+1) .. " | UID " .. uidIndex .. "/" .. SO_UID_MOI_NICK, true)
                        tcNick = tcNick + 1
                        ghiLogUID("Nick " .. nickIndex .. " | UID " .. uid .. " | Thanh Cong")
                    end

                    -- KHÔI PHỤC: Kiểm tra nút Back to Profile để thoát màn hình thông báo
                    local hasBack = findImage("crop_1776839126664.png", 1, 0.9)
                    if hasBack or findText("Back to Profile") then
                        log("🔄 Tìm thấy nút Back, đang quay lại...")
                        tapText("Back to Profile", 10, 1)
                        sleep(2)
                    end
                else
                    logScreen("⚠️ Không thấy Thêm bạn (" .. uidIndex .. "/" .. SO_UID_MOI_NICK .. ")", true)
                    tbNick = tbNick + 1
                    ghiLogUID("Nick " .. nickIndex .. " | UID " .. uid .. " | That Bai (No Add Friend)")
                end

                if uidIndex < SO_UID_MOI_NICK and conUID() then
                    nghi(THOI_GIAN_NGHI_UID, "Nghỉ đợi mở UID tiếp theo")
                end
            end

            log("")
            logScreen("📊 Kết quả Nick " .. nickIndex .. ": TC " .. tcNick .. " | Lỗi " .. loiNick, true)
            tongTC = tongTC + tcNick
            tongTB = tongTB + tbNick
            tongLoi = tongLoi + loiNick
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < SO_NICK_UID and conUID() then
                nghi(5, "Nghỉ đổi nick")
            end
        end
    end

    log("")
    log("==========================================")
    logScreen("✅ HOÀN TẤT KẾT BẠN UID\n📊 Tổng TC: " .. tongTC .. " | Lỗi: " .. tongLoi, true)
    log("==========================================")
end

print("✅ ket_ban_uid.lua đã nạp")