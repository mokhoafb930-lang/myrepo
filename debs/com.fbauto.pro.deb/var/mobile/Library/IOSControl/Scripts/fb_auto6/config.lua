-- ================================================================
-- FILE: config.lua - TẤT CẢ BIẾN & GUI MENU & LƯU/TẢI CONFIG
-- Nguồn: fb_auto_new.lua dòng 386-800
-- ================================================================

-- ========== CÀI ĐẶT MẶC ĐỊNH (FARM) ==========
SO_LAN_LAP = 2
THOI_GIAN_NGHI = 10
NICK_BAT_DAU = 1

-- ========== CÀI ĐẶT MẶC ĐỊNH (THAM GIA NHÓM UID) ==========
GROUP_UID_FILE = "/var/mobile/Documents/fb_join_group.txt"
GROUP_LOG_FILE = "/var/mobile/Documents/fb_join_group_log.txt"
-- 1. JOIN GROUP STANDALONE (Chạy lẻ)
JG_SO_NICK = 1
JG_SL_SA = 5
JG_TG_SA = 30
BAT_XOA_UID_NHOM = 1

-- 2. JOIN GROUP LIÊN HOÀN (Tổng hợp)
JG_SL_LH = 2
JG_TG_LH = 45
BAT_LH_JOIN_GROUP = 0

-- 2.1 LƯỚT NEWSFEED CÓ LIKE (Liên hoàn)
BAT_LH_LUOT_LIKE = 0
LH_NF_LIKE_SO_BAI = 50
LH_NF_LIKE_SO_LIKE = 10
LH_NF_LIKE_NGHI = 2

-- ========== THÔNG KÊ & LOG ==========
BAT_AVATAR = 0
BAT_ANH_BIA = 0
BAT_DANG_BAI = 1
BAT_DANG_BAI_TEXT = 0
BAT_DANG_STORY = 0
BAT_LUOT_NEWSFEED = 0
BAT_EDIT_PROFILE = 1
BAT_WATCH = 0
SO_LAN_LUOT = 10
THOI_GIAN_LUOT = 2

-- 1. WATCH STANDALONE (Chạy lẻ ngoài Menu)
WATCH_SL_SA = 5
WATCH_TG_SA = 10
WATCH_NICK_SA = 1

-- 2. WATCH FARM (Trong Nuôi nick)
WATCH_SL_FARM = 2
WATCH_TG_FARM = 15

-- 3. WATCH LIÊN HOÀN (Trong Tổng hợp)
WATCH_SL_LH = 3
WATCH_TG_LH = 20

-- 4. BIẾN DÙNG CHUNG / MẶC ĐỊNH
WATCH_SO_LUONG = 2
WATCH_THOI_GIAN = 15
WATCH_SO_NICK = 1

-- ========== CÀI ĐẶT MẶC ĐỊNH (NẠP NICK) ==========
SO_NICK_CAN_DANG_NHAP = 10

-- ========== CÀI ĐẶT MẶC ĐỊNH (KẾT BẠN UID) ==========
THOI_GIAN_NGHI_UID = 15
SO_NICK_UID = 2
SO_UID_MOI_NICK = 5
BAT_XOA_UID = 1

-- ========== CÀI ĐẶT MẶC ĐỊNH (KẾT BẠN GỢI Ý) ==========
SO_LUONG_KB_GY = 20
DELAY_KB_GY = 15
MAX_LUOT_KB_GY = 5
SO_NICK_KB_GY = 2

-- ========== CÀI ĐẶT MẶC ĐỊNH (CHẤP NHẬN KẾT BẠN) ==========
SO_NICK_CNKB = 2
DELAY_CNKB = 2
MAX_LUOT_CNKB = 3

-- ========== CÀI ĐẶT MẶC ĐỊNH (TƯƠNG TÁC BÀI VIẾT) ==========
INTERACT_URL = ""
INTERACT_NICKS = 1
INTERACT_RANDOM = 0
INTERACT_LIKE = 0
INTERACT_TYM = 0
INTERACT_THUONG = 0
INTERACT_HAHA = 0
INTERACT_BUON = 1
INTERACT_MAX_ATTEMPTS = 10
INTERACT_SCROLL_DELAY = 2

-- ========== CÀI ĐẶT MẶC ĐỊNH (CMT BÀI VIẾT CHỈ ĐỊNH) ==========
CMT_URL = ""
CMT_SO_NICK = 1
CMT_MODE = "random"
CMT_MAX_ATTEMPTS = 10
CMT_MAX_RETRY_POST = 3
CMT_SCROLL_DELAY = 2
CMT_TAP_DELAY = 5
CMT_CURRENT_INDEX = 1

-- ========== CÀI ĐẶT MẶC ĐỊNH (CHIA SẺ BÀI VIẾT) ==========
SHARE_URL = ""
SHARE_SO_NICK = 1
SHARE_MAX_ATTEMPTS = 10
SHARE_SCROLL_DELAY = 2
SHARE_TAP_DELAY = 5
SHARE_MAX_CHECK = 5

-- ========== BIẾN TỔNG HỢP & LỊCH TRÌNH ==========
BAT_LH_FARM = 0
BAT_LH_KBUID = 0
BAT_LH_KBGY = 0
BAT_LH_CNKB = 0
BAT_LH_NAP = 0
BAT_LH_CMT = 0
BAT_LH_SHARE = 0
BAT_LH_INTERACT = 0
BAT_LH_TEXT = 0
BAT_LH_WATCH = 0
LH_SO_NICK = 10

-- ========== BIẾN LỊCH TRÌNH (SCHEDULE) ==========
SO_NICK_CHAY_LAN = 10
SO_LUOT_CHAY_VONG = 1
THOI_GIAN_NGHI_VONG = 300
SO_PHUT_RESET_LUONG = 30
SO_PHUT_DOI_IP_LAN = 0
SCHEDULE_LOG_FILE = "/var/mobile/Documents/schedule_log.txt"
DANG_CHAY_LICH_TRINH = false
STOP_SCHEDULE = false
_G.CO_LOI_SOMETHING = false

-- ========== ĐƯỜNG DẪN FILE HỆ THỐNG ==========
ACCOUNT_FILE     = "/var/mobile/Documents/nick.txt"
THONG_KE_FILE    = "/var/mobile/Documents/thongke.txt"
UID_FRIEND_FILE  = "/var/mobile/Documents/uid_friend.txt"
UID_LOG_FILE     = "/var/mobile/Documents/uid_ket_ban_log.txt"
CONFIG_PATH      = "/var/mobile/Documents/fb_auto_config.txt"
TERMS_FILE       = "/var/mobile/Documents/terms_accepted.txt"

-- ========== ĐƯỜNG DẪN FILE NỘI DUNG ==========
CMT_FILE_PATH    = "/var/mobile/Documents/cmt_content.txt"
POST_FILE_PATH   = "/var/mobile/Documents/post_content.txt"
BIO_FILE_PATH    = "/var/mobile/Documents/bio_content.txt"
CITY_FILE_PATH   = "/var/mobile/Documents/city_content.txt"
WORK_FILE_PATH   = "/var/mobile/Documents/work_content.txt"
SCHOOL_FILE_PATH = "/var/mobile/Documents/school_content.txt"
RELA_FILE_PATH   = "/var/mobile/Documents/rela_content.txt"

-- ========== GUI MENU SETTINGS ==========
GUI_FEATURES = {
    {"🖼️ Avatar",         "BAT_AVATAR"},
    {"🖼️ Ảnh bìa",        "BAT_ANH_BIA"},
    {"📝 Đăng bài (Ảnh+Text)", "BAT_DANG_BAI"},
    {"📝 Đăng bài (Chỉ Text)", "BAT_DANG_BAI_TEXT"},
    {"📸 Đăng Story",      "BAT_DANG_STORY"},
    {"📜 Lướt Newsfeed",   "BAT_LUOT_NEWSFEED"},
    {"✏️ Edit Profile",    "BAT_EDIT_PROFILE"},
    {"🎬 Xem Watch",      "BAT_WATCH"},
}

GUI_SETTINGS = {
    {"Số lần lặp",         "SO_LAN_LAP",     "lần"},
    {"Thời gian nghỉ",     "THOI_GIAN_NGHI", "giây"},
    {"Số lần lướt NF",     "SO_LAN_LUOT",    "lần"},
    {"TG giữa lần lướt",   "THOI_GIAN_LUOT", "giây"},
    {"Số video Watch",     "WATCH_SO_LUONG", "video"},
    {"TG xem Watch tối đa","WATCH_THOI_GIAN", "giây"},
    {"Nick bắt đầu từ",    "NICK_BAT_DAU",   "STT"},
}

-- ========== HÀM ĐỌC/GHI GIÁ TRỊ BIẾN ==========
function layGiaTri(ten)
    if ten == "BAT_AVATAR" then return BAT_AVATAR
    elseif ten == "BAT_ANH_BIA" then return BAT_ANH_BIA
    elseif ten == "BAT_DANG_BAI" then return BAT_DANG_BAI
    elseif ten == "BAT_DANG_BAI_TEXT" then return BAT_DANG_BAI_TEXT
    elseif ten == "BAT_DANG_STORY" then return BAT_DANG_STORY
    elseif ten == "BAT_LUOT_NEWSFEED" then return BAT_LUOT_NEWSFEED
    elseif ten == "BAT_EDIT_PROFILE" then return BAT_EDIT_PROFILE
    elseif ten == "SO_LAN_LAP" then return SO_LAN_LAP
    elseif ten == "THOI_GIAN_NGHI" then return THOI_GIAN_NGHI
    elseif ten == "SO_LAN_LUOT" then return SO_LAN_LUOT
    elseif ten == "THOI_GIAN_LUOT" then return THOI_GIAN_LUOT
    elseif ten == "SO_NICK_CAN_DANG_NHAP" then return SO_NICK_CAN_DANG_NHAP
    elseif ten == "SO_NICK_UID" then return SO_NICK_UID
    elseif ten == "SO_UID_MOI_NICK" then return SO_UID_MOI_NICK
    elseif ten == "BAT_XOA_UID" then return BAT_XOA_UID
    elseif ten == "SO_LUONG_KB_GY" then return SO_LUONG_KB_GY
    elseif ten == "DELAY_KB_GY" then return DELAY_KB_GY
    elseif ten == "MAX_LUOT_KB_GY" then return MAX_LUOT_KB_GY
    elseif ten == "SO_NICK_KB_GY" then return SO_NICK_KB_GY
    elseif ten == "SO_NICK_CNKB" then return SO_NICK_CNKB
    elseif ten == "DELAY_CNKB" then return DELAY_CNKB
    elseif ten == "MAX_LUOT_CNKB" then return MAX_LUOT_CNKB
    elseif ten == "INTERACT_NICKS" then return INTERACT_NICKS
    elseif ten == "INTERACT_RANDOM" then return INTERACT_RANDOM
    elseif ten == "INTERACT_LIKE" then return INTERACT_LIKE
    elseif ten == "INTERACT_TYM" then return INTERACT_TYM
    elseif ten == "INTERACT_THUONG" then return INTERACT_THUONG
    elseif ten == "INTERACT_HAHA" then return INTERACT_HAHA
    elseif ten == "INTERACT_BUON" then return INTERACT_BUON
    elseif ten == "INTERACT_MAX_ATTEMPTS" then return INTERACT_MAX_ATTEMPTS
    elseif ten == "INTERACT_SCROLL_DELAY" then return INTERACT_SCROLL_DELAY
    elseif ten == "CMT_SO_NICK" then return CMT_SO_NICK
    elseif ten == "CMT_MAX_ATTEMPTS" then return CMT_MAX_ATTEMPTS
    elseif ten == "CMT_SCROLL_DELAY" then return CMT_SCROLL_DELAY
    elseif ten == "SHARE_SO_NICK" then return SHARE_SO_NICK
    elseif ten == "SHARE_MAX_ATTEMPTS" then return SHARE_MAX_ATTEMPTS
    elseif ten == "SHARE_SCROLL_DELAY" then return SHARE_SCROLL_DELAY
    elseif ten == "SHARE_TAP_DELAY" then return SHARE_TAP_DELAY
    elseif ten == "SHARE_MAX_CHECK" then return SHARE_MAX_CHECK
    elseif ten == "BAT_WATCH" then return BAT_WATCH
    elseif ten == "NICK_BAT_DAU" then return NICK_BAT_DAU
    elseif ten == "WATCH_SL_SA" then return WATCH_SL_SA
    elseif ten == "WATCH_TG_SA" then return WATCH_TG_SA
    elseif ten == "WATCH_NICK_SA" then return WATCH_NICK_SA
    elseif ten == "WATCH_SL_FARM" then return WATCH_SL_FARM
    elseif ten == "WATCH_TG_FARM" then return WATCH_TG_FARM
    elseif ten == "WATCH_SL_LH" then return WATCH_SL_LH
    elseif ten == "WATCH_TG_LH" then return WATCH_TG_LH
    elseif ten == "JG_SO_NICK" then return JG_SO_NICK
    elseif ten == "JG_SL_SA" then return JG_SL_SA
    elseif ten == "JG_TG_SA" then return JG_TG_SA
    elseif ten == "JG_SL_LH" then return JG_SL_LH
    elseif ten == "JG_TG_LH" then return JG_TG_LH
    elseif ten == "BAT_LH_JOIN_GROUP" then return BAT_LH_JOIN_GROUP
    elseif ten == "BAT_XOA_UID_NHOM" then return BAT_XOA_UID_NHOM
    elseif ten == "BAT_LH_FARM" then return BAT_LH_FARM
    elseif ten == "BAT_LH_KBUID" then return BAT_LH_KBUID
    elseif ten == "BAT_LH_KBGY" then return BAT_LH_KBGY
    elseif ten == "BAT_LH_CNKB" then return BAT_LH_CNKB
    elseif ten == "BAT_LH_CMT" then return BAT_LH_CMT
    elseif ten == "BAT_LH_SHARE" then return BAT_LH_SHARE
    elseif ten == "BAT_LH_INTERACT" then return BAT_LH_INTERACT
    elseif ten == "BAT_LH_TEXT" then return BAT_LH_TEXT
    elseif ten == "BAT_LH_WATCH" then return BAT_LH_WATCH
    elseif ten == "LH_SO_NICK" then return LH_SO_NICK
    elseif ten == "WATCH_SO_LUONG" then return WATCH_SO_LUONG
    elseif ten == "WATCH_THOI_GIAN" then return WATCH_THOI_GIAN
    elseif ten == "WATCH_SO_NICK" then return WATCH_SO_NICK
    elseif ten == "BAT_LH_LUOT_LIKE" then return BAT_LH_LUOT_LIKE
    elseif ten == "LH_NF_LIKE_SO_BAI" then return LH_NF_LIKE_SO_BAI
    elseif ten == "LH_NF_LIKE_SO_LIKE" then return LH_NF_LIKE_SO_LIKE
    elseif ten == "LH_NF_LIKE_NGHI" then return LH_NF_LIKE_NGHI
    end
    return _G[ten] or 0
end

function ganGiaTri(ten, giaTri)
    if ten == "BAT_AVATAR" then BAT_AVATAR = giaTri
    elseif ten == "BAT_ANH_BIA" then BAT_ANH_BIA = giaTri
    elseif ten == "BAT_DANG_BAI" then BAT_DANG_BAI = giaTri
    elseif ten == "BAT_DANG_BAI_TEXT" then BAT_DANG_BAI_TEXT = giaTri
    elseif ten == "BAT_DANG_STORY" then BAT_DANG_STORY = giaTri
    elseif ten == "BAT_LUOT_NEWSFEED" then BAT_LUOT_NEWSFEED = giaTri
    elseif ten == "BAT_EDIT_PROFILE" then BAT_EDIT_PROFILE = giaTri
    elseif ten == "SO_LAN_LAP" then SO_LAN_LAP = giaTri
    elseif ten == "THOI_GIAN_NGHI" then THOI_GIAN_NGHI = giaTri
    elseif ten == "SO_LAN_LUOT" then SO_LAN_LUOT = giaTri
    elseif ten == "THOI_GIAN_LUOT" then THOI_GIAN_LUOT = giaTri
    elseif ten == "SO_NICK_CAN_DANG_NHAP" then SO_NICK_CAN_DANG_NHAP = giaTri
    elseif ten == "SO_NICK_UID" then SO_NICK_UID = giaTri
    elseif ten == "SO_UID_MOI_NICK" then SO_UID_MOI_NICK = giaTri
    elseif ten == "BAT_XOA_UID" then BAT_XOA_UID = giaTri
    elseif ten == "SO_LUONG_KB_GY" then SO_LUONG_KB_GY = giaTri
    elseif ten == "DELAY_KB_GY" then DELAY_KB_GY = giaTri
    elseif ten == "MAX_LUOT_KB_GY" then MAX_LUOT_KB_GY = giaTri
    elseif ten == "SO_NICK_KB_GY" then SO_NICK_KB_GY = giaTri
    elseif ten == "SO_NICK_CNKB" then SO_NICK_CNKB = giaTri
    elseif ten == "DELAY_CNKB" then DELAY_CNKB = giaTri
    elseif ten == "MAX_LUOT_CNKB" then MAX_LUOT_CNKB = giaTri
    elseif ten == "INTERACT_NICKS" then INTERACT_NICKS = giaTri
    elseif ten == "INTERACT_RANDOM" then INTERACT_RANDOM = giaTri
    elseif ten == "INTERACT_LIKE" then INTERACT_LIKE = giaTri
    elseif ten == "INTERACT_TYM" then INTERACT_TYM = giaTri
    elseif ten == "INTERACT_THUONG" then INTERACT_THUONG = giaTri
    elseif ten == "INTERACT_HAHA" then INTERACT_HAHA = giaTri
    elseif ten == "INTERACT_BUON" then INTERACT_BUON = giaTri
    elseif ten == "INTERACT_MAX_ATTEMPTS" then INTERACT_MAX_ATTEMPTS = giaTri
    elseif ten == "INTERACT_SCROLL_DELAY" then INTERACT_SCROLL_DELAY = giaTri
    elseif ten == "CMT_SO_NICK" then CMT_SO_NICK = giaTri
    elseif ten == "CMT_MAX_ATTEMPTS" then CMT_MAX_ATTEMPTS = giaTri
    elseif ten == "CMT_SCROLL_DELAY" then CMT_SCROLL_DELAY = giaTri
    elseif ten == "SHARE_SO_NICK" then SHARE_SO_NICK = giaTri
    elseif ten == "SHARE_MAX_ATTEMPTS" then SHARE_MAX_ATTEMPTS = giaTri
    elseif ten == "SHARE_SCROLL_DELAY" then SHARE_SCROLL_DELAY = giaTri
    elseif ten == "SHARE_TAP_DELAY" then SHARE_TAP_DELAY = giaTri
    elseif ten == "SHARE_MAX_CHECK" then SHARE_MAX_CHECK = giaTri
    elseif ten == "NICK_BAT_DAU" then NICK_BAT_DAU = giaTri
    elseif ten == "BAT_WATCH" then BAT_WATCH = giaTri
    elseif ten == "WATCH_SL_SA" then WATCH_SL_SA = giaTri
    elseif ten == "WATCH_TG_SA" then WATCH_TG_SA = giaTri
    elseif ten == "WATCH_NICK_SA" then WATCH_NICK_SA = giaTri
    elseif ten == "WATCH_SL_FARM" then WATCH_SL_FARM = giaTri
    elseif ten == "WATCH_TG_FARM" then WATCH_TG_FARM = giaTri
    elseif ten == "WATCH_SL_LH" then WATCH_SL_LH = giaTri
    elseif ten == "WATCH_TG_LH" then WATCH_TG_LH = giaTri
    elseif ten == "JG_SO_NICK" then JG_SO_NICK = giaTri
    elseif ten == "JG_SL_SA" then JG_SL_SA = giaTri
    elseif ten == "JG_TG_SA" then JG_TG_SA = giaTri
    elseif ten == "JG_SL_LH" then JG_SL_LH = giaTri
    elseif ten == "JG_TG_LH" then JG_TG_LH = giaTri
    elseif ten == "BAT_LH_JOIN_GROUP" then BAT_LH_JOIN_GROUP = giaTri
    elseif ten == "BAT_XOA_UID_NHOM" then BAT_XOA_UID_NHOM = giaTri
    elseif ten == "BAT_LH_FARM" then BAT_LH_FARM = giaTri
    elseif ten == "BAT_LH_KBUID" then BAT_LH_KBUID = giaTri
    elseif ten == "BAT_LH_KBGY" then BAT_LH_KBGY = giaTri
    elseif ten == "BAT_LH_CNKB" then BAT_LH_CNKB = giaTri
    elseif ten == "BAT_LH_CMT" then BAT_LH_CMT = giaTri
    elseif ten == "BAT_LH_SHARE" then BAT_LH_SHARE = giaTri
    elseif ten == "BAT_LH_INTERACT" then BAT_LH_INTERACT = giaTri
    elseif ten == "BAT_LH_TEXT" then BAT_LH_TEXT = giaTri
    elseif ten == "BAT_LH_WATCH" then BAT_LH_WATCH = giaTri
    elseif ten == "LH_SO_NICK" then LH_SO_NICK = giaTri
    elseif ten == "WATCH_SO_LUONG" then WATCH_SO_LUONG = giaTri
    elseif ten == "WATCH_THOI_GIAN" then WATCH_THOI_GIAN = giaTri
    elseif ten == "WATCH_SO_NICK" then WATCH_SO_NICK = giaTri
    elseif ten == "BAT_LH_LUOT_LIKE" then BAT_LH_LUOT_LIKE = giaTri
    elseif ten == "LH_NF_LIKE_SO_BAI" then LH_NF_LIKE_SO_BAI = giaTri
    elseif ten == "LH_NF_LIKE_SO_LIKE" then LH_NF_LIKE_SO_LIKE = giaTri
    elseif ten == "LH_NF_LIKE_NGHI" then LH_NF_LIKE_NGHI = giaTri
    else _G[ten] = giaTri end
end

-- ========== LƯU/TẢI CẤU HÌNH ==========
function luuCauHinh()
    local f = io.open(CONFIG_PATH, "w")
    if not f then
        toast("❌ Không thể lưu file!")
        return false
    end
    for _, feat in ipairs(GUI_FEATURES) do
        f:write(feat[2] .. "=" .. tostring(layGiaTri(feat[2])) .. "\n")
    end
    for _, setting in ipairs(GUI_SETTINGS) do
        f:write(setting[2] .. "=" .. tostring(layGiaTri(setting[2])) .. "\n")
    end
    f:write("SO_NICK_CAN_DANG_NHAP=" .. tostring(SO_NICK_CAN_DANG_NHAP) .. "\n")
    f:write("SO_NICK_UID=" .. tostring(SO_NICK_UID) .. "\n")
    f:write("SO_UID_MOI_NICK=" .. tostring(SO_UID_MOI_NICK) .. "\n")
    f:write("BAT_XOA_UID=" .. tostring(BAT_XOA_UID) .. "\n")
    f:write("SO_LUONG_KB_GY=" .. tostring(SO_LUONG_KB_GY) .. "\n")
    f:write("DELAY_KB_GY=" .. tostring(DELAY_KB_GY) .. "\n")
    f:write("MAX_LUOT_KB_GY=" .. tostring(MAX_LUOT_KB_GY) .. "\n")
    f:write("SO_NICK_KB_GY=" .. tostring(SO_NICK_KB_GY) .. "\n")
    f:write("SO_NICK_CNKB=" .. tostring(SO_NICK_CNKB) .. "\n")
    f:write("DELAY_CNKB=" .. tostring(DELAY_CNKB) .. "\n")
    f:write("MAX_LUOT_CNKB=" .. tostring(MAX_LUOT_CNKB) .. "\n")
    f:write("INTERACT_URL=" .. INTERACT_URL .. "\n")
    f:write("INTERACT_NICKS=" .. tostring(INTERACT_NICKS) .. "\n")
    f:write("INTERACT_RANDOM=" .. tostring(INTERACT_RANDOM) .. "\n")
    f:write("INTERACT_LIKE=" .. tostring(INTERACT_LIKE) .. "\n")
    f:write("INTERACT_TYM=" .. tostring(INTERACT_TYM) .. "\n")
    f:write("INTERACT_THUONG=" .. tostring(INTERACT_THUONG) .. "\n")
    f:write("INTERACT_HAHA=" .. tostring(INTERACT_HAHA) .. "\n")
    f:write("INTERACT_BUON=" .. tostring(INTERACT_BUON) .. "\n")
    f:write("INTERACT_MAX_ATTEMPTS=" .. tostring(INTERACT_MAX_ATTEMPTS) .. "\n")
    f:write("INTERACT_SCROLL_DELAY=" .. tostring(INTERACT_SCROLL_DELAY) .. "\n")
    f:write("CMT_URL=" .. CMT_URL .. "\n")
    f:write("CMT_SO_NICK=" .. tostring(CMT_SO_NICK) .. "\n")
    f:write("CMT_MODE=" .. CMT_MODE .. "\n")
    f:write("CMT_MAX_ATTEMPTS=" .. tostring(CMT_MAX_ATTEMPTS) .. "\n")
    f:write("CMT_SCROLL_DELAY=" .. tostring(CMT_SCROLL_DELAY) .. "\n")
    f:write("SHARE_URL=" .. SHARE_URL .. "\n")
    f:write("SHARE_SO_NICK=" .. tostring(SHARE_SO_NICK) .. "\n")
    f:write("SHARE_MAX_ATTEMPTS=" .. tostring(SHARE_MAX_ATTEMPTS) .. "\n")
    f:write("SHARE_SCROLL_DELAY=" .. tostring(SHARE_SCROLL_DELAY) .. "\n")
    f:write("SHARE_TAP_DELAY=" .. tostring(SHARE_TAP_DELAY) .. "\n")
    f:write("SHARE_MAX_CHECK=" .. tostring(SHARE_MAX_CHECK) .. "\n")
    f:write("BAT_LH_FARM=" .. tostring(BAT_LH_FARM) .. "\n")
    f:write("BAT_LH_KBUID=" .. tostring(BAT_LH_KBUID) .. "\n")
    f:write("BAT_LH_KBGY=" .. tostring(BAT_LH_KBGY) .. "\n")
    f:write("BAT_LH_CNKB=" .. tostring(BAT_LH_CNKB) .. "\n")
    f:write("BAT_LH_CMT=" .. tostring(BAT_LH_CMT) .. "\n")
    f:write("BAT_LH_SHARE=" .. tostring(BAT_LH_SHARE) .. "\n")
    f:write("BAT_LH_INTERACT=" .. tostring(BAT_LH_INTERACT) .. "\n")
    f:write("BAT_LH_TEXT=" .. tostring(BAT_LH_TEXT) .. "\n")
    f:write("BAT_LH_WATCH=" .. tostring(BAT_LH_WATCH) .. "\n")
    f:write("LH_SO_NICK=" .. tostring(LH_SO_NICK) .. "\n")
    f:write("LH_NF_LIKE_NGHI=" .. tostring(LH_NF_LIKE_NGHI) .. "\n")
    f:write("JG_SO_NICK=" .. tostring(JG_SO_NICK) .. "\n")
    f:write("WATCH_SO_NICK=" .. tostring(WATCH_SO_NICK) .. "\n")
    f:write("ACCOUNT_FILE=" .. ACCOUNT_FILE .. "\n")
    f:write("UID_FRIEND_FILE=" .. UID_FRIEND_FILE .. "\n")
    f:close()
    toast("✅ Đã lưu cấu hình!")
    log("💾 Da luu config vao: " .. CONFIG_PATH)
    return true
end

function taiCauHinh()
    local f = io.open(CONFIG_PATH, "r")
    if not f then
        toast("⚠️ Chưa có cấu hình đã lưu!")
        return false
    end
    for line in f:lines() do
        local key, value = line:match("^([^=]+)=(.+)$")
        if key and value then
            key = key:match("^%s*(.-)%s*$")
            value = value:match("^%s*(.-)%s*$")
            if key == "ACCOUNT_FILE" then ACCOUNT_FILE = value
            elseif key == "UID_FRIEND_FILE" then UID_FRIEND_FILE = value
            elseif key == "CMT_URL" then CMT_URL = value
            elseif key == "SHARE_URL" then SHARE_URL = value
            elseif key == "INTERACT_URL" then INTERACT_URL = value
            elseif key == "CMT_MODE" then CMT_MODE = value
            else
                local num = tonumber(value)
                if num then ganGiaTri(key, num) end
            end
        end
    end
    f:close()
    toast("✅ Đã tải cấu hình!")
    log("📂 Da tai config tu: " .. CONFIG_PATH)
    return true
end

-- ========== TẠO CHUỖI TÓM TẮT CẤU HÌNH ==========
function tomTatCauHinh()
    local lines = {}
    table.insert(lines, "── CHỨC NĂNG FARM ──")
    for _, feat in ipairs(GUI_FEATURES) do
        local val = layGiaTri(feat[2])
        local status = (val == 1) and "✅ BẬT" or "❌ TẮT"
        table.insert(lines, feat[1] .. ": " .. status)
    end
    table.insert(lines, "")
    table.insert(lines, "── THÔNG SỐ FARM ──")
    for _, setting in ipairs(GUI_SETTINGS) do
        table.insert(lines, "🔢 " .. setting[1] .. ": " .. layGiaTri(setting[2]) .. " " .. setting[3])
    end
    table.insert(lines, "")
    table.insert(lines, "── NẠP NICK ──")
    table.insert(lines, "📂 File: " .. ACCOUNT_FILE)
    table.insert(lines, "🔢 Số nick: " .. SO_NICK_CAN_DANG_NHAP)
    table.insert(lines, "")
    table.insert(lines, "── KẾT BẠN GỢI Ý ──")
    table.insert(lines, "👥 Nick chạy: " .. SO_NICK_KB_GY)
    table.insert(lines, "🔢 SL/Nick: " .. SO_LUONG_KB_GY)
    table.insert(lines, "")
    table.insert(lines, "── CHẤP NHẬN KẾT BẠN ──")
    table.insert(lines, "👥 Nick chạy: " .. SO_NICK_CNKB)
    table.insert(lines, "⏳ Delay: " .. DELAY_CNKB .. "s")
    return table.concat(lines, "\n")
end

-- ========== CÁC MENU GUI ==========
function menuToggle()
    while true do
        local items = {}
        for _, feat in ipairs(GUI_FEATURES) do
            local val = layGiaTri(feat[2])
            local icon = (val == 1) and "✅" or "❌"
            table.insert(items, icon .. " " .. feat[1])
        end
        table.insert(items, "──────────────")
        table.insert(items, "🟢 Bật tất cả")
        table.insert(items, "🔴 Tắt tất cả")
        table.insert(items, "◀️ Quay lại")
        local choice = dialogChoice("⚙️ BẬT/TẮT CHỨC NĂNG", unpack(items))
        if not choice or choice:find("Quay lại") then return
        elseif choice:find("Bật tất cả") then
            for _, feat in ipairs(GUI_FEATURES) do ganGiaTri(feat[2], 1) end
            toast("✅ Đã bật tất cả!")
        elseif choice:find("Tắt tất cả") then
            for _, feat in ipairs(GUI_FEATURES) do ganGiaTri(feat[2], 0) end
            toast("❌ Đã tắt tất cả!")
        elseif not choice:find("────") then
            for _, feat in ipairs(GUI_FEATURES) do
                if choice:find(feat[1], 1, true) then
                    local val = layGiaTri(feat[2])
                    ganGiaTri(feat[2], (val == 1) and 0 or 1)
                    luuCauHinh()
                    local status = (layGiaTri(feat[2]) == 1) and "BẬT ✅" or "TẮT ❌"
                    toast(feat[1] .. ": " .. status)
                    break
                end
            end
        end
    end
end

function menuSettings()
    while true do
        local items = {}
        for _, setting in ipairs(GUI_SETTINGS) do
            table.insert(items, "🔢 " .. setting[1] .. ": " .. layGiaTri(setting[2]) .. " " .. setting[3])
        end
        table.insert(items, "◀️ Quay lại")
        local choice = dialogChoice("🔢 CÀI ĐẶT THÔNG SỐ", unpack(items))
        if not choice or choice:find("Quay lại") then return end
        for _, setting in ipairs(GUI_SETTINGS) do
            if choice:find(setting[1]) then
                local curVal = layGiaTri(setting[2])
                local input = dialogInput(setting[1], "Nhập giá trị mới (" .. setting[3] .. ")\nHiện tại: " .. curVal)
                if input then
                    local num = tonumber(input)
                    if num and num >= 0 then
                        ganGiaTri(setting[2], math.floor(num))
                        toast(setting[1] .. " = " .. layGiaTri(setting[2]))
                    else
                        toast("⚠️ Giá trị không hợp lệ!")
                    end
                end
                break
            end
        end
    end
end

print("✅ config.lua đã nạp (Đồng bộ 100% với code gốc)")