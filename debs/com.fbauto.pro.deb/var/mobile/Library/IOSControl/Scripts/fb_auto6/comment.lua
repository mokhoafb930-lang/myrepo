-- ================================================================
-- FILE: comment.lua - CMT BÀI VIẾT CHỈ ĐỊNH
-- Nguồn: fb_auto_new.lua dòng 2299-2552
-- ================================================================

-- ========== DANH SÁCH NỘI DUNG CMT MẶC ĐỊNH ==========
CMT_LIST = readLinesFromFile(CMT_FILE_PATH, {
    "Bài viết hay quá! ❤️",
    "Cảm ơn bạn đã chia sẻ! 🙏",
    "Tuyệt vời! 👍",
    "Mình rất thích bài này! 😍",
    "Ủng hộ bạn nè! 🚀",
    "Hay lắm ạ! 💯",
    "Có ích quá, cảm ơn! 📝",
    "Đọc xong thấy thú vị! ✨",
    "Chia sẻ hay quá! 🌟",
    "Mong bạn ra nhiều bài hơn nữa! 💪",
    "Nội dung chất lượng quá! 🔥",
    "Bài viết rất ý nghĩa! 💖",
    "Hữu ích thật sự luôn! 🙌",
    "Like mạnh cho bài này! 👍",
    "Quá tuyệt vời luôn! 🌈",
    "Bài viết đáng để đọc! 📚",
    "Xin cảm ơn vì thông tin hay! 🙏",
    "Đọc mà cuốn quá! 😍",
    "Bạn chia sẻ có tâm quá! ❤️",
    "Hay xuất sắc luôn! 💯",
    "Đúng cái mình đang cần! ✨",
    "Rất đáng tham khảo nha! 📌",
    "Thật sự quá hay luôn! 🔥",
    "Cảm ơn vì bài viết bổ ích! 🌟",
    "Chúc bạn luôn thành công! 🚀",
    "Mình học được nhiều điều! 📖",
    "Bài này đỉnh thật sự! 😎",
    "Nội dung rõ ràng dễ hiểu! 👍",
    "Quá xịn luôn bạn ơi! 💪",
    "Xem xong thấy thích quá! 😍",
    "Đã đọc và rất thích! ❤️",
    "Bạn đầu tư nội dung ghê! 🔥",
    "Quá hay quá chất lượng! 💯",
    "Mong chờ bài tiếp theo nha! 🌟",
    "Bài viết quá tuyệt hảo! ✨",
    "Ủng hộ dài dài luôn! 🚀",
    "Chia sẻ đúng lúc quá! 🙏",
    "Hay và ý nghĩa lắm ạ! 💖",
    "Nội dung đỉnh cao luôn! 😎",
    "Đọc xong mở mang nhiều! 📚",
    "Bài đăng quá chuyên nghiệp! 👍",
    "Thật lòng rất thích bài này! 😍",
    "Quá giá trị luôn nha! 💯",
    "Cảm ơn bạn nhiều lắm! ❤️",
    "Đọc phát là mê luôn! 🔥",
    "Bài viết quá chỉn chu! 🌟",
    "Like mạnh không cần nghĩ! 👍",
    "Quá cuốn hút luôn nha! ✨",
    "Đúng gu mình luôn! 😍",
    "Nội dung hay miễn bàn! 🚀",
    "Hay thật sự luôn đó! 💖",
    "Chất lượng khỏi bàn! 💯",
    "Mong bạn đăng thêm nhiều nhé! 📌",
    "Rất đáng để lan toả! 🌈",
    "Đọc xong thấy vui ghê! 😊",
    "Bài viết truyền cảm hứng quá! 🔥",
    "Quá tốt quá hay luôn! ❤️",
    "Ủng hộ hết mình nha! 💪",
    "Đỉnh của chóp luôn! 😎",
    "Bài đăng quá xuất sắc! 🌟",
    "Nội dung siêu hay luôn! ✨",
    "Cảm ơn bạn đã dành thời gian chia sẻ! 🙏",
    "Mình lưu lại để đọc thêm! 📚",
    "Rất thích cách bạn trình bày! 👍",
    "Hay quá đi mất! 😍",
    "Bài viết đáng đồng tiền bát gạo! 💯",
    "Thật sự quá có tâm! ❤️",
    "Mỗi lần đọc là học thêm được điều mới! 📖",
    "Nội dung cực kỳ giá trị! 🚀",
    "Xứng đáng 1 like lớn! 👍",
    "Bài viết tuyệt đỉnh luôn! 🔥"
})

-- Biến đếm index cho chế độ tuần tự
CMT_CURRENT_INDEX = 1
CMT_MAX_RETRY_POST = 5
CMT_TAP_DELAY = 5

-- ========== LẤY NỘI DUNG COMMENT ========== (dòng 2303-2320)
local function getNoiDungCMT()
    if #CMT_LIST == 0 then return "Hay quá!" end

    if CMT_MODE == "random" then
        local idx = math.random(1, #CMT_LIST)
        log("🎲 Chọn comment ngẫu nhiên (" .. idx .. "/" .. #CMT_LIST .. "): " .. CMT_LIST[idx])
        log("🎲 Random (" .. idx .. "/" .. #CMT_LIST .. "): " .. CMT_LIST[idx])
        return CMT_LIST[idx]
    else
        local noiDung = CMT_LIST[CMT_CURRENT_INDEX]
        log("🔄 Chọn comment tuần tự (" .. CMT_CURRENT_INDEX .. "/" .. #CMT_LIST .. "): " .. noiDung)
        log("🔄 Tuần tự (" .. CMT_CURRENT_INDEX .. "/" .. #CMT_LIST .. "): " .. noiDung)

        CMT_CURRENT_INDEX = CMT_CURRENT_INDEX + 1
        if CMT_CURRENT_INDEX > #CMT_LIST then
            CMT_CURRENT_INDEX = 1
            log("🔄 Đã hết danh sách, quay lại câu đầu tiên")
            log("🔄 Hết list, quay lại từ đầu")
        end
        return noiDung
    end
end

-- ========== THỰC HIỆN CMT BÀI VIẾT CHỈ ĐỊNH ========== (dòng 2322-2438)
function thucHienCMTBaiViet()
    -- Load lại nội dung từ file trước khi chạy
    CMT_LIST = readLinesFromFile(CMT_FILE_PATH, CMT_LIST)

    local commentBoxImage = "crop_1777343201954.png"
    local postButtonImage = "crop_1777343840162.png"

    logScreen("💬 BẮT ĐẦU CMT BÀI VIẾT", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + CMT_SO_NICK), true)
    log("👥 Số nick: " .. CMT_SO_NICK)
    log("🔗 URL: " .. CMT_URL)
    log("🎲 Mode: " .. CMT_MODE)
    log("📝 Số nội dung: " .. #CMT_LIST)

    CMT_CURRENT_INDEX = 1  -- Reset index sequential mỗi lần chạy

    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, CMT_SO_NICK do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end

        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. CMT_SO_NICK .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            sleep(1)
            chuyenNick(tenPhanVung)
            sleep(1)
        end

        if not moFacebook() then
            log("⚠️ Lỗi mở Facebook, bỏ qua nick này")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            log("📱 Đang mở bài viết...")
            openURL(CMT_URL)
            sleep(5)
            log("✅ Đã mở bài viết")
            sleep(2)

            log("🔍 Tìm ô nhập comment (tối đa " .. CMT_MAX_ATTEMPTS .. " lần)...")
            local found = false

            for attempt = 1, CMT_MAX_ATTEMPTS do
                logScreen("🔍 Tìm ô comment (" .. attempt .. "/" .. CMT_MAX_ATTEMPTS .. ")", true)
                log("🔄 Lần thử " .. attempt .. "/" .. CMT_MAX_ATTEMPTS)

                local x, y = findImage(commentBoxImage, 1)

                if x and y then
                    log("✅ Tìm thấy ô comment tại: (" .. x .. ", " .. y .. ")")
                    sleep(CMT_TAP_DELAY)

                    log("👉 Đang tap vào ô comment...")
                    tap(x, y)
                    sleep(1)
                    sleep(2)

                    local noiDung = getNoiDungCMT()
                    log("📝 Đang nhập nội dung comment...")
                    inputText(noiDung)
                    sleep(1)
                    log("✅ Đã nhập: " .. noiDung)
                    sleep(3)

                    log("🔍 Tìm nút Đăng bình luận...")
                    local foundPost = false

                    for retry = 1, CMT_MAX_RETRY_POST do
                        local x2, y2 = findImage(postButtonImage, 1)
                        if x2 and y2 then
                            log("✅ Tìm thấy nút Đăng tại: (" .. x2 .. ", " .. y2 .. ")")
                            tap(x2, y2)
                            sleep(1)
                            sleep(5)
                            logScreen("✅ ĐÃ ĐĂNG BÌNH LUẬN! (" .. nickIndex .. "/" .. CMT_SO_NICK .. ")", true)
                            foundPost = true
                            break
                        else
                            if retry < CMT_MAX_RETRY_POST then
                                log("⚠️ Chưa thấy nút Đăng, thử lại " .. retry .. "/" .. CMT_MAX_RETRY_POST)
                                sleep(2)
                            end
                        end
                    end

                    if not foundPost then
                        logScreen("❌ Không tìm thấy nút Đăng!", true)
                        log("❌ Không tìm thấy nút Đăng sau " .. CMT_MAX_RETRY_POST .. " lần thử")
                    end

                    found = true
                    break
                else
                    if attempt < CMT_MAX_ATTEMPTS then
                        log("⚠️ Chưa thấy ô comment, đang cuộn...")
                        swipe(200, 500, 200, 200, 1)
                        sleep(CMT_SCROLL_DELAY)
                    end
                end
            end

            if not found then
                logScreen("❌ Không tìm thấy ô comment!", true)
                log("❌ Không tìm thấy ô comment sau " .. CMT_MAX_ATTEMPTS .. " lần thử")
            end
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < CMT_SO_NICK then
                nghi(5, "Nghỉ đổi nick")
            end
        end
    end

    logScreen("✅ HOÀN TẤT CMT BÀI VIẾT", true)
    log("==========================================")
end

-- ========== MENU CMT BÀI VIẾT CHỈ ĐỊNH ========== (dòng 2440-2552)
function menuCMTBaiViet()
    while true do
        -- Load lại nội dung từ file để hiển thị số lượng chính xác
        CMT_LIST = readLinesFromFile(CMT_FILE_PATH, CMT_LIST)
        local urlHien = CMT_URL
        if string.len(urlHien) > 20 then
            urlHien = string.sub(urlHien, 1, 20) .. "…"
        end
        if urlHien == "" then urlHien = "chưa nhập" end

        local title = "💬 CMT bài viết chỉ định\n"
            .. "· Nick: " .. CMT_SO_NICK .. "  · Mode: " .. (CMT_MODE == "random" and "ngẫu nhiên" or "tuần tự") .. "\n"
            .. "· Link: " .. urlHien .. "\n"
            .. "· Nội dung: " .. #CMT_LIST .. " câu"

        local choice = dialogChoice(title,
            "🔗 Nhập link bài viết",
            "👥 Số nick cần chạy: " .. CMT_SO_NICK,
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "🎲 Chế độ: " .. (CMT_MODE == "random" and "Ngẫu nhiên 🎲" or "Tuần tự 🔄"),
            "📝 Xem/Sửa danh sách nội dung",
            "🔢 Số lần lướt tìm: " .. CMT_MAX_ATTEMPTS,
            "⏳ Delay giữa các lần: " .. CMT_SCROLL_DELAY .. "s",
            "──────────────",
            "🚀 BẮT ĐẦU CHẠY",
            "◀️ Quay lại"
        )

        if not choice or choice:find("Quay lại") then
            return "back"
        elseif choice:find("Nhập link") then
            local urlInput = dialogInput("Link bài viết", "Dán link bài viết vào đây:", CMT_URL)
            if urlInput and urlInput ~= "" then CMT_URL = urlInput end
        elseif choice:find("Số nick") then
            local n = dialogInput("Số nick cần chạy", "Nhập số lượng:", tostring(CMT_SO_NICK))
            if n and tonumber(n) then CMT_SO_NICK = math.floor(tonumber(n)) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT nick bắt đầu chạy:", tostring(NICK_BAT_DAU))
            if input then
                local num = tonumber(input)
                if num and num >= 0 then
                    NICK_BAT_DAU = math.max(1, math.floor(num))
                    toast("🚩 Nick bắt đầu: " .. NICK_BAT_DAU)
                else
                    toast("⚠️ Giá trị không hợp lệ!")
                end
            end
        elseif choice:find("Chế độ") then
            CMT_MODE = (CMT_MODE == "random") and "sequential" or "random"
            toast("Mode: " .. (CMT_MODE == "random" and "Ngẫu nhiên 🎲" or "Tuần tự 🔄"))
        elseif choice:find("Xem/Sửa") then
            local page = 1
            local pageSize = 20
            while true do
                local startIdx = (page - 1) * pageSize + 1
                local endIdx = math.min(page * pageSize, #CMT_LIST)
                local displayLines = {}
                for i = startIdx, endIdx do
                    local content = CMT_LIST[i]
                    table.insert(displayLines, i .. ". " .. content)
                end
                local preview = table.concat(displayLines, "\n")
                local totalPage = math.ceil(#CMT_LIST / pageSize)

                local msg = "📝 DANH SÁCH NỘI DUNG CMT\n"
                    .. "📄 Trang: " .. page .. "/" .. totalPage .. "\n"
                    .. "📊 Tổng: " .. #CMT_LIST .. " câu\n"
                    .. "────────────────\n"
                    .. preview .. "\n"
                    .. "────────────────\n"
                    .. "⚠️ Vui lòng vào file cmt.txt để sửa nội dung!"

                local buttons = {"OK ✅"}
                if page < totalPage then table.insert(buttons, "Trang tiếp ➡️") end
                if page > 1 then table.insert(buttons, "⬅️ Trang trước") end

                local res = dialogChoice(msg, unpack(buttons))
                if not res or res == "OK ✅" then
                    break
                elseif res == "Trang tiếp ➡️" then
                    page = page + 1
                elseif res == "⬅️ Trang trước" then
                    page = page - 1
                end
            end
        elseif choice:find("Số lần lướt tìm") then
            local n = dialogInput("Số lần lướt tối đa", "Nhập số lần:", tostring(CMT_MAX_ATTEMPTS))
            if n and tonumber(n) then CMT_MAX_ATTEMPTS = math.floor(tonumber(n)) end
        elseif choice:find("Delay giữa các lần") then
            local n = dialogInput("Delay cuộn (giây)", "Nhập số giây:", tostring(CMT_SCROLL_DELAY))
            if n and tonumber(n) then CMT_SCROLL_DELAY = math.floor(tonumber(n)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            if CMT_URL == "" then
                toast("⚠️ Vui lòng nhập link bài viết!")
            elseif #CMT_LIST == 0 then
                toast("⚠️ Danh sách comment trống!")
            else
                local confirm = dialogChoice(
                    "🚀 XÁC NHẬN CMT\n\n"
                    .. "👥 Chạy: " .. CMT_SO_NICK .. " nick\n"
                    .. "🎲 Mode: " .. CMT_MODE .. "\n"
                    .. "📝 " .. #CMT_LIST .. " câu comment",
                    "✅ Chạy ngay!",
                    "◀️ Quay lại"
                )
                if confirm and confirm:find("Chạy ngay") then
                    luuCauHinh()
                    return "cmt_bai_viet"
                end
            end
        end
    end
end

print("✅ comment.lua đã nạp")