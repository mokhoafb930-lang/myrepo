-- ================================================================
-- FILE: nick_manager.lua - QUẢN LÝ NICK + CHECK LIVE UID
-- Nguồn: fb_auto_new.lua dòng 804-1183
-- ================================================================

-- ========== HÀM ĐẾM NICK TRONG FILE ========== (dòng 804-818)
function demNickTrongFile()
    local soNick = 0
    local f = io.open(ACCOUNT_FILE, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content then
            for line in string.gmatch(content, "[^\r\n]+") do
                if line ~= "" then soNick = soNick + 1 end
            end
        end
    end
    return soNick
end

-- ========== HÀM THÊM NICK VÀO FILE ========== (dòng 820-833)
function ghiNickVaoFile(nickLine)
    local f = io.open(ACCOUNT_FILE, "a")
    if not f then
        f = io.open(ACCOUNT_FILE, "w")
    end
    if not f then
        toast("❌ Không thể ghi file!")
        return false
    end
    f:write(nickLine .. "\n")
    f:close()
    return true
end

-- ========== HÀM GHI LOG KẾT BẠN UID ========== (dòng 835-844)
function ghiLogUID(msg)
    local f = io.open(UID_LOG_FILE, "a")
    if not f then f = io.open(UID_LOG_FILE, "w") end
    if f then
        local timestamp = os.date("%Y-%m-%d %H:%M:%S")
        f:write("[" .. timestamp .. "] " .. msg .. "\n")
        f:close()
    end
end

-- ========== HÀM ĐẾM UID TRONG FILE ========== (dòng 1185-1199)
function demUIDTrongFile()
    local soUID = 0
    local f = io.open(UID_FRIEND_FILE, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content then
            for line in string.gmatch(content, "[^\r\n]+") do
                if line ~= "" then soUID = soUID + 1 end
            end
        end
    end
    return soUID
end

-- ========== KIỂM TRA LIVE UID ========== (dòng 850-900)
function kiemTraLiveUID(uid)
    if not uid or uid == "" then
        return false, "Không có UID"
    end

    local ok, r = pcall(function()
        return httpGet("https://graph.facebook.com/" .. uid .. "/picture?redirect=false")
    end)

    if not ok then
        return false, "Lỗi kết nối: " .. tostring(r)
    end

    local body = ""
    if type(r) == "table" then
        body = r.body or r.data or r[1] or ""
    elseif type(r) == "string" then
        body = r
    end

    local url = string.match(body, '"url"%s*:%s*"([^"]+)"')

    if url then
        local doDai = #url

        local dieUrls = {
            "https://static.xx.fbcdn.net/rsrc.php/v4/yo/r/UlIqmHJn-SK.gif",
            "https://static.xx.fbcdn.net/rsrc.php/v4/yL/r/HsTZSDw4avx.gif",
            "https://static.xx.fbcdn.net/rsrc.php/v4/y-/r/IOC9bCk9Hhd.gif"
        }

        for _, dieUrl in ipairs(dieUrls) do
            if url == dieUrl then
                return false, "URL ảnh mặc định (die)"
            end
        end

        if doDai > 150 then
            return true, "URL dài (" .. doDai .. " ký tự)"
        else
            return false, "URL quá ngắn (" .. doDai .. " ký tự)"
        end
    end

    if string.find(body, '"error"') then
        return false, "API trả về error"
    end

    return false, "Không xác định được"
end

-- ========== LƯU THỐNG KÊ ========== (dòng 902-920)
local function luuThongKe(ngayGio, tongNick, liveNick, dieNick, tyLeLive, tyLeDie, chiTiet)
    local f = io.open(THONG_KE_FILE, "a")
    if f then
        f:write("========================================\n")
        f:write("📅 THỜI GIAN: " .. ngayGio .. "\n")
        f:write("📊 TỔNG NICK: " .. tongNick .. "\n")
        f:write("✅ LIVE: " .. liveNick .. " (" .. string.format("%.2f", tyLeLive) .. "%)\n")
        f:write("❌ DIE: " .. dieNick .. " (" .. string.format("%.2f", tyLeDie) .. "%)\n")
        f:write("📋 CHI TIẾT:\n")
        for _, item in ipairs(chiTiet) do
            f:write("   " .. item .. "\n")
        end
        f:write("========================================\n\n")
        f:close()
        return true
    end
    return false
end

-- ========== ĐỌC NICK TỪ FILE ========== (dòng 922-937)
local function docNickTuFile()
    local file = io.open(ACCOUNT_FILE, "r")
    if not file then return {} end
    local lines = {}
    for line in file:lines() do
        if line ~= "" then table.insert(lines, line) end
    end
    file:close()
    return lines
end

-- ========== LẤY UID TỪ DÒNG ========== (dòng 939-946)
function layUIDTuDong(line)
    local uid = line:match("^([^|]+)")
    if uid then uid = uid:match("^%s*(.-)%s*$") end
    return uid
end

local function layThoiGian()
    return os.date("%Y-%m-%d %H:%M:%S")
end

-- ========== HIỂN THỊ THỐNG KÊ ========== (dòng 953-981)
local function hienThiThongKe(tong, live, die, tyLeLive, tyLeDie)
    log("")
    log("╔══════════════════════════════════════════════════════════╗")
    log("║                    📊 THỐNG KÊ CHI TIẾT                   ║")
    log("╠══════════════════════════════════════════════════════════╣")
    log(string.format("║  📝 TỔNG SỐ NICK:     %-40s║", tong))
    log(string.format("║  ✅ LIVE:            %-40s║", live .. " (" .. string.format("%.2f", tyLeLive) .. "%)"))
    log(string.format("║  ❌ DIE:             %-40s║", die .. " (" .. string.format("%.2f", tyLeDie) .. "%)"))
    log("╠══════════════════════════════════════════════════════════╣")
    log(string.format("║  📈 TỶ LỆ LIVE/DEATH: %-40s║", string.format("%.1f", tyLeLive) .. "% / " .. string.format("%.1f", tyLeDie) .. "%"))
    local danhGia = ""
    if tyLeLive >= 80 then danhGia = "★★★★★ TỐT"
    elseif tyLeLive >= 60 then danhGia = "★★★★☆ KHÁ"
    elseif tyLeLive >= 40 then danhGia = "★★★☆☆ TRUNG BÌNH"
    elseif tyLeLive >= 20 then danhGia = "★★☆☆☆ YẾU"
    else danhGia = "★☆☆☆☆ RẤT YẾU" end
    log(string.format("║  🏆 ĐÁNH GIÁ:        %-40s║", danhGia))
    log("╚══════════════════════════════════════════════════════════╝")
    log("")
end

-- ========== KIỂM TRA VÀ XÓA NICK DIE ========== (dòng 983-1101)
function kiemTraVaXoaNickDie()
    log("")
    log("==========================================")
    log("🔍 BẮT ĐẦU KIỂM TRA VÀ XÓA NICK DIE")
    log("==========================================")

    local allLines = docNickTuFile()
    if #allLines == 0 then
        log("📭 File nick rỗng!")
        toast("📭 File nick rỗng!", 2)
        return 0
    end

    log("📊 Tổng số nick trong file: " .. #allLines)
    toast("📊 Tổng số nick: " .. #allLines, 2)
    sleep(1)

    local liveLines = {}
    local dieLines = {}
    local ketQua = {}
    local chiTietThongKe = {}
    local startTime = os.time()

    for i, line in ipairs(allLines) do
        local percent = math.floor((i / #allLines) * 100)
        toast("🔍 Đang kiểm tra: " .. i .. "/" .. #allLines .. " (" .. percent .. "%)", 1)

        local uid = layUIDTuDong(line)
        if not uid or uid == "" then
            log("⚠️ Không thể lấy UID từ dòng: " .. line)
            table.insert(liveLines, line)
            table.insert(ketQua, {line = line, uid = "???", status = "UNKNOWN", reason = "Không lấy được UID"})
            table.insert(chiTietThongKe, "⚠️ ??? | UNKNOWN")
        else
            log("")
            log("👉 Kiểm tra nick " .. i .. "/" .. #allLines .. ": " .. uid)
            local isLive, lyDo = kiemTraLiveUID(uid)
            if isLive then
                table.insert(liveLines, line)
                table.insert(ketQua, {line = line, uid = uid, status = "LIVE", reason = lyDo})
                table.insert(chiTietThongKe, "✅ " .. uid .. " | LIVE")
                log("✅ GIỮ LẠI: " .. uid .. " | " .. lyDo)
            else
                table.insert(dieLines, line)
                table.insert(ketQua, {line = line, uid = uid, status = "DIE", reason = lyDo})
                table.insert(chiTietThongKe, "❌ " .. uid .. " | DIE | " .. lyDo)
                log("❌ XÓA: " .. uid .. " | " .. lyDo)
            end
        end
        if i < #allLines then sleep(1) end
    end

    local endTime = os.time()
    local thoiGianChay = endTime - startTime

    if #dieLines > 0 then
        toast("💾 Đang xóa " .. #dieLines .. " nick die và ghi lại file...", 2)
        local fw = io.open(ACCOUNT_FILE, "w")
        if fw then
            for _, line in ipairs(liveLines) do fw:write(line .. "\n") end
            fw:close()
            log("")
            log("✅ Đã xóa " .. #dieLines .. " nick DIE khỏi file!")
            log("✅ Còn lại " .. #liveLines .. " nick LIVE trong file!")
        else
            log("❌ Không thể ghi file!")
            toast("❌ Không thể ghi file!", 2)
        end
    else
        log("")
        log("✅ Tất cả nick đều LIVE! Không có nick nào bị xóa!")
    end

    local liveCount = #liveLines
    local dieCount = #dieLines
    local tongNick = #allLines
    local percentLive = (liveCount / tongNick) * 100
    local percentDie = (dieCount / tongNick) * 100

    hienThiThongKe(tongNick, liveCount, dieCount, percentLive, percentDie)
    log("⏱️ THỜI GIAN CHẠY: " .. thoiGianChay .. " giây")

    local thoiGian = layThoiGian()
    luuThongKe(thoiGian, tongNick, liveCount, dieCount, percentLive, percentDie, chiTietThongKe)
    log("💾 Đã lưu thống kê vào file: " .. THONG_KE_FILE)

    log("")
    log("📋 CHI TIẾT TỪNG NICK:")
    for _, item in ipairs(ketQua) do
        if item.status == "LIVE" then
            log("✅ " .. item.uid .. " | " .. item.status .. " | " .. item.reason)
        else
            log("❌ " .. item.uid .. " | " .. item.status .. " | " .. item.reason)
        end
    end
    log("==========================================")

    toast("✅ Xong! LIVE: " .. liveCount .. " (" .. string.format("%.1f", percentLive) .. "%) | DIE: " .. dieCount .. " | TG: " .. thoiGianChay .. "s", 3)
    return dieCount
end

-- ========== XEM THỐNG KÊ ĐÃ LƯU ========== (dòng 1103-1119)
function xemThongKeLuu()
    local file = io.open(THONG_KE_FILE, "r")
    if not file then
        dialogChoice("📊 THỐNG KÊ\n\n📭 Chưa có dữ liệu thống kê!", "OK ✅")
        return
    end
    local content = file:read("*a")
    file:close()
    if content == "" then
        dialogChoice("📊 THỐNG KÊ\n\n📭 Chưa có dữ liệu thống kê!", "OK ✅")
    else
        dialogChoice("📊 LỊCH SỬ THỐNG KÊ\n\n" .. content, "OK ✅")
    end
end

-- ========== XÓA TOÀN BỘ THỐNG KÊ ========== (dòng 1121-1140)
function xoaThongKe()
    local confirm = dialogChoice(
        "⚠️ XÓA TOÀN BỘ THỐNG KÊ\n\nBạn có chắc chắn muốn xóa tất cả lịch sử thống kê?",
        "✅ Xóa ngay!", "◀️ Hủy"
    )
    if confirm and confirm:find("Xóa ngay") then
        local f = io.open(THONG_KE_FILE, "w")
        if f then f:write("") f:close()
            toast("🗑️ Đã xóa toàn bộ lịch sử thống kê!", 2)
        else
            toast("❌ Không thể xóa file thống kê!", 2)
        end
    end
end

-- ========== MENU CHECK LIVE UID ========== (dòng 1142-1183)
function menuCheckUID()
    while true do
        local soNick = demNickTrongFile()
        local filename = ACCOUNT_FILE:match("([^/]+)$") or ACCOUNT_FILE
        local title = "🔍 Check live UID\n· File: " .. filename .. "\n· Tổng nick: " .. soNick

        local choice = dialogChoice(title,
            "🗑️ Kiểm tra và xóa nick DIE",
            "📊 Xem lịch sử thống kê",
            "🗑️ Xóa toàn bộ thống kê",
            "◀️ Quay lại"
        )

        if not choice or choice:find("Quay lại") then return
        elseif choice:find("Kiểm tra và xóa nick DIE") then
            if soNick == 0 then
                toast("⚠️ File nick rỗng! Thêm nick trước!", 2)
            else
                local confirm = dialogChoice(
                    "🚀 XÁC NHẬN KIỂM TRA VÀ XÓA NICK DIE\n\n📊 Tổng số nick: " .. soNick
                    .. "\n⚠️ Nick DIE sẽ tự động bị xóa khỏi file!\n💾 Kết quả thống kê sẽ được lưu lại!",
                    "✅ Chạy ngay!", "◀️ Quay lại"
                )
                if confirm and confirm:find("Chạy ngay") then
                    kiemTraVaXoaNickDie()
                end
            end
        elseif choice:find("Xem lịch sử thống kê") then
            xemThongKeLuu()
        elseif choice:find("Xóa toàn bộ thống kê") then
            xoaThongKe()
        end
    end
end

print("✅ nick_manager.lua đã nạp")