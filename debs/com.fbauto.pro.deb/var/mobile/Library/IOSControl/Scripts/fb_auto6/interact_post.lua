-- ================================================================
-- FILE: interact_post.lua - TƯƠNG TÁC BÀI VIẾT
-- Nguồn: fb_auto_new.lua dòng 2059-2297
-- ================================================================

-- ========== TÌM ẢNH VỚI CUỘN ========== (dòng 2064-2077)
local function findImageWithScroll_Post(imagePath, maxScroll)
    for attempt = 1, maxScroll do
        local x, y = findImage(imagePath, 1)
        if x and y then
            return x, y, attempt
        else
            if attempt < maxScroll then
                swipe(200, 500, 200, 300, 1)
                sleep(INTERACT_SCROLL_DELAY)
            end
        end
    end
    return nil, nil, maxScroll
end

-- ========== TÌM MENU VỚI THỬ LẠI ========== (dòng 2079-2101)
local function findMenuWithRetry_Post(tenCamXuc, menuPath)
    local MAX_RETRY_MENU = 3
    local RETRY_DELAY = 3
    for retry = 1, MAX_RETRY_MENU do
        logScreen("🔍 Đang tìm cảm xúc: " .. tenCamXuc, true)
        log("🔍 Tim cam xuc: " .. tenCamXuc .. " (LAN " .. retry .. "/" .. MAX_RETRY_MENU .. ")")
        local x, y = findImage(menuPath, 1)
        if x and y then
            log("✅ TIM THAY MENU " .. tenCamXuc .. " TAI: (" .. x .. ", " .. y .. ")")
            return x, y
        else
            if retry < MAX_RETRY_MENU then
                log("⚠️ KHONG THAY MENU " .. tenCamXuc .. ", THU LAI SAU " .. RETRY_DELAY .. "s...")
                sleep(RETRY_DELAY)
            end
        end
    end
    logScreen("❌ KHÔNG TÌM THẤY MENU " .. tenCamXuc, true)
    return nil, nil
end

-- ========== XỬ LÝ CẢM XÚC ========== (dòng 2103-2122)
local function xuLyCamXuc_Post(tenCamXuc, menuPath, imagePathPost)
    local x, y, attempts = findImageWithScroll_Post(imagePathPost, INTERACT_MAX_ATTEMPTS)
    if x and y then
        longPress(x, y, 1.5)
        sleep(2)
        local x2, y2 = findMenuWithRetry_Post(tenCamXuc, menuPath)
        if x2 and y2 then
            tap(x2, y2) sleep(1)
            logScreen("❤️ ĐÃ " .. tenCamXuc .. " THÀNH CÔNG!", true)
        else
            logScreen("❌ KHÔNG CHỌN ĐƯỢC CẢM XÚC", true)
        end
    else
        logScreen("❌ KHÔNG TÌM THẤY NÚT LIKE/POST", true)
    end
end

-- ========== CHẠY TƯƠNG TÁC BÀI VIẾT ========== (dòng 2124-2207)
function thucHienInteractPost()
    logScreen("🚀 TƯƠNG TÁC BÀI VIẾT", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + INTERACT_NICKS), true)
    log("🔗 URL: " .. INTERACT_URL)
    log("👥 Số nick: " .. INTERACT_NICKS)

    local imagePathPost = "crop_1777213229157.png"
    local menuTYM = "crop_1777188485023.png"
    local menuTHUONG = "crop_1777213812741.png"
    local menuHAHA = "crop_1777213949549.png"
    local menuBUON = "crop_1777214041805.png"

    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, INTERACT_NICKS do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end
        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. INTERACT_NICKS .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            chuyenNick(tenPhanVung)
        end
        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            log("📱 Dang mo bai viet...")
            openURL(INTERACT_URL) sleep(5)
            log("✅ Da mo bai viet") sleep(2)

            local listEnabled = {}
            if INTERACT_LIKE == 1 then table.insert(listEnabled, "LIKE") end
            if INTERACT_TYM == 1 then table.insert(listEnabled, "TYM") end
            if INTERACT_THUONG == 1 then table.insert(listEnabled, "THUONG") end
            if INTERACT_HAHA == 1 then table.insert(listEnabled, "HAHA") end
            if INTERACT_BUON == 1 then table.insert(listEnabled, "BUON") end

            if #listEnabled == 0 then
                log("⚠️ Khong co cam xuc nao duoc bat!")
            else
                if INTERACT_RANDOM == 1 then
                    local randomChoice = listEnabled[math.random(1, #listEnabled)]
                    log("🎲 Random chon: " .. randomChoice)
                    if randomChoice == "LIKE" then
                        local x, y = findImageWithScroll_Post(imagePathPost, INTERACT_MAX_ATTEMPTS)
                        if x and y then tap(x, y) sleep(1) logScreen("❤️ ĐÃ LIKE THÀNH CÔNG!", true) end
                    elseif randomChoice == "TYM" then xuLyCamXuc_Post("TYM", menuTYM, imagePathPost)
                    elseif randomChoice == "THUONG" then xuLyCamXuc_Post("THUONG THUONG", menuTHUONG, imagePathPost)
                    elseif randomChoice == "HAHA" then xuLyCamXuc_Post("HAHA", menuHAHA, imagePathPost)
                    elseif randomChoice == "BUON" then xuLyCamXuc_Post("BUON", menuBUON, imagePathPost)
                    end
                else
                    if INTERACT_LIKE == 1 then
                        local x, y = findImageWithScroll_Post(imagePathPost, INTERACT_MAX_ATTEMPTS)
                        if x and y then tap(x, y) sleep(1) logScreen("❤️ ĐÃ LIKE THÀNH CÔNG!", true) end
                    end
                    if INTERACT_TYM == 1 then xuLyCamXuc_Post("TYM", menuTYM, imagePathPost) end
                    if INTERACT_THUONG == 1 then xuLyCamXuc_Post("THUONG THUONG", menuTHUONG, imagePathPost) end
                    if INTERACT_HAHA == 1 then xuLyCamXuc_Post("HAHA", menuHAHA, imagePathPost) end
                    if INTERACT_BUON == 1 then xuLyCamXuc_Post("BUON", menuBUON, imagePathPost) end
                end
            end
        end
        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < INTERACT_NICKS then nghi(5, "Nghỉ đổi nick") end
        end
    end
    logScreen("✅ HOÀN TẤT TƯƠNG TÁC BÀI VIẾT", true)
end

-- ========== MENU TƯƠNG TÁC BÀI VIẾT ========== (dòng 2209-2297)
function menuInteractPost()
    while true do
        local camXucBat = ""
        if INTERACT_LIKE == 1 then camXucBat = camXucBat .. "👍" end
        if INTERACT_TYM == 1 then camXucBat = camXucBat .. "❤️" end
        if INTERACT_THUONG == 1 then camXucBat = camXucBat .. "🥰" end
        if INTERACT_HAHA == 1 then camXucBat = camXucBat .. "😆" end
        if INTERACT_BUON == 1 then camXucBat = camXucBat .. "😢" end
        if camXucBat == "" then camXucBat = "chưa chọn" end
        local urlHien = INTERACT_URL
        if string.len(urlHien) > 20 then urlHien = string.sub(urlHien, 1, 20) .. "…" end

        local title = "🎯 Tương tác bài viết\n"
            .. "· Nick: " .. INTERACT_NICKS .. "  · Random: " .. (INTERACT_RANDOM == 1 and "bật" or "tắt") .. "\n"
            .. "· Link: " .. urlHien .. "\n· Cảm xúc: " .. camXucBat
        local choice = dialogChoice(title,
            "🔗 Nhập link bài viết", "👥 Số nick cần chạy: " .. INTERACT_NICKS,
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "🎲 Random cảm xúc: " .. (INTERACT_RANDOM == 1 and "BẬT ✅" or "TẮT ❌"),
            "👍 LIKE: " .. (INTERACT_LIKE == 1 and "BẬT ✅" or "TẮT ❌"),
            "❤️ TYM: " .. (INTERACT_TYM == 1 and "BẬT ✅" or "TẮT ❌"),
            "🥰 THƯƠNG THƯƠNG: " .. (INTERACT_THUONG == 1 and "BẬT ✅" or "TẮT ❌"),
            "😆 HAHA: " .. (INTERACT_HAHA == 1 and "BẬT ✅" or "TẮT ❌"),
            "😢 BUỒN: " .. (INTERACT_BUON == 1 and "BẬT ✅" or "TẮT ❌"),
            "🔢 Số lần lướt tìm: " .. INTERACT_MAX_ATTEMPTS,
            "⏳ Delay giữa các lần: " .. INTERACT_SCROLL_DELAY .. "s",
            "──────────────", "🚀 BẮT ĐẦU CHẠY", "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Nhập link") then
            local urlInput = dialogInput("Link bài viết", "Dán link bài viết vào đây:", INTERACT_URL)
            if urlInput and urlInput ~= "" then INTERACT_URL = urlInput end
        elseif choice:find("Số nick") then
            local n = dialogInput("Số nick cần chạy", "Nhập số lượng:", tostring(INTERACT_NICKS))
            if n and tonumber(n) then INTERACT_NICKS = tonumber(n) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT nick bắt đầu chạy:", tostring(NICK_BAT_DAU))
            if input then local num = tonumber(input)
                if num and num >= 0 then NICK_BAT_DAU = math.max(1, math.floor(num)) toast("🚩 Nick bắt đầu: " .. NICK_BAT_DAU)
                else toast("⚠️ Giá trị không hợp lệ!") end
            end
        elseif choice:find("Random") then INTERACT_RANDOM = (INTERACT_RANDOM == 1) and 0 or 1
        elseif choice:find("LIKE") then INTERACT_LIKE = (INTERACT_LIKE == 1) and 0 or 1
        elseif choice:find("TYM") then INTERACT_TYM = (INTERACT_TYM == 1) and 0 or 1
        elseif choice:find("THƯƠNG THƯƠNG") then INTERACT_THUONG = (INTERACT_THUONG == 1) and 0 or 1
        elseif choice:find("HAHA") then INTERACT_HAHA = (INTERACT_HAHA == 1) and 0 or 1
        elseif choice:find("BUỒN") then INTERACT_BUON = (INTERACT_BUON == 1) and 0 or 1
        elseif choice:find("Số lần lướt tìm") then
            local n = dialogInput("Số lần lướt tối đa", "Nhập số lần:", tostring(INTERACT_MAX_ATTEMPTS))
            if n and tonumber(n) then INTERACT_MAX_ATTEMPTS = math.floor(tonumber(n)) end
        elseif choice:find("Delay giữa các lần") then
            local n = dialogInput("Delay cuộn (giây)", "Nhập số giây:", tostring(INTERACT_SCROLL_DELAY))
            if n and tonumber(n) then INTERACT_SCROLL_DELAY = math.floor(tonumber(n)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            if INTERACT_URL == "" then toast("⚠️ Vui lòng nhập link bài viết!")
            else
                local confirm = dialogChoice("🚀 XÁC NHẬN CHẠY\n\n👥 Chạy: " .. INTERACT_NICKS .. " nick\n🎯 Random: " .. (INTERACT_RANDOM == 1 and "BẬT" or "TẮT"), "✅ Chạy ngay!", "◀️ Quay lại")
                if confirm and confirm:find("Chạy ngay") then luuCauHinh() return "interact_post" end
            end
        end
    end
end

print("✅ interact_post.lua đã nạp")