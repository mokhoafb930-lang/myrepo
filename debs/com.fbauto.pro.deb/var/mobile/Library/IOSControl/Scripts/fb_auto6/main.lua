-- ================================================================
-- FILE: main.lua - ENTRY POINT (Phiên bản hoàn thiện 100%)
-- ================================================================

-- 1. Nạp modules hệ thống & hằng số trước
require("config")
require("utils")
require("file_io")

-- 2. Kiểm tra điều khoản & Bản quyền trước khi nạp module logic
if not kiemTraDieuKhoan() then stop() return end
if not xacThucKey() then stop() return end

-- 3. Nạp các module logic (Thứ tự quan trọng)
require("crane")
require("fb_core")
require("nick_manager")
require("farm_data")  -- Nạp data trước farm logic
require("watch")     -- Nạp Watch trước Farm để có hàm farmWatch
require("farm")
require("nap_nick")
require("ket_ban_uid")
require("ket_ban_goi_y")
require("chap_nhan_kb")
require("interact_post")
require("comment")
require("share")
require("schedule")
require("watch")
require("join_group")
require("crane_manager")
require("menu_chinh")

-- 4. Khởi tạo môi trường
taoTatCaFileNoiDung()

-- 5. Vòng lặp Menu chính
while true do
    local cheDo = menuChinh()

    if cheDo == "join_group" then
        thucHienJoinGroup()
    elseif cheDo == "exit" or not cheDo then
        break
    elseif cheDo == "farm" then
        thucHienFarm()
    elseif cheDo == "ket_ban_uid" then
        thucHienKetBanUID()
    elseif cheDo == "ket_ban_goi_y" then
        thucHienKetBanGoiY()
    elseif cheDo == "chap_nhan_kb" then
        thucHienChapNhanKetBan()
    elseif cheDo == "nap_nick" then
        thucHienNapNick()
    elseif cheDo == "interact_post" then
        thucHienInteractPost()
    elseif cheDo == "cmt_bai_viet" then
        thucHienCMTBaiViet()
    elseif cheDo == "share_bai_viet" then
        thucHienShareBaiViet()
    elseif cheDo == "xem_watch_standalone" then
        thucHienWatch()
    elseif cheDo == "chay_tong_hop" then
        chayTongHopRunner()
    end

    logScreen("✅ Hoàn tất tác vụ, quay lại Menu...", true)
    sleep(2)
end