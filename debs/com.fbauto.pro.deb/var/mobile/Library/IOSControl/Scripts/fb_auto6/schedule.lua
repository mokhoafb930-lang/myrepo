-- ================================================================
-- FILE: schedule.lua - LẬP LỊCH TỰ ĐỘNG (dòng 5527-5915 gốc)
-- ================================================================

BAT_LAP_LICH = 0
THOI_GIAN_CHAY = "15:30"
SO_NICK_LL = 2
NICK_BAT_DAU_LL = 1
SO_NGAY_LL = 10
LAN_DA_CHAY_LL = 0
NGAY_BAT_DAU_LL = ""
CHUC_NANG_LL = "farm"
FARM_AVATAR = 1
FARM_COVER = 1
FARM_POST = 1
FARM_STORY = 0
FARM_NEWSFEED = 0
FARM_EDIT = 1

local function luuCauHinhLapLich()
    local f = io.open(CONFIG_FILE_LL, "w")
    if f then
        f:write("BAT_LAP_LICH=" .. BAT_LAP_LICH .. "\n")
        f:write("THOI_GIAN_CHAY=" .. THOI_GIAN_CHAY .. "\n")
        f:write("SO_NICK_LL=" .. SO_NICK_LL .. "\n")
        f:write("NICK_BAT_DAU_LL=" .. NICK_BAT_DAU_LL .. "\n")
        f:write("SO_NGAY_LL=" .. SO_NGAY_LL .. "\n")
        f:write("LAN_DA_CHAY_LL=" .. LAN_DA_CHAY_LL .. "\n")
        f:write("NGAY_BAT_DAU_LL=" .. NGAY_BAT_DAU_LL .. "\n")
        f:write("CHUC_NANG_LL=" .. CHUC_NANG_LL .. "\n")
        f:write("FARM_AVATAR=" .. FARM_AVATAR .. "\n")
        f:write("FARM_COVER=" .. FARM_COVER .. "\n")
        f:write("FARM_POST=" .. FARM_POST .. "\n")
        f:write("FARM_STORY=" .. FARM_STORY .. "\n")
        f:write("FARM_NEWSFEED=" .. FARM_NEWSFEED .. "\n")
        f:write("FARM_EDIT=" .. FARM_EDIT .. "\n")
        f:close() return true
    end
    return false
end

local function taiCauHinhLapLich()
    local f = io.open(CONFIG_FILE_LL, "r")
    if not f then return false end
    for line in f:lines() do
        local key, val = line:match("([^=]+)=(.*)")
        if key and val then
            if key == "BAT_LAP_LICH" then BAT_LAP_LICH = tonumber(val) or 0
            elseif key == "THOI_GIAN_CHAY" then THOI_GIAN_CHAY = val
            elseif key == "SO_NICK_LL" then SO_NICK_LL = tonumber(val) or 2
            elseif key == "NICK_BAT_DAU_LL" then NICK_BAT_DAU_LL = tonumber(val) or 1
            elseif key == "SO_NGAY_LL" then SO_NGAY_LL = tonumber(val) or 10
            elseif key == "LAN_DA_CHAY_LL" then LAN_DA_CHAY_LL = tonumber(val) or 0
            elseif key == "NGAY_BAT_DAU_LL" then NGAY_BAT_DAU_LL = val
            elseif key == "CHUC_NANG_LL" then CHUC_NANG_LL = val
            elseif key == "FARM_AVATAR" then FARM_AVATAR = tonumber(val) or 1
            elseif key == "FARM_COVER" then FARM_COVER = tonumber(val) or 1
            elseif key == "FARM_POST" then FARM_POST = tonumber(val) or 1
            elseif key == "FARM_STORY" then FARM_STORY = tonumber(val) or 0
            elseif key == "FARM_NEWSFEED" then FARM_NEWSFEED = tonumber(val) or 0
            elseif key == "FARM_EDIT" then FARM_EDIT = tonumber(val) or 1
            end
        end
    end
    f:close() return true
end

local function ghiLogLich(noiDung)
    local f = io.open(FILE_LOG_LL, "a")
    if not f then f = io.open(FILE_LOG_LL, "w") end
    if f then f:write("[" .. os.date("%Y-%m-%d %H:%M:%S") .. "] " .. noiDung .. "\n") f:close() end
    log("📝 " .. noiDung)
end

local function tenChucNangLL()
    local ten = {farm="🌾 FARM", ketban_uid="👤 KẾT BẠN UID", ketban_gy="👥 KẾT BẠN GỢI Ý",
        chapnhan="🤝 CHẤP NHẬN KB", nap="🔑 NẠP NICK", interact_post="🎯 TƯƠNG TÁC POST",
        cmt_bai_viet="💬 CMT BÀI VIẾT", share_bai_viet="🚀 CHIA SẺ POST"}
    return ten[CHUC_NANG_LL] or CHUC_NANG_LL
end

local function chonGio()
    local items = {} for i = 0, 23 do table.insert(items, string.format("%02d", i)) end
    local chon = dialogChoice("CHỌN GIỜ", unpack(items))
    return chon or string.sub(THOI_GIAN_CHAY, 1, 2)
end

local function chonPhut()
    local items1, items2, items3 = {}, {}, {}
    for i = 0, 19 do table.insert(items1, string.format("%02d", i)) end
    for i = 20, 39 do table.insert(items2, string.format("%02d", i)) end
    for i = 40, 59 do table.insert(items3, string.format("%02d", i)) end
    local chon = dialogChoice("PHÚT (0-19)", unpack(items1))
    if chon then return chon end
    chon = dialogChoice("PHÚT (20-39)", unpack(items2))
    if chon then return chon end
    chon = dialogChoice("PHÚT (40-59)", unpack(items3))
    return chon or string.sub(THOI_GIAN_CHAY, 4, 5)
end

local function chayChucNang()
    local oldNickBatDau = NICK_BAT_DAU
    NICK_BAT_DAU = NICK_BAT_DAU_LL
    ghiLogLich("BAT DAU chay: " .. tenChucNangLL())
    if CHUC_NANG_LL == "farm" then
        local old = {BAT_AVATAR, BAT_ANH_BIA, BAT_DANG_BAI, BAT_DANG_STORY, BAT_LUOT_NEWSFEED, BAT_EDIT_PROFILE}
        BAT_AVATAR = FARM_AVATAR BAT_ANH_BIA = FARM_COVER BAT_DANG_BAI = FARM_POST
        BAT_DANG_STORY = FARM_STORY BAT_LUOT_NEWSFEED = FARM_NEWSFEED BAT_EDIT_PROFILE = FARM_EDIT
        thucHienFarm()
        BAT_AVATAR = old[1] BAT_ANH_BIA = old[2] BAT_DANG_BAI = old[3]
        BAT_DANG_STORY = old[4] BAT_LUOT_NEWSFEED = old[5] BAT_EDIT_PROFILE = old[6]
    elseif CHUC_NANG_LL == "ketban_uid" then thucHienKetBanUID()
    elseif CHUC_NANG_LL == "ketban_gy" then thucHienKetBanGoiY()
    elseif CHUC_NANG_LL == "chapnhan" then thucHienChapNhanKetBan()
    elseif CHUC_NANG_LL == "nap" then thucHienNapNick()
    elseif CHUC_NANG_LL == "interact_post" then thucHienInteractPost()
    elseif CHUC_NANG_LL == "cmt_bai_viet" then thucHienCMTBaiViet()
    elseif CHUC_NANG_LL == "share_bai_viet" then thucHienShareBaiViet()
    end
    ghiLogLich("HOAN THANH: " .. tenChucNangLL())
    NICK_BAT_DAU = oldNickBatDau
end

local function trangThaiFarmLL()
    local s = {}
    s.avatar = (FARM_AVATAR == 1) and "✅" or "❌"
    s.cover = (FARM_COVER == 1) and "✅" or "❌"
    s.post = (FARM_POST == 1) and "✅" or "❌"
    s.story = (FARM_STORY == 1) and "✅" or "❌"
    s.newsfeed = (FARM_NEWSFEED == 1) and "✅" or "❌"
    s.edit = (FARM_EDIT == 1) and "✅" or "❌"
    return s
end

local function menuCaiFarmLL()
    while true do
        local st = trangThaiFarmLL()
        local title = "🌾 Cài farm (chế độ lịch)\n"
            .. "· " .. st.avatar .. " Avatar  · " .. st.cover .. " Ảnh bìa  · " .. st.post .. " Đăng bài\n"
            .. "· " .. st.story .. " Story  · " .. st.newsfeed .. " Newsfeed  · " .. st.edit .. " Hồ sơ"

        local chon = dialogChoice(title,
            "🖼️ Ảnh đại diện", "🖼️ Ảnh bìa", "📝 Đăng bài", "📸 Đăng Story",
            "📜 Lướt Newsfeed", "✏️ Sửa hồ sơ", "────────",
            "🟢 Bật tất cả", "🔴 Tắt tất cả", "◀️ Quay lại"
        )
        if not chon or chon:find("Quay lại") then luuCauHinhLapLich() return
        elseif chon:find("Ảnh đại diện") then FARM_AVATAR = (FARM_AVATAR == 1) and 0 or 1
        elseif chon:find("Ảnh bìa") then FARM_COVER = (FARM_COVER == 1) and 0 or 1
        elseif chon:find("Đăng bài") then FARM_POST = (FARM_POST == 1) and 0 or 1
        elseif chon:find("Đăng Story") then FARM_STORY = (FARM_STORY == 1) and 0 or 1
        elseif chon:find("Lướt Newsfeed") then FARM_NEWSFEED = (FARM_NEWSFEED == 1) and 0 or 1
        elseif chon:find("Sửa hồ sơ") then FARM_EDIT = (FARM_EDIT == 1) and 0 or 1
        elseif chon:find("Bật tất cả") then FARM_AVATAR=1; FARM_COVER=1; FARM_POST=1; FARM_STORY=1; FARM_NEWSFEED=1; FARM_EDIT=1
        elseif chon:find("Tắt tất cả") then FARM_AVATAR=0; FARM_COVER=0; FARM_POST=0; FARM_STORY=0; FARM_NEWSFEED=0; FARM_EDIT=0
        end
    end
end

local function kiemTraLich()
    taiCauHinhLapLich()
    if NGAY_BAT_DAU_LL == "" then NGAY_BAT_DAU_LL = os.date("%Y-%m-%d") luuCauHinhLapLich() end

    log("📋 THÔNG TIN LỊCH:")
    log("├─ " .. tenChucNangLL())
    log("├─ 📅 " .. SO_NGAY_LL .. " ngày")
    log("├─ ⏰ " .. THOI_GIAN_CHAY)
    log("├─ 📊 Đã chạy: " .. LAN_DA_CHAY_LL .. "/" .. SO_NGAY_LL)
    log("└─ 🔘 Trạng thái: " .. (BAT_LAP_LICH == 1 and "ĐANG BẬT" or "ĐANG TẮT"))

    if BAT_LAP_LICH == 0 then logScreen("⚠️ LỊCH ĐANG TẮT! VÀO MENU BẬT LÊN!", true) return end
    ghiLogLich("KHOI DONG LICH - " .. SO_NGAY_LL .. " ngay luc " .. THOI_GIAN_CHAY)
    local daChayHomNay = false local ngayDaChay = ""
    while BAT_LAP_LICH == 1 and LAN_DA_CHAY_LL < SO_NGAY_LL do
        local now = os.date("*t")
        local gioHienTai = string.format("%02d:%02d", now.hour, now.min)
        local ngayHomNay = string.format("%d-%02d-%02d", now.year, now.month, now.day)
        if ngayHomNay ~= ngayDaChay then daChayHomNay = false end
        if gioHienTai == THOI_GIAN_CHAY and not daChayHomNay then
            logScreen("📅 CHẠY LỊCH: " .. tenChucNangLL(), true)
            chayChucNang()
            LAN_DA_CHAY_LL = LAN_DA_CHAY_LL + 1 luuCauHinhLapLich()
            daChayHomNay = true ngayDaChay = ngayHomNay
            logScreen("✅ ĐÃ CHẠY XONG HÔM NAY! TIẾN ĐỘ: " .. LAN_DA_CHAY_LL .. "/" .. SO_NGAY_LL, true)
            nghi(120, "Nghỉ sau lịch hôm nay")
            if LAN_DA_CHAY_LL >= SO_NGAY_LL then 
                log("🎉 HOÀN THÀNH " .. SO_NGAY_LL .. " NGÀY LẬP LỊCH!")
                BAT_LAP_LICH = 0 luuCauHinhLapLich() break 
            end
        else
            if now.sec < 5 then
                logScreen("📅 TIẾN ĐỘ: " .. LAN_DA_CHAY_LL .. "/" .. SO_NGAY_LL .. " NGÀY\n💓 Chờ đến: " .. THOI_GIAN_CHAY .. " (Bây giờ: " .. gioHienTai .. ")", true)
            end
        end
        sleep(5)
    end
    log("⏹️ Đã kết thúc chế độ lập lịch!")
end

function menuLapLich()
    taiCauHinhLapLich()
    while true do
        local title = "⏰ Lập lịch [" .. (BAT_LAP_LICH == 1 and "✅ BẬT" or "❌ TẮT") .. "]\n"
            .. "· " .. tenChucNangLL() .. "  · " .. THOI_GIAN_CHAY .. "\n"
            .. "· " .. LAN_DA_CHAY_LL .. "/" .. SO_NGAY_LL .. " ngày"
        local choice = dialogChoice(title,
            "🔘 Bật/Tắt lịch", "🎯 Chọn chức năng", "🌾 Cài đặt Farm", "📅 Cài số ngày", "⏰ Cài giờ chạy",
            "🚩 Nick bắt đầu", "──────────────",
            "🧪 TEST (chạy 1 lần)", "🗑️ Reset tiến độ", "──────────────",
            "🚀 BẮT ĐẦU CHỜ LỊCH", "◀️ Quay lại")
        if not choice or choice:find("Quay lại") then return
        elseif choice:find("Bật/Tắt") then BAT_LAP_LICH = (BAT_LAP_LICH == 1) and 0 or 1 luuCauHinhLapLich()
        elseif choice:find("Chọn chức năng") then
            local cn = dialogChoice("CHỌN CHỨC NĂNG", "🌾 FARM", "👤 KẾT BẠN UID", "👥 KẾT BẠN GỢI Ý", "🤝 CHẤP NHẬN KB", "🔑 NẠP NICK", "🎯 TƯƠNG TÁC POST", "💬 CMT BÀI VIẾT", "🚀 CHIA SẺ POST")
            if cn then
                if cn:find("FARM") then CHUC_NANG_LL = "farm"
                elseif cn:find("KẾT BẠN UID") then CHUC_NANG_LL = "ketban_uid"
                elseif cn:find("KẾT BẠN GỢI Ý") then CHUC_NANG_LL = "ketban_gy"
                elseif cn:find("CHẤP NHẬN") then CHUC_NANG_LL = "chapnhan"
                elseif cn:find("NẠP NICK") then CHUC_NANG_LL = "nap"
                elseif cn:find("TƯƠNG TÁC") then CHUC_NANG_LL = "interact_post"
                elseif cn:find("CMT") then CHUC_NANG_LL = "cmt_bai_viet"
                elseif cn:find("CHIA SẺ") then CHUC_NANG_LL = "share_bai_viet" end
                luuCauHinhLapLich()
            end
        elseif choice:find("Cài đặt Farm") then
            if CHUC_NANG_LL == "farm" then menuCaiFarmLL()
            else toast("⚠️ Vui lòng chọn chức năng FARM trước!") end
        elseif choice:find("Cài số ngày") then
            local n = dialogInput("SỐ NGÀY", "Hiện tại: " .. SO_NGAY_LL)
            if n and tonumber(n) then SO_NGAY_LL = tonumber(n) luuCauHinhLapLich() end
        elseif choice:find("Cài giờ") then
            THOI_GIAN_CHAY = chonGio() .. ":" .. chonPhut() luuCauHinhLapLich()
        elseif choice:find("Nick bắt đầu") then
            local n = dialogInput("Nick bắt đầu", "STT:", tostring(NICK_BAT_DAU_LL))
            if n and tonumber(n) then NICK_BAT_DAU_LL = math.max(1, math.floor(tonumber(n))) luuCauHinhLapLich() end
        elseif choice:find("TEST") then chayChucNang()
        elseif choice:find("Reset") then LAN_DA_CHAY_LL = 0 NGAY_BAT_DAU_LL = os.date("%Y-%m-%d") luuCauHinhLapLich()
        elseif choice:find("BẮT ĐẦU CHỜ") then
            if BAT_LAP_LICH == 0 then toast("⚠️ Bật lịch trước!") else kiemTraLich() return end
        end
    end
end

print("✅ schedule.lua đã nạp")