-- ================================================================
-- FILE: nap_nick.lua - LOGIC NẠP NICK (Y hệt fb_auto_new.lua)
-- ================================================================

-- ========== HÀM HỖ TRỢ TÌM ẢNH (ĐỘ NHẠY 0.85) ==========
local function coAnh(imagePath)
    local x, y = findImage(imagePath, 1, 0.85)
    if x and y then
        log("✅ CÓ ảnh: " .. imagePath)
        return true
    else
        log("❌ KHÔNG có ảnh: " .. imagePath)
        return false
    end
end

-- ========== HÀM ĐẾM SỐ NICK TRONG FILE ==========
function demNickTrongFile()
    local f = io.open(ACCOUNT_FILE, "r")
    if not f then return 0 end
    local count = 0
    for line in f:lines() do
        if line ~= "" then count = count + 1 end
    end
    f:close()
    return count
end

-- ========== HÀM GHI NICK VÀO FILE ==========
function ghiNickVaoFile(line)
    local f = io.open(ACCOUNT_FILE, "a")
    if not f then return false end
    f:write(line .. "\n")
    f:close()
    return true
end

-- ========== HÀM LẤY UID TỪ DÒNG NICK ==========
local function layUIDTuDong(line)
    local uid = line:match("^([^|]+)")
    if uid then
        uid = uid:match("^%s*(.-)%s*$")
    end
    return uid
end

-- ========== HÀM KIỂM TRA LIVE UID ==========
function kiemTraLiveUID(uid)
    if not uid or uid == "" then return false, "Không có UID" end
    local ok, r = pcall(function()
        return httpGet("https://graph.facebook.com/" .. uid .. "/picture?redirect=false")
    end)
    if not ok then return false, "Lỗi kết nối" end
    local body = ""
    if type(r) == "table" then body = r.body or r.data or r[1] or ""
    elseif type(r) == "string" then body = r end

    local url = string.match(body, '"url"%s*:%s*"([^"]+)"')
    if url then
        local dieUrls = {
            "https://static.xx.fbcdn.net/rsrc.php/v4/yo/r/UlIqmHJn-SK.gif",
            "https://static.xx.fbcdn.net/rsrc.php/v4/yL/r/HsTZSDw4avx.gif",
            "https://static.xx.fbcdn.net/rsrc.php/v4/y-/r/IOC9bCk9Hhd.gif"
        }
        for _, du in ipairs(dieUrls) do if url == du then return false, "Nick DIE (URL mặc định)" end end
        if #url > 150 then return true, "Live" end
    end
    return false, "Nick DIE/Lỗi"
end

-- ========== MENU CHECK LIVE UID ==========
function menuCheckUID()
    while true do
        local soNick = demNickTrongFile()
        local choice = dialogChoice("🔍 Check Live/Die UID\n· Tổng nick: " .. soNick,
            "🗑️ Kiểm tra và xóa nick DIE",
            "📊 Xem lịch sử thống kê",
            "🗑️ Xóa toàn bộ thống kê",
            "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then break end

        if choice:find("Kiểm tra và xóa") then
            logScreen("🔍 BẮT ĐẦU CHECK LIVE/DIE...", true)
            local f = io.open(ACCOUNT_FILE, "r")
            if not f then toast("❌ Không mở được file!") break end
            local lines = {}
            for line in f:lines() do if line ~= "" then table.insert(lines, line) end end
            f:close()

            local live, die = {}, 0
            for i, line in ipairs(lines) do
                local uid = layUIDTuDong(line)
                if uid then
                    logScreen("⏳ Check (" .. i .. "/" .. #lines .. "): " .. uid, true)
                    local isLive = kiemTraLiveUID(uid)
                    if isLive then table.insert(live, line) else die = die + 1 end
                else table.insert(live, line) end
            end

            local fw = io.open(ACCOUNT_FILE, "w")
            if fw then fw:write(table.concat(live, "\n") .. "\n") fw:close() end
            dialogChoice("✅ XONG!\n\n✅ Live: " .. #live .. "\n❌ Die: " .. die .. "\n(Đã xóa nick DIE)", "OK")
        elseif choice:find("Xem lịch sử") then
            local f = io.open(THONG_KE_FILE, "r")
            if f then local c = f:read("*all") f:close() dialogChoice("📊 LỊCH SỬ\n\n" .. c, "Đóng") else toast("Trống!") end
        elseif choice:find("Xóa toàn bộ") then
            local fw = io.open(THONG_KE_FILE, "w") if fw then fw:close() toast("✅ Đã xóa!") end
        end
    end
end

-- ========== MENU NẠP NICK ==========
function menuNapNick()
    while true do
        local soNickCon = demNickTrongFile()
        local filename = ACCOUNT_FILE:match("([^/]+)$") or ACCOUNT_FILE
        local title = "🔑 Nạp nick\n"
            .. "· Nạp: " .. SO_NICK_CAN_DANG_NHAP .. " nick  · Còn: " .. soNickCon .. "\n"
            .. "· Nick bắt đầu: " .. NICK_BAT_DAU .. "\n"
            .. "· File: " .. filename

        local choice = dialogChoice(title,
            "➕ Thêm nick (nhập tay)",
            "📋 Dán nhiều nick",
            "👁️ Xem danh sách nick",
            "🗑️ Xóa tất cả nick",
            "🔍 Check Live UID",
            "──────────────",
            "📂 Đổi đường dẫn file",
            "🔢 Đổi số nick cần nạp",
            "🚩 Đổi nick bắt đầu: " .. NICK_BAT_DAU,
            "──────────────",
            "🚀 BẮT ĐẦU NẠP NICK",
            "◀️ Quay lại"
        )

        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Thêm nick") then
            local soThem = 0
            while true do
                local currentCount = demNickTrongFile()
                local uid = dialogInput("👤 THÊM NICK (#" .. (soThem + 1) .. ")", "Đã thêm: " .. soThem .. " | Trong file: " .. currentCount .. "\n\nNhập UID / email / SĐT\n(Bỏ trống để dừng)")
                if not uid or uid == "" then if soThem > 0 then toast("✅ Đã thêm " .. soThem .. " nick!") end break end
                local pass = dialogInput("🔐 Mật khẩu", "Nhập mật khẩu cho: " .. uid)
                if not pass or pass == "" then toast("⚠️ Bỏ qua nick!")
                else
                    local twofa = dialogInput("🔑 Secret 2FA", "Nhập secret 2FA cho: " .. uid) or ""
                    local line = uid .. "|" .. pass .. (twofa ~= "" and "|" .. twofa or "")
                    if ghiNickVaoFile(line) then soThem = soThem + 1 toast("✅ Đã thêm! Tổng: " .. demNickTrongFile()) end
                end
            end
        elseif choice:find("Dán nhiều") then
            local clip = getClipboard() or ""
            if clip == "" then toast("⚠️ Clipboard trống!")
            else
                local nicksMoi = {}
                for line in clip:gmatch("[^\r\n]+") do
                    local parts = {}
                    for p in line:gmatch("[^|]+") do table.insert(parts, p:match("^%s*(.-)%s*$")) end
                    if #parts >= 2 and parts[1] ~= "" and parts[2] ~= "" then
                        table.insert(nicksMoi, line)
                    end
                end
                if #nicksMoi > 0 then
                    for _, nl in ipairs(nicksMoi) do ghiNickVaoFile(nl) end
                    toast("✅ Đã nạp " .. #nicksMoi .. " nick!")
                else toast("⚠️ Không có nick hợp lệ!") end
            end
        elseif choice:find("Xem danh sách") then
            local f = io.open(ACCOUNT_FILE, "r")
            local allLines = {}
            if f then
                for line in f:lines() do if line ~= "" then table.insert(allLines, line) end end
                f:close()
            end

            if #allLines == 0 then
                dialogChoice("👁️ DANH SÁCH NICK\n\n📭 Hiện chưa có nick nào trong danh sách.", "Đóng")
            else
                local page = 1
                local pageSize = 15 -- Hiển thị 15 nick mỗi trang cho gọn
                while true do
                    local startIdx = (page - 1) * pageSize + 1
                    local endIdx = math.min(page * pageSize, #allLines)
                    local displayLines = {}
                    for i = startIdx, endIdx do
                        local line = allLines[i]
                        local parts = {}
                        for p in line:gmatch("[^|]+") do table.insert(parts, p:match("^%s*(.-)%s*$")) end

                        local uid = parts[1] or "???"
                        local pass = parts[2] or "???"
                        local twofa = parts[3] or "Không có"
                        local status = "⏳"
                        local note = ""

                        if line:find("thành công") then status = "✅"
                        elseif line:find("sai pass") or line:find("checkpoint") or line:find("lỗi") then status = "❌" end
                        if #parts >= 4 then note = " (" .. parts[#parts] .. ")" end

                        -- Hiển thị theo dạng thụt lề cho dễ nhìn
                        table.insert(displayLines, string.format("%02d. %s %s%s", i, status, uid, note))
                        table.insert(displayLines, string.format("    🔑 P: %s", pass))
                        if twofa ~= "" and twofa ~= "Không có" then
                            table.insert(displayLines, string.format("    🔐 2FA: %s", twofa))
                        end
                        table.insert(displayLines, "────────────────")
                    end

                    local totalPage = math.ceil(#allLines / pageSize)
                    local buttons = {"Đóng"}
                    if page < totalPage then table.insert(buttons, "Trang sau ➡️") end
                    if page > 1 then table.insert(buttons, "⬅️ Trang trước") end

                    local msg = string.format("👁️ DANH SÁCH NICK (%d/%d)\n📊 Tổng: %d nick\n%s\n\n%s", 
                                    page, totalPage, #allLines, "════════════════", table.concat(displayLines, "\n"))

                    local c = dialogChoice(msg, unpack(buttons))
                    if not c or c:find("Đóng") then break
                    elseif c:find("Trang sau") then page = page + 1
                    elseif c:find("Trang trước") then page = page - 1 end
                end
            end
        elseif choice:find("Xóa tất cả") then
            local confirm = dialogChoice("⚠️ XÁC NHẬN\nXóa sạch toàn bộ nick?", "🔥 Xóa ngay!", "Hủy")
            if confirm and confirm:find("Xóa ngay") then local fw = io.open(ACCOUNT_FILE, "w") if fw then fw:close() toast("🧹 Đã xóa!") end end
        elseif choice:find("Check Live UID") then menuCheckUID()
        elseif choice:find("Đổi đường dẫn") then
            local input = dialogInput("Đổi file", "Nhập đường dẫn file mới:", ACCOUNT_FILE)
            if input and input ~= "" then ACCOUNT_FILE = input end
        elseif choice:find("Đổi số nick") then
            local input = dialogInput("Số nick nạp", "Nhập số lượng:", tostring(SO_NICK_CAN_DANG_NHAP))
            if input and tonumber(input) then SO_NICK_CAN_DANG_NHAP = math.floor(tonumber(input)) end
        elseif choice:find("Đổi nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "Nhập STT:", tostring(NICK_BAT_DAU))
            if input and tonumber(input) then NICK_BAT_DAU = math.max(1, math.floor(tonumber(input))) end
        elseif choice:find("BẮT ĐẦU NẠP NICK") then return "nap_nick" end
    end
end

-- ================================================================
-- ║  HÀM THỰC HIỆN NẠP NICK (Y hệt fb_auto_new.lua)            ║
-- ================================================================
function thucHienNapNick()

    -- ========== HÀM RESET MẠNG (NẠP NICK) ==========
    local function resetMangNN()
        if _G.DANG_CHAY_LIEN_HOAN and _G.DA_RESET_MANG then
            log("🔄 Đã reset mạng cho nick này trước đó, bỏ qua.")
            return
        end
        _G.DA_RESET_MANG = true
        while true do
            local success, err = pcall(function()
                setAirplaneMode(true)
                nghi(3, "BẬT CHẾ ĐỘ MÁY BAY")
                setAirplaneMode(false)
                nghi(8, "ĐANG ĐỢI MẠNG")
            end)

            local newIP = "Không xác định"
            for retry = 1, 6 do
                newIP = getIP()
                if newIP ~= "Không xác định" then break end
                logScreen("⏳ Đang chờ lấy IP mới (" .. (retry*5) .. "s)...", true)
                sleep(5)
            end

            if newIP ~= "Không xác định" then
                log("✅ IP mới: " .. newIP)
                logScreen("✅ ĐỔI IP THÀNH CÔNG\n📡 IP Mới: " .. newIP, true)
                sleep(2)
                return true
            else
                logScreen("❌ KHÔNG LẤY ĐƯỢC IP, ĐANG THỬ LẠI...", true)
                log("❌ Khong lay duoc IP trong Nap Nick, dang thu lai...")
                sleep(2)
            end
        end
    end

    -- ========== CHUYỂN NICK (NẠP NICK) ==========
    local function chuyenNickNN()
        return chuyenNick()
    end

    -- ========== MỞ FACEBOOK (NẠP NICK) ==========
    local function moFacebookNN()
        log("📱 Dang mo Facebook...")
        local success, err = pcall(function()
            appRun("com.facebook.Facebook")
            sleep(10)
            log("✅ Da mo Facebook")
            sleep(8)
        end)

        if success then
            log("✅ Mo Facebook thanh cong")
            return true
        else
            log("❌ Mo Facebook that bai: " .. tostring(err))
            return false
        end
    end

    -- ========== ĐÓNG FACEBOOK (NẠP NICK) ==========
    local function dongFacebookNN()
        pcall(function()
            appKill("com.facebook.Facebook")
            sleep(3)
            log("✅ Da dong Facebook")
        end)
    end

    -- ========== HÀM LẤY MÃ 2FA TỪ SECRET ==========
    local function get2faFromSecret(secret)
        if not secret or secret == "" then return nil end
        log("🔄 Dang lay ma 2FA tu API...")
        local ok, r = pcall(function() return httpGet("https://2fa.live/tok/" .. secret) end)
        if not ok then return nil end
        local body = (type(r) == "table") and (r.body or r.data or r[1]) or r
        if not body then return nil end
        local code = tostring(body):match('"token"%s*:%s*"(.-)"')
        return code
    end

    -- ========== KIỂM TRA CẢNH BÁO AUTOMATED BEHAVIOR ==========
    local function checkCanhBaoAutomated()
        if findText("We suspect automated behavior", 2) then 
            log("⚠️ PHAT HIEN CANH BAO: Automated behavior")
            if findText("Dismiss", 2) then tapText("Dismiss", 3) sleep(2) end
        end
    end

    -- ========== KIỂM TRA MÀN HÌNH 2FA ==========
    local function kiemTra2FA()
        log("🔍 Kiem tra man hinh 2FA...")
        if findImage("crop_1776579755130.png", 1, 0.85) then
            log("👉 PHAT HIEN 2FA (bang hinh)")
            sleep(1)
            if findText("OK", 3) then tapText("OK", 5) sleep(2) end
            return true
        end
        if findText("Login Code Required", 3) then
            log("👉 PHAT HIEN 2FA (bang text)")
            sleep(1)
            if findText("OK", 3) then tapText("OK", 5) sleep(2) end
            return true
        end
        return false
    end

    -- ========== XỬ LÝ NHẬP MÃ 2FA ==========
    local function xuLy2FA(secret)
        log("⚠️ Bat dau xu ly 2FA...")
        sleep(1)
        if findText("Login code", 5) then tapText("Login code", 10) sleep(1)
        elseif findText("Mã đăng nhập", 5) then tapText("Mã đăng nhập", 10) sleep(1)
        else tap(200, 300) sleep(1) end

        local code = get2faFromSecret(secret)
        if not code then return false end
        inputText(code)
        sleep(1)
        if findText("Continue", 3) then tapText("Continue", 5)
        elseif findText("Log in", 3) then tapText("Log in", 5)
        elseif findText("Tiếp tục", 3) then tapText("Tiếp tục", 5)
        elseif findText("OK", 3) then tapText("OK", 5) end
        sleep(10)
        checkCanhBaoAutomated()
        return true
    end

    -- ========== XỬ LÝ NHẬP TÀI KHOẢN + 2FA ==========
    local function xuLyNhapTaiKhoan(uid, pass, twofa)
        logScreen("📝 ĐANG NHẬP TÀI KHOẢN: " .. uid, true)
        if findText("Phone number or email", 5) then tapText("Phone number or email", 10)
        elseif findText("Email or Phone Number", 5) then tapText("Email or Phone Number", 10)
        elseif findText("Số điện thoại hoặc email", 5) then tapText("Số điện thoại hoặc email", 10)
        else tap(224, 268) end
        sleep(2)
        inputText(uid)
        sleep(3)
        if tapImage("crop_1776574976548.png", 10, 1) then
        elseif findText("Next", 3) then tapText("Next", 5)
        elseif findText("Tiếp theo", 3) then tapText("Tiếp theo", 5)
        elseif findText("Tiếp tục", 3) then tapText("Tiếp tục", 5) end
        sleep(3)
        if findText("Password", 5) then tapText("Password", 10)
        elseif findText("Mật khẩu", 5) then tapText("Mật khẩu", 10)
        else tap(232, 343) end
        sleep(3)
        inputText(pass)
        sleep(3)
        if findText("Log In", 3) then tapText("Log In", 10)
        elseif findText("log in", 3) then tapText("log in", 10)
        elseif findText("Đăng nhập", 3) then tapText("Đăng nhập", 10)
        else tap(200, 500) end
        sleep(15)

        if coAnh("crop_1776575852885.png") then
            log("❌ Phát hiện ảnh lỗi: Sai pass hoặc Checkpoint")
            return false, "nick bị sai pass hoặc checkpoint"
        end
        checkCanhBaoAutomated()
        if kiemTra2FA() then
            if twofa and twofa ~= "" then
                if not xuLy2FA(twofa) then return false, "lỗi xử lý 2FA" end
                nghi(20, "Đang đợi load sau 2FA")
                findText("ok", 3) tapText("ok", 5) sleep(5)
            else return false, "thiếu mã 2FA" end
        else
            sleep(7)
            if findText("OK", 3) then tapText("OK", 5) sleep(2) end
            if findText("ok", 3) then tapText("ok", 5) sleep(7) end
        end
        return true, "đăng nhập thành công"
    end

    -- ========== TÌM NICK CHƯA XỬ LÝ ==========
    local function timNickChuaXuLy()
        local file = io.open(ACCOUNT_FILE, "r")
        if not file then return nil end
        local unprocessedLine = nil
        for line in file:lines() do
            if line ~= "" and not (line:find("thành công") or line:find("sai pass") or line:find("lỗi 2FA") or line:find("thiếu mã 2FA") or line:find("checkpoint")) then
                unprocessedLine = line break
            end
        end
        file:close()
        if not unprocessedLine then return nil end
        local parts = {}
        for part in string.gmatch(unprocessedLine, "[^|]+") do table.insert(parts, part) end
        local uid = parts[1] or ""
        local pass = parts[2] or ""
        local twofa = parts[3] or ""
        return uid:match("^%s*(.-)%s*$"), pass:match("^%s*(.-)%s*$"), twofa:match("^%s*(.-)%s*$"), unprocessedLine
    end

    -- ========== CẬP NHẬT TRẠNG THÁI NICK ==========
    local function capNhatTrangThaiNick(oldLine, statusMessage)
        local file = io.open(ACCOUNT_FILE, "r")
        if not file then return false end
        local allLines = {}
        for line in file:lines() do table.insert(allLines, line) end
        file:close()
        local updated = false
        local newLines = {}
        for _, line in ipairs(allLines) do
            if line == oldLine and not updated then
                table.insert(newLines, line .. "|" .. statusMessage)
                updated = true
            else table.insert(newLines, line) end
        end
        local fw = io.open(ACCOUNT_FILE, "w")
        if fw then fw:write(table.concat(newLines, "\n") .. "\n") fw:close() return true end
        return false
    end

    -- ========== KIỂM TRA CÒN NICK ==========
    local function conNick()
        local uid = timNickChuaXuLy()
        return uid ~= nil
    end

    -- ========== VÒNG LẶP CHÍNH ==========
    logScreen("🚀 BẮT ĐẦU NẠP NICK", true)
    local thanhCong, thatBai = 0, 0
    for lan = 1, SO_NICK_CAN_DANG_NHAP do
        logScreen("🚀 NICK " .. lan .. "/" .. SO_NICK_CAN_DANG_NHAP, true)
        if not conNick() then log("❌ HET NICK!") break end
        local uid, pass, twofa, oldLine = timNickChuaXuLy()
        if not uid then break end

        resetMangNN()
        local danhSachNick = layDanhSachCrane()
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx = ((lan - 1 + offset) % #danhSachNick) + 1
        chuyenNick(danhSachNick[idx] or "Default")

        if moFacebookNN() then
            local ok, msg = xuLyNhapTaiKhoan(uid, pass, twofa)
            if ok then thanhCong = thanhCong + 1 else thatBai = thatBai + 1 end
            capNhatTrangThaiNick(oldLine, msg)
            dongFacebookNN()
        else
            capNhatTrangThaiNick(oldLine, "lỗi không mở được ứng dụng")
            thatBai = thatBai + 1
        end
        if lan < SO_NICK_CAN_DANG_NHAP then nghi(10, "Nghỉ đợi nạp nick tiếp theo") end
    end
    logScreen("✅ HOÀN TẤT: TC:" .. thanhCong .. " TB:" .. thatBai, true)
end

print("✅ nap_nick.lua đã nạp (Bản 484 dòng - Có thẻ thông tin)")