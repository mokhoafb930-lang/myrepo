-- ================================================================
-- FILE: farm_data.lua - DỮ LIỆU NGẪU NHIÊN CHO FARM (Đầy đủ 100%)
-- Nguồn: fb_auto_new.lua dòng 3595-4256
-- ================================================================

-- ========== NỘI DUNG ĐĂNG BÀI (RẤT NHIỀU) ==========
NOI_DUNG_BAI_VIET = readLinesFromFile(POST_FILE_PATH, {
    -- Chủ đề buổi sáng (1-20)
    "Sáng nay thức dậy sớm hơn thường lệ một chút, pha ly cà phê rồi ngồi nhìn trời sáng dần. Những phút đầu ngày yên tĩnh như vậy luôn khiến đầu óc dễ chịu hơn nhiều.",
    "Một ngày mới lại bắt đầu, hy vọng mọi việc sẽ suôn sẻ. Chúc mọi người một ngày tốt lành! ☀️",
    "Thức dậy lúc 5h sáng, tập thể dục 30 phút, tắm nước ấm và bắt đầu ngày mới với năng lượng tràn đầy. 🔋",
    "Bình minh đẹp quá, tranh thủ chụp vài tấm ảnh lưu lại khoảnh khắc. Nắng sớm thật dễ chịu.",
    "Sáng nay không vội vàng, ngồi thư giãn nghe nhạc một lúc rồi mới bắt đầu công việc. Cảm giác thoải mái hơn hẳn.",
    "Thức dậy thấy trời đẹp, lòng cũng thấy vui vui. Một ngày mới tốt lành nhé mọi người!",
    "Ly cà phê sáng and bản nhạc yêu thích - khởi đầu hoàn hảo cho ngày mới. ☕🎵",
    "Sáng nay ra ban công hít thở không khí trong lành, thấy yêu đời hơn hẳn.",
    "Hôm nay dậy sớm hơn 15 phút, có thời gian làm mọi thứ chậm rãi hơn, cảm giác thật tuyệt.",
    "Buổi sáng thức dậy thấy mình còn sống, còn khỏe, còn người thương bên cạnh là đủ.",
    "Sáng nay uống cà phê ở quen quen, nhìn ra đường phố tấp nập, thấy mình may mắn vì được bình yên mỗi ngày.",
    "Bình minh đẹp như một bức tranh, thức dậy sớm để không bỏ lỡ khoảnh khắc tuyệt vời này.",
    "Hôm nay trời hửng nắng, cảm giác ấm áp tràn ngập căn phòng nhỏ.",
    "Sáng nay đọc được câu nói hay: Hãy bắt đầu ngày mới bằng lòng biết ơn.",
    "Thức dậy và mỉm cười vì hôm nay lại là một ngày mới đầy cơ hội.",
    "Một tách trà nóng, một cuốn sách hay - khởi đầu buổi sáng hoàn hảo.",
    "Sáng nay đi bộ dưới ánh nắng sớm, thấy tâm hồn nhẹ nhàng hơn.",
    "Hôm nay trời đẹp quá, thích hợp để bắt đầu những dự định mới.",
    "Thức dậy sớm để thấy cuộc sống tươi đẹp từ những điều giản đơn nhất.",
    "Buổi sáng trong lành, hãy hít thở thật sâu and mỉm cười thật tươi.",

    -- Chủ đề công việc (21-50)
    "Hôm nay công việc không quá nhiều nhưng vẫn đủ để bận rộn cả ngày. Dù hơi mệt nhưng cảm giác hoàn thành xong từng việc nhỏ cũng khiến tâm trạng khá tốt.",
    "Làm xong project đúng hạn, cảm giác nhẹ nhõm vô cùng. Tối nay được nghỉ ngơi rồi! 🎉",
    "Gặp đối tác mới, buổi làm việc khá hiệu quả. Hy vọng sẽ có nhiều cơ hội hợp tác trong tương lai.",
    "Học thêm được kỹ năng mới hôm nay, thấy bản thân tiến bộ từng ngày. Cố gắng không ngừng! 📚",
    "Làm việc nhóm hôm nay rất vui, mọi người phối hợp ăn ý, công việc tiến triển nhanh hơn dự kiến.",
    "Hôm nay giải quyết xong một đống việc tồn đọng, nhẹ cả người. Cuối tuần sẽ được nghỉ ngơi thật thoải mái.",
    "Công việc áp lực nhưng mình vẫn ổn. Cố lên nào!",
    "Nhận được lời khen từ sếp, vui quá! Cố gắng của mình đã được ghi nhận.",
    "Hôm nay dọn dẹp bàn làm việc, sắp xếp lại mọi thứ gọn gàng, làm việc thấy hứng khởi hơn hẳn.",
    "Mệt nhưng vui vì đã hoàn thành những việc quan trọng. Tạm biệt công việc, về nhà thư giãn thôi.",
    "Hôm nay được nghỉ làm, ở nhà làm việc cá nhân, cảm giác thật thoải mái.",
    "Đồng nghiệp thân thiện, môi trường làm việc tốt giúp mình có động lực mỗi ngày.",
    "Deadline gần kề, nhưng mình đã sẵn sàng. Sẽ cố gắng hết sức!",
    "Học thêm khóa học mới để nâng cao chuyên môn, tương lai sẽ rộng mở hơn.",
    "Công việc có đôi chút khó khăn, nhưng mình tin là sẽ vượt qua.",
    "Hôm nay nhận được thưởng, vui quá! Có thêm động lực để làm việc chăm chỉ hơn.",
    "Làm việc từ xa ở quán cà phê, vừa chill vừa hoàn thành công việc.",
    "Sếp giao nhiệm vụ mới, hơi lo nhưng đây là cơ hội để phát triển.",
    "Team building cuối tuần này, háo hức được đi chơi cùng đồng nghiệp.",
    "Học được mẹo quản lý thời gian mới, làm việc hiệu quả hơn hẳn.",
    "Hôm nay tan làm sớm, tranh thủ đi tập gym xả stress.",
    "Khách hàng khen dịch vụ tốt, tự hào về công ty quá!",
    "Làm xong việc khó nhất trong tuần, tâm trạng nhẹ tênh.",
    "Học hỏi được nhiều điều từ đồng nghiệp giỏi, biết ơn vì môi trường làm việc tuyệt vời.",
    "Hôm nay họp hành hiệu quả, mọi người đều đóng góp ý kiến hay.",
    "Mệt mỏi vì tăng ca, nhưng nghĩ đến tương lai thì thấy xứng đáng.",
    "Nhận email được tăng lương, phấn khích quá! Cố gắng được đền đáp.",
    "Làm việc với tinh thần lạc quan, mọi thứ trở nên dễ dàng hơn.",
    "Hôm nay là một ngày làm việc năng suất, hài lòng với bản thân.",
    "Được giao làm trưởng nhóm dự án nhỏ, hơi áp lực nhưng cũng hào hứng.",

    -- Chủ đề cảm xúc (51-80)
    "Có những ngày chẳng cần điều gì đặc biệt xảy ra, chỉ cần mọi thứ diễn ra bình thường, không áp lực và không phiền lòng là đã đủ vui rồi.",
    "Hôm nay tâm trạng khá ổn định, không quá vui nhưng cũng chẳng có gì buồn. Giữ được trạng thái cân bằng như vậy là tốt rồi.",
    "Buồn một chút, nhưng rồi cũng sẽ qua. Mai lại là một ngày mới tốt đẹp hơn. 💪",
    "Vui vì nhận được tin vui từ người thân. Gia đình là trên hết! ❤️",
    "Hôm nay hơi mệt mỏi, chắc do thiếu ngủ. Tối nay phải ngủ sớm mới được.",
    "Cảm thấy biết ơn vì những điều nhỏ nhặt quanh ta. Hạnh phúc đôi khi đến từ những thứ giản đơn nhất.",
    "Bỗng nhiên thấy nhớ nhà, nhớ mẹ. Chắc cuối tuần này phải về thăm mọi người thôi.",
    "Hôm nay có chút căng thẳng nhưng mọi thứ rồi sẽ ổn. Hít một hơi thật sâu and tiếp tục bước tiếp.",
    "Thấy lòng nhẹ nhàng khi hoàng hôn buông xuống. Một ngày nữa lại qua đi bình yên.",
    "Hạnh phúc là đây! Được ở bên cạnh những người mình yêu thương.",
    "Cô đơn đôi khi cũng không quá tệ, là lúc mình học cách yêu bản thân.",
    "Hôm nay cảm thấy yêu đời hơn vì được gặp lại bạn cũ.",
    "Niềm vui nhỏ: sáng nay được ăn món mình thích.",
    "Có những lúc im lặng lại là cách trả lời hay nhất.",
    "Cảm giác bình yên hiếm hoi khi được ngồi một mình nghe nhạc.",
    "Hôm nay trời mưa, tâm trạng hơi trầm nhưng cũng ổn.",
    "Vui vì làm được điều mình từng nghĩ là không thể.",
    "Học cách chấp nhận cảm xúc của chính mình, dù vui hay buồn.",
    "Cảm thấy may mắn vì có những người bạn tốt bên cạnh.",
    "Hôm nay thấy tự tin hơn về bản thân, cảm giác tuyệt vời!",
    "Mệt mỏi nhưng không sao, đời mà, lên xuống là bình thường.",
    "Hạnh phúc đến từ những điều nhỏ nhặt, như nhận được tin nhắn chúc ngủ ngon.",
    "Tự nhiên nhớ về kỷ niệm xưa, vui có buồn có, nhưng tất cả đều đẹp.",
    "Cảm giác thật dễ chịu khi được làm điều mình yêu thích.",
    "Hôm nay mình đã cười rất nhiều, đó là một ngày tốt.",
    "Có những bộn bề không tên, nhưng mọi thứ rồi sẽ qua.",
    "Thấy mình may mắn vì còn có thể mơ và còn có thể cố gắng.",
    "Tâm trạng hôm nay như một bản nhạc nhẹ nhàng, êm đềm.",
    "Ngày hôm nay có chút muộn phiền, mai sẽ tươi tỉnh lại.",
    "Cảm ơn cuộc sống đã cho tôi thêm một ngày để yêu thương.",

    -- Chủ đề thói quen & phát triển bản thân (81-110)
    "Dạo này đang cố gắng thay đổi lại giờ giấc sinh hoạt, ngủ sớm hơn để sáng dậy không còn cảm giác mệt như trước nữa.",
    "Đang học cách không suy nghĩ quá nhiều về những chuyện chưa xảy ra. Tập trung vào việc hiện tại thấy nhẹ đầu hơn rất nhiều.",
    "Mỗi ngày đọc 10 trang sách, học 5 từ mới tiếng Anh. Những thói quen nhỏ nhưng lâu dài sẽ tạo nên sự khác biệt.",
    "Tập thiền 15 phút mỗi tối, tâm trí thư thái and ngủ ngon hơn hẳn. Rất đáng để duy trì! 🧘",
    "Tập thể dục được 1 tháng rồi, thấy cơ thể khỏe khoắn hơn nhiều. Sẽ cố gắng duy trì thói quen này.",
    "Học được cách nói 'không' với những việc không cần thiết. Thời gian của mình cũng quý giá lắm chứ.",
    "Mỗi ngày một chút tiến bộ, không cần vội vàng. Chậm mà chắc.",
    "Bắt đầu học nấu ăn, tuy lóng ngóng nhưng vui lắm. Tự tay làm món mình thích thật tuyệt.",
    "Tập viết nhật ký mỗi tối, nhìn lại một ngày đã qua để biết mình đã sống thế nào.",
    "Đang học cách lắng nghe nhiều hơn, nói ít hơn. Cảm thấy các mối quan hệ cũng tốt lên.",
    "Mỗi sáng viết 3 điều biết ơn, cuộc sống trở nên tươi đẹp hơn.",
    "Học thêm kỹ năng mềm, thấy mình tự tin hơn trong giao tiếp.",
    "Tập thói quen dậy sớm, có thêm thời gian cho bản thân.",
    "Bỏ dần thói quen lướt điện thoại trước khi ngủ, ngủ ngon hơn hẳn.",
    "Mỗi tuần một mục tiêu nhỏ, hoàn thành rồi tự thưởng cho bản thân.",
    "Học cách sắp xếp thời gian hợp lý, cuộc sống không còn bừa bộn.",
    "Uống đủ nước mỗi ngày, làn da cải thiện rõ rệt.",
    "Tập luyện thể thao đều đặn, sức khỏe tốt hơn, tinh thần thoải mái.",
    "Học nấu món mới mỗi cuối tuần, vừa vui vừa ngon miệng.",
    "Đọc sách thay vì xem TV, thấy tâm hồn phong phú hơn.",
    "Tập tính kiên nhẫn, mọi việc từ từ rồi cũng sẽ ổn.",
    "Học cách quản lý chi tiêu, không còn lo thiếu tiền cuối tháng.",
    "Mỗi tháng một cuốn sách về phát triển bản thân, mở mang tầm mắt.",
    "Học cách tha thứ, lòng nhẹ nhàng hơn rất nhiều.",
    "Tập nói lời cảm ơn and xin lỗi đúng lúc, các mối quan hệ tốt đẹp hơn.",
    "Bắt đầu học một ngôn ngữ mới, khám phá văn hóa thú vị.",
    "Tập viết ra những suy nghĩ trong đầu, đầu óc sáng suốt hơn.",
    "Dọn dẹp nhà cửa mỗi ngày, sống gọn gàng ngăn nắp.",
    "Học cách yêu thương bản thân trước khi yêu người khác.",
    "Chăm sóc sức khỏe tinh thần, thiền định giúp tâm an lạc.",

    -- Chủ đề thời tiết (111-135)
    "Thời tiết hôm nay khá dễ chịu, có nắng nhẹ and chút gió mát nên làm gì cũng thấy có động lực hơn.",
    "Trời mưa cả ngày, ở nhà làm ly trà nóng nghe nhạc thư giãn. Cũng có cái thú vui riêng. ☕🎵",
    "Nắng đẹp quá, tranh thủ đi dạo công viên hóng gió. Thành phố hôm nay thật bình yên.",
    "Trời se se lạnh, mặc áo ấm đi dạo phố thấy dễ chịu vô cùng. Mùa đông đến rồi.",
    "Nóng quá, chỉ muốn ở nhà bật điều hòa thôi. Trời ơi đừng nóng nữa!",
    "Mưa rồi, thích nhất là mưa nhẹ nhàng, ngồi bên cửa sổ nhìn mưa rơi thật thư giãn.",
    "Hôm nay trời đẹp quá, không khí trong lành, thích hợp để đi chơi xa.",
    "Gió mùa về rồi, trời trở lạnh. Nhớ quàng thêm khăn ấm nhé mọi người.",
    "Trời đẹp quá, hãy ra ngoài tận hưởng cuộc sống này.",
    "Những cơn mưa rào mùa hạ đến rồi đi thật nhanh, không khí mát mẻ.",
    "Mây trắng bay trên bầu trời xanh, tâm hồn cũng thảnh thơi.",
    "Hoàng hôm nay đẹp quá, màu vàng cam ấm áp, thật bình yên.",
    "Sáng sớm có chút sương mù, không gian huyền ảo như chốn thần tiên.",
    "Trời trở gió rồi, mọi người nhớ giữ ấm cơ thể nhé.",
    "Nắng Sài Gòn chói chang, nhưng vẫn yêu cái nắng nơi đây.",
    "Mưa rơi lộp bộp ngoài hiên, nghe mà thấy ấm lòng khi ở trong nhà.",
    "Trời bắt đầu sang thu, lá vàng rơi lác đác, thơi mộng làm sao.",
    "Bão sắp đến, mọi người nhớ cẩn thận kẻo gió lớn.",
    "Sau cơn mưa trời lại sáng, cầu vồng xuất hiện, đẹp quá!",
    "Không khí se lạnh, thích nhất là được ngồi bên bếp lửa hồng.",
    "Nắng gắt quá, đi ra đường nhớ mặc áo chống nắng cẩn thận.",
    "Chiều buông, gió mát rượi, cảm giác thư giãn tuyệt vời sau một ngày dài.",
    "Mưa lớn quá, kẹt xe nhưng lòng vẫn vui vì sắp được về nhà.",
    "Trời đẹp quá, lên kế hoạch cho chuyến dã ngoại cuối tuần thôi.",
    "Gió lạnh mùa đông đã về, nhớ quàng khăn and mang găng tay nhé.",

    -- Chủ đề cuối ngày (136-165)
    "Một ngày trôi qua nhanh thật, mới đó mà đã gần tối. Vẫn còn vài việc chưa xong nhưng thôi cứ để mai tiếp tục.",
    "Tối nay nấu món mới, tuy chưa ngon lắm nhưng vui vì được tự tay làm. Dần dần sẽ cải thiện thôi.",
    "Cảm ơn một ngày dài đã trôi qua bình an. Chúc mọi người ngủ ngon! 🌙",
    "Hôm nay cũng đã cố gắng hết khả năng của mình rồi nên không cần tạo thêm áp lực nữa.",
    "Mọi thứ không phải lúc nào cũng đúng kế hoạch nhưng đôi khi như vậy lại tốt, giúp mình học cách linh hoạt hơn.",
    "Buổi sáng bắt đầu bằng ly cà phê nóng and chút nắng ngoài hiên thật sự khiến tâm trạng tốt hơn nhiều.",
    "Hôm nay tuy hơi bận nhưng mọi việc đều đang dần tiến triển tốt. Chậm một chút cũng không sao.",
    "Đang tập thói quen sống chậm lại để cảm nhận mọi thứ rõ hơn.",
    "Một ngày bình thường nhưng không hề vô nghĩa. Chỉ cần còn sức khỏe là đã đáng quý rồi.",
    "Tối rồi, tắt điện thoại thư giãn. Cảm giác không bị làm phiền thật tuyệt.",
    "Vừa xem xong một bộ phim hay, tâm trạng thật tốt. Chúc mọi người ngủ ngon.",
    "Ngày hôm nay đã kết thúc, mai lại bắt đầu một ngày mới. Hẹn gặp lại!",
    "Hoàng hôn buông xuống, khép lại một ngày dài, thở phào nhẹ nhõm.",
    "Tối nay trăng tròn, đẹp quá, ngồi ngắm trăng một lúc rồi đi ngủ.",
    "Mặc dù mệt nhưng nhìn lại việc đã làm, thấy hài lòng với chính mình.",
    "Cuối ngày rồi, hãy buông bỏ những ưu phiền, giữ lại những điều tốt đẹp.",
    "Tạm biệt ngày hôm nay, hẹn gặp mặt trời ngày mai.",
    "Tối nay không làm gì cả, chỉ nằm dài and nghỉ ngơi sau một tuần bận rộn.",
    "Nhâm nhi tách trà nóng cuối ngày, lòng thư thái hơn bao giờ hết.",
    "Ngày mới bắt đầu bằng nụ cười, kết thúc bằng sự bình yên.",
    "Cảm ơn bản thân đã cố gắng hết sức hôm nay, nghỉ ngơi thật tốt nhé.",
    "Tối rồi, nhắn tin cho người thương: An ngủ ngon nhé!",
    "Mệt lắm rồi, tôi đi ngủ đây, mai tiếp tục chiến đấu tiếp.",
    "Chuẩn bị đi ngủ sớm, ngày mai dậy sớm tập thể dục.",
    "Tối nay nấu cơm mời cả nhà, hạnh phúc đơn giản lắm.",
    "Ngày hôm nay trôi qua êm đềm, biết ơn cuộc sống.",
    "Đã đến lúc tắt máy tính, tắt điện thoại and thực sự nghỉ ngơi.",
    "Hoàn thành hết việc trong to do list, cảm giác nhẹ nhõm vô cùng.",
    "Trời tối rồi, đường phố lên đèn, thành phố về đêm thật lung linh.",
    "Một ngày nữa lại trôi qua, hãy sống trọn vẹn từng khoảnh khắc.",

    -- Chủ đề du lịch & giải trí (166-200)
    "Đang lên kế hoạch cho chuyến đi cuối tuần tới. Phượt cùng bạn bè thì còn gì bằng! 🏍️",
    "Nhìn lại ảnh chuyến đi Đà Lạt tháng trước, nhớ quá. Chắc phải sắp xếp đi tiếp thôi.",
    "Biển ơi! Sắp được nghỉ dưỡng ở biển rồi, háo hức quá! 🏖️",
    "Cuối tuần này đi cắm trại cùng bạn bè, chuẩn bị đồ đạc thật đầy đủ nào.",
    "Khám phá một quán cà phê mới, không gian đẹp, đồ uống ngon, điểm đến lý tưởng cho ngày cuối tuần.",
    "Đi bộ dọc bờ biển lúc chiều tối, gió mát quá, thấy lòng thư thái.",
    "Leo núi mệt thật nhưng lên đến đỉnh ngắm cảnh thì xứng đáng quá!",
    "Đi chợ đêm ăn vặt thỏa thích, ẩm thực đường phố Việt Nam tuyệt vời quá!",
    "Cuộc sống không phải lúc nào cũng dễ dàng, nhưng mình có thể chọn cách đối diện với nó.",
    "Mỉm cười lên nào, ngày mới lại bắt đầu with bao điều tốt đẹp đang chờ đón.",
    "Yêu thương bắt đầu từ chính mình",
    "Cho đi yêu thương, nhận lại bình an",
    "Sống có mục tiêu, có đam mê",
    "Học cách buông bỏ những điều không cần thiết",
    "Mỗi người đều có giá trị riêng",
    "Hãy sống như ngày mai không bao giờ đến",
    "Đừng để nỗi sợ ngăn cản bạn",
    "Bạn mạnh mẽ hơn bạn nghĩ",
    "Hãy tin vào phép màu của sự cố gắng",
})

-- ========== TIỂU SỬ NGẪU NHIÊN (40+ câu) ==========
TIEU_SU_RANDOM = readLinesFromFile(BIO_FILE_PATH, {
    "Yêu thương và bình an! ❤️", "Sống là để trải nghiệm 🌟", "Hạnh phúc là ở hiện tại 🥰",
    "Cảm ơn cuộc sống! 🙏", "Mỗi ngày là một món quà 🎁", "Sống tích cực mỗi ngày ✨",
    "Làm điều mình thích, yêu điều mình làm 💯", "Cuộc đời ngắn, đừng sống nhạt nhòa 🎨",
    "Thành công không phải đích đến, mà là hành trình 🚀", "Hãy là bản thể tốt nhất của chính mình 💪",
    "Tận hưởng từng khoảnh khắc 🕰️", "Sống đơn giản, nghĩ tích cực 😊", "Cho đi là còn mãi 🤝",
    "Mỉm cười vì mình đang sống 😄", "Bình yên trong tâm hồn 🕊️", "Đủ là hạnh phúc 🍀",
    "Học hôm nay để sống ngày mai 📖", "Sống chậm, yêu thương nhiều 💕",
    "Mỗi người một con đường, hãy đi con đường của mình 🛤️", "Thành công là khi bạn dám bắt đầu 🌈",
    "Cố gắng hôm nay, thành công ngày mai", "Yêu đời, yêu người, yêu bản thân", "Sống không hối tiếc",
    "Mỗi ngày đều là một khởi đầu mới", "Hạnh phúc không phải đích đến, mà là cách ta đi",
    "Đơn giản là đẹp", "Sống thật, yêu thật", "Tâm an, lòng vui", "Buông bỏ để nhẹ lòng",
    "Học cách tha thứ cho chính mình", "Trân trọng những gì mình đang có", "Biết ơn mỗi ngày bình an",
    "Hãy cứ là chính bạn, phần còn lại hãy để thời gian", "Sống không phải để hơn ai, mà để hơn chính mình ngày hôm qua",
    "Im lặng đôi khi là câu trả lời tốt nhất", "Chậm lại một chút, cuộc sống vẫn đẹp",
    "Tập trung vào điều quan trọng", "Đừng để những điều nhỏ nhặt làm hỏng ngày của bạn",
    "Hãy để nỗi buồn ngủ yên, và để niềm vui thức dậy", "Sống cho hiện tại, vì quá khứ đã qua, tương lai chưa tới",
    "Yêu thương bắt đầu từ chính mình", "Cho đi yêu thương, nhận lại bình an", "Sống có mục tiêu, có đam mê",
    "Học cách buông bỏ những điều không cần thiết", "Mỗi người đều có giá trị riêng",
    "Hãy sống như ngày mai không bao giờ đến", "Đừng để nỗi sợ ngăn cản bạn", "Bạn mạnh mẽ hơn bạn nghĩ",
    "Hãy tin vào phép màu của sự cố gắng",
})

-- ========== DANH SÁCH CÔNG VIỆC (100+ items) ==========
DANH_SACH_CONG_VIEC = readLinesFromFile(WORK_FILE_PATH, {
    -- IT & Công nghệ
    "Kỹ sư phần mềm", "Developer", "Lập trình viên", "Kỹ thuật viên", "Quản lý dự án",
    "Trưởng phòng kỹ thuật", "Giám đốc công nghệ", "Chuyên viên phân tích dữ liệu",
    "Kỹ sư AI", "Chuyên gia bảo mật", "Kỹ sư DevOps", "Thiết kế UI/UX", "Quản trị hệ thống",
    "Lập trình viên Frontend", "Lập trình viên Backend", "Lập trình viên Fullstack",
    "Kỹ sư cầu nối", "Chuyên viên kiểm thử", "Quản trị cơ sở dữ liệu", "Kỹ sư mạng",
    "Chuyên gia điện toán đám mây", "Kỹ sư Blockchain", "Lập trình viên Game",
    "Kỹ sư nhúng", "Chuyên gia IoT",

    -- Kinh doanh & Marketing
    "Kinh doanh", "Marketing", "Nhân viên kinh doanh", "Trưởng phòng kinh doanh",
    "Giám đốc kinh doanh", "Chuyên viên Marketing online", "Chuyên viên SEO",
    "Chuyên viên truyền thông", "Content Creator", "Quản lý thương hiệu",
    "Chuyên viên quảng cáo", "Trưởng nhóm sales", "Chăm sóc khách hàng",
    "Phát triển thị trường", "Chuyên viên xuất nhập khẩu",

    -- Hành chính - Văn phòng
    "Nhân viên văn phòng", "Hành chính nhân sự", "Lễ tân", "Thư ký", "Trợ lý giám đốc",
    "Quản lý văn phòng", "Chuyên viên tuyển dụng", "Chuyên viên đào tạo",
    "Chuyên viên lương thưởng", "Chuyên viên pháp chế",

    -- Giáo dục
    "Giáo viên", "Giảng viên đại học", "Gia sư", "Trợ giảng", "Hiệu trưởng",
    "Chuyên viên giáo dục", "Tư vấn giáo dục",

    -- Y tế
    "Bác sĩ", "Y tá", "Dược sĩ", "Kỹ thuật viên xét nghiệm", "Bác sĩ đa khoa",
    "Bác sĩ răng hàm mặt", "Chuyên viên vật lý trị liệu", "Điều dưỡng",

    -- Tài chính - Kế toán
    "Kế toán", "Tư vấn tài chính", "Kiểm toán", "Chuyên viên tín dụng",
    "Giao dịch viên ngân hàng", "Quản lý tài chính", "Chuyên viên đầu tư",
    "Môi giới chứng khoán", "Tư vấn bảo hiểm",

    -- Bất động sản - Xây dựng
    "Bất động sản", "Kỹ sư xây dựng", "Kiến trúc sư", "Thiết kế nội thất",
    "Giám sát công trình", "Thầu xây dựng", "Chuyên viên định giá",
    "Quản lý dự án xây dựng",

    -- Nghệ thuật - Sáng tạo
    "Nhiếp ảnh gia", "Nhà văn", "Họa sĩ", "Nhạc sĩ", "Ca sĩ", "Diễn viên",
    "Đạo diễn", "Biên kịch", "MC", "Biên tập viên", "Nhà báo",
    "Designer đồ họa", "Thiết kế thời trang", "Makeup artist", "Stylist",

    -- Dịch vụ - Khác
    "Freelancer", "Doanh nhân", "Startup Founder", "Chủ doanh nghiệp",
    "Quản lý nhà hàng", "Pha chế", "Đầu bếp", "Lái xe",
    "Hướng dẫn viên du lịch", "Phiên dịch viên", "Thông dịch viên",
    "Chuyên viên logistics", "Nhân viên bán hàng", "Chăm sóc khách hàng", "Tư vấn viên",
})

-- ========== DANH SÁCH TRƯỜNG HỌC (100+ items) ==========
DANH_SACH_TRUONG = readLinesFromFile(SCHOOL_FILE_PATH, {
    -- THPT TP.HCM
    "THPT Chuyên Lê Hồng Phong", "THPT Nguyễn Thượng Hiền", "THPT Bùi Thị Xuân",
    "THPT Trần Phú", "THPT Phan Đăng Lưu", "THPT Lê Quý Đôn", "THPT Marie Curie",
    "THPT Nguyễn Du", "THPT Gia Định", "THPT Ernst Thälmann", "THPT Lê Thánh Tôn",
    "THPT Nguyễn Hữu Cầu", "THPT Hùng Vương", "THPT Võ Thị Sáu", "THPT Trưng Vương",
    "THPT Nguyễn Thị Minh Khai", "THPT Phú Nhuận", "THPT Trần Khai Nguyên",
    "THPT Nguyễn Công Trứ", "THPT Mạc Đĩnh Chi",

    -- THPT Hà Nội
    "THPT Chuyên Hà Nội - Amsterdam", "THPT Chu Văn An", "THPT Kim Liên",
    "THPT Việt Đức", "THPT Trần Phú - Hà Nội", "THPT Phan Đình Phùng",
    "THPT Nguyễn Huệ", "THPT Thăng Long", "THPT Lê Quý Đôn - Hà Nội", "THPT Quang Trung",

    -- THPT Đà Nẵng
    "THPT Chuyên Lê Quý Đôn Đà Nẵng", "THPT Phan Châu Trinh", "THPT Trần Phú Đà Nẵng",
    "THPT Liên Chiểu", "THPT Hòa Vang",

    -- Đại học TP.HCM
    "Đại học Bách Khoa TP.HCM", "Đại học Khoa học Tự nhiên", "Đại học Kinh tế TP.HCM",
    "Đại học Sư phạm TP.HCM", "Đại học Y Dược TP.HCM", "Đại học Ngoại thương cơ sở 2",
    "Đại học Quốc gia TP.HCM", "Đại học Công nghệ Thông tin", "Đại học Ngân hàng TP.HCM",
    "Đại học Tôn Đức Thắng", "Đại học RMIT Việt Nam", "Đại học FPT TP.HCM",
    "Đại học Hoa Sen", "Đại học Văn Lang", "Đại học Công nghiệp TP.HCM",
    "Đại học Giao thông Vận tải TP.HCM", "Đại học Luật TP.HCM", "Đại học Mở TP.HCM",
    "Đại học Tài chính Marketing", "Đại học Sài Gòn", "Đại học Văn Hiến",
    "Đại học Nông Lâm TP.HCM",

    -- Đại học Hà Nội
    "Đại học Bách Khoa Hà Nội", "Đại học Quốc gia Hà Nội", "Đại học Kinh tế Quốc dân",
    "Đại học Ngoại thương", "Đại học Y Hà Nội", "Học viện Công nghệ Bưu chính Viễn thông",
    "Đại học Xây dựng", "Đại học Dược Hà Nội", "Đại học Luật Hà Nội",
    "Học viện Tài chính", "Đại học Thương mại", "Đại học Khoa học Xã hội và Nhân văn",
    "Đại học Công đoàn",

    -- Đại học Đà Nẵng
    "Đại học Bách Khoa Đà Nẵng", "Đại học Kinh tế Đà Nẵng", "Đại học Sư phạm Đà Nẵng",
    "Đại học Ngoại ngữ Đà Nẵng", "Đại học Duy Tân", "Đại học Đông Á",

    -- Đại học các tỉnh khác
    "Đại học Cần Thơ", "Đại học Nha Trang", "Đại học Huế", "Đại học Đà Lạt",
    "Đại học Vinh", "Đại học Quy Nhơn", "Đại học Tây Nguyên", "Đại học Hải Phòng",

    -- Cao đẳng
    "Cao đẳng Kỹ thuật Cao Thắng", "Cao đẳng Kinh tế Đối ngoại",
    "Cao đẳng Công thương TP.HCM", "Cao đẳng Sư phạm TP.HCM", "Cao đẳng Nghề TP.HCM",
    "Cao đẳng Viễn Đông", "Cao đẳng Văn hóa Nghệ thuật",

    -- Trường nghề
    "Trung cấp Nghề TP.HCM", "Trung cấp Kỹ thuật Nguyễn Hữu Cảnh",
    "Trung cấp Kinh tế Kỹ thuật", "Trung cấp Du lịch", "Trung cấp Y tế",
})

-- ========== THÀNH PHỐ (RẤT NHIỀU) ==========
DANH_SACH_THANH_PHO = readLinesFromFile(CITY_FILE_PATH, {
    -- Thành phố trực thuộc trung ương
    "Thành phố Hồ Chí Minh", "Hà Nội", "Đà Nẵng", "Hải Phòng", "Cần Thơ",

    -- Tỉnh miền Bắc
    "Hạ Long, Quảng Ninh", "Nam Định", "Thái Bình", "Hưng Yên", "Hải Dương",
    "Bắc Ninh", "Bắc Giang", "Vĩnh Yên, Vĩnh Phúc", "Việt Trì, Phú Thọ",
    "Hòa Bình", "Sơn La", "Điện Biên Phủ, Điện Biên", "Lai Châu", "Lào Cai",
    "Yên Bái", "Tuyên Quang", "Hà Giang", "Cao Bằng", "Lạng Sơn", "Thái Nguyên",
    "Phủ Lý, Hà Nam", "Ninh Bình", "Thanh Hóa",

    -- Tỉnh miền Trung
    "Vinh, Nghệ An", "Hà Tĩnh", "Đồng Hới, Quảng Bình", "Đông Hà, Quảng Trị",
    "Huế, Thừa Thiên Huế", "Hội An, Quảng Nam", "Tam Kỳ, Quảng Nam",
    "Quảng Ngãi", "Pleiku, Gia Lai", "Kon Tum", "Quy Nhơn, Bình Định",
    "Tuy Hòa, Phú Yên", "Nha Trang, Khánh Hòa", "Cam Ranh, Khánh Hòa",
    "Phan Rang - Tháp Chàm, Ninh Thuận", "Phan Thiết, Bình Thuận",
    "Buôn Ma Thuột, Đắk Lắk", "Gia Nghĩa, Đắk Nông", "Đà Lạt, Lâm Đồng",
    "Bảo Lộc, Lâm Đồng",

    -- Tỉnh miền Tây Nam Bộ
    "Long Xuyên, An Giang", "Châu Đốc, An Giang", "Rạch Giá, Kiên Giang",
    "Hà Tiên, Kiên Giang", "Phú Quốc, Kiên Giang", "Mỹ Tho, Tiền Giang",
    "Bến Tre", "Trà Vinh", "Vĩnh Long", "Sa Đéc, Đồng Tháp", "Cao Lãnh, Đồng Tháp",
    "Tân An, Long An", "Bạc Liêu", "Cà Mau", "Sóc Trăng", "Hậu Giang",
    "Ngã Bảy, Hậu Giang", "Thủ Dầu Một, Bình Dương", "Biên Hòa, Đồng Nai",
    "Bà Rịa, Bà Rịa - Vũng Tàu", "Vũng Tàu", "Tây Ninh", "Đồng Xoài, Bình Phước",
})

-- ========== QUÊ QUÁN (RIÊNG - RẤT NHIỀU) ==========
DANH_SACH_QUE_QUAN = {
    -- Miền Bắc
    "Hà Nội", "Hải Phòng", "Nam Định", "Thái Bình", "Hưng Yên", "Hải Dương",
    "Bắc Ninh", "Bắc Giang", "Vĩnh Phúc", "Phú Thọ", "Hòa Bình", "Sơn La",
    "Điện Biên", "Lai Châu", "Lào Cai", "Yên Bái", "Tuyên Quang", "Hà Giang",
    "Cao Bằng", "Lạng Sơn", "Thái Nguyên", "Hà Nam", "Ninh Bình", "Thanh Hóa",
    "Quảng Ninh",

    -- Miền Trung
    "Nghệ An", "Hà Tĩnh", "Quảng Bình", "Quảng Trị", "Thừa Thiên Huế",
    "Quảng Nam", "Đà Nẵng", "Quảng Ngãi", "Gia Lai", "Kon Tum", "Bình Định",
    "Phú Yên", "Khánh Hòa", "Ninh Thuận", "Bình Thuận", "Đắk Lắk", "Đắk Nông",
    "Lâm Đồng",

    -- Miền Nam
    "Thành phố Hồ Chí Minh", "Cần Thơ", "An Giang", "Kiên Giang", "Tiền Giang",
    "Bến Tre", "Trà Vinh", "Vĩnh Long", "Đồng Tháp", "Long An", "Bạc Liêu",
    "Cà Mau", "Sóc Trăng", "Hậu Giang", "Bình Dương", "Đồng Nai",
    "Bà Rịa - Vũng Tàu", "Tây Ninh", "Bình Phước",
}

-- ========== RELATIONSHIP STATUS (9 items) ==========
DANH_SACH_RELATIONSHIP = readLinesFromFile(RELA_FILE_PATH, {
    "Single", "In a relationship", "Engaged", "Married", "In a civil union",
    "In a domestic partnership", "In an open relationship", "It's complicated", "Separated"
})

print("✅ farm_data.lua đã cập nhật đầy đủ 100% dữ liệu")