-- ================================================================
-- FILE: share.lua - CHIA SẺ BÀI VIẾT CHỈ ĐỊNH
-- Nguồn: fb_auto_new.lua dòng 2554-2735
-- ================================================================

-- ========== THỰC HIỆN CHIA SẺ ========== (dòng 2558-2666)
function thucHienShareBaiViet()
    local shareButtonImage = "crop_1777348725692.png"
    logScreen("────────────────────\n🚀 BẮT ĐẦU CHIA SẺ BÀI VIẾT\n────────────────────", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + SHARE_SO_NICK), true)
    log("👥 Số nick: " .. SHARE_SO_NICK)
    log("🔗 URL: " .. SHARE_URL)

    local danhSachNick = layDanhSachCrane()
    for nickIndex = 1, SHARE_SO_NICK do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end
        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. SHARE_SO_NICK .. " | 📂 " .. tenPhanVung, true)
        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang() sleep(1)
            chuyenNick(tenPhanVung) sleep(1)
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not moFacebook() then
            log("⚠️ Lỗi mở Facebook, bỏ qua nick này")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            log("📱 Đang mở bài viết...")
            openURL(SHARE_URL) sleep(5)
            log("✅ Đã mở bài viết") sleep(2)

            local tapSuccess = false
            for attempt = 1, SHARE_MAX_ATTEMPTS do
                logScreen("🔍 Tìm nút Chia sẻ (" .. attempt .. "/" .. SHARE_MAX_ATTEMPTS .. ")", true)
                local x, y = findImage(shareButtonImage, 1)
                if x and y then
                    log("✅ Tìm thấy nút Chia sẻ tại: (" .. x .. ", " .. y .. ")")
                    sleep(SHARE_TAP_DELAY)
                    local result = tapImage(shareButtonImage, 3, 1)
                    if result then
                        log("✅ Đã tap nút Chia sẻ")
                        for check = 1, SHARE_MAX_CHECK do
                            sleep(2)
                            if findText("Say something about this", 1) or findText("say something about this", 1) then
                                log("✅ Thấy menu chia sẻ!")
                                tapSuccess = true
                                break
                            else
                                if check < SHARE_MAX_CHECK then
                                    log("⚠️ Chưa thấy menu, tap lại tọa độ...")
                                    tap(x, y)
                                end
                            end
                        end
                        break
                    else
                        log("⚠️ Không tap được, lướt nhẹ lên...")
                        swipe(200, 400, 200, 300, 0.5) sleep(1)
                        result = tapImage(shareButtonImage, 3, 1)
                        if result then tapSuccess = true break end
                    end
                else
                    if attempt < SHARE_MAX_ATTEMPTS then
                        swipe(200, 500, 200, 200, 1) sleep(SHARE_SCROLL_DELAY)
                    end
                end
            end

            if tapSuccess then
                sleep(2)
                if findText("Friends", 1) then
                    tapText("Friends", 5, 1) sleep(2)
                    tapText("Public", 5, 1) sleep(1)
                    tapText("Done", 5, 1) sleep(2)
                end
                tapText("Share Now", 5, 1) sleep(7)
                logScreen("✅ ĐÃ CHIA SẺ THÀNH CÔNG! (" .. nickIndex .. "/" .. SHARE_SO_NICK .. ")", true)
            else
                logScreen("❌ Không thể chia sẻ bài viết!", true)
            end
        end
        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < SHARE_SO_NICK then nghi(5, "Nghỉ đổi nick") end
        end
    end
    logScreen("✅ HOÀN TẤT CHIA SẺ BÀI VIẾT", true)
end

-- ========== MENU CHIA SẺ ========== (dòng 2668-2735)
function menuShareBaiViet()
    while true do
        local urlHien = SHARE_URL
        if string.len(urlHien) > 20 then urlHien = string.sub(urlHien, 1, 20) .. "…" end
        if urlHien == "" then urlHien = "chưa nhập" end
        local title = "🚀 Chia sẻ bài viết chỉ định\n· Nick: " .. SHARE_SO_NICK .. "\n· Cuộn tối đa: " .. SHARE_MAX_ATTEMPTS .. " lần\n· Link: " .. urlHien
        local choice = dialogChoice(title,
            "🔗 Nhập link bài viết", "👥 Số nick cần chạy: " .. SHARE_SO_NICK,
            "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "🔢 Số lần lướt tìm: " .. SHARE_MAX_ATTEMPTS,
            "⏳ Delay giữa các lần: " .. SHARE_SCROLL_DELAY .. "s",
            "──────────────", "🚀 BẮT ĐẦU CHẠY", "◀️ Quay lại"
        )
        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Nhập link") then
            local urlInput = dialogInput("Link bài viết", "Dán link:", SHARE_URL)
            if urlInput and urlInput ~= "" then SHARE_URL = urlInput end
        elseif choice:find("Số nick") then
            local n = dialogInput("Số nick", "Nhập:", tostring(SHARE_SO_NICK))
            if n and tonumber(n) then SHARE_SO_NICK = math.floor(tonumber(n)) end
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT:", tostring(NICK_BAT_DAU))
            if input then local num = tonumber(input)
                if num and num >= 0 then NICK_BAT_DAU = math.max(1, math.floor(num)) end
            end
        elseif choice:find("Số lần lướt") then
            local n = dialogInput("Lướt tối đa", "Nhập:", tostring(SHARE_MAX_ATTEMPTS))
            if n and tonumber(n) then SHARE_MAX_ATTEMPTS = math.floor(tonumber(n)) end
        elseif choice:find("Delay") then
            local n = dialogInput("Delay cuộn", "Nhập:", tostring(SHARE_SCROLL_DELAY))
            if n and tonumber(n) then SHARE_SCROLL_DELAY = math.floor(tonumber(n)) end
        elseif choice:find("BẮT ĐẦU CHẠY") then
            if SHARE_URL == "" then toast("⚠️ Vui lòng nhập link!")
            else
                local confirm = dialogChoice("🚀 XÁC NHẬN CHIA SẺ\n\n👥 Chạy: " .. SHARE_SO_NICK .. " nick\n🔗 " .. urlHien, "✅ Chạy ngay!", "◀️ Quay lại")
                if confirm and confirm:find("Chạy ngay") then return "share_bai_viet" end
            end
        end
    end
end

print("✅ share.lua đã nạp")