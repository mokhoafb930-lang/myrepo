-- ================================================================
-- FILE: farm.lua - LOGIC FARM (dòng 4258-5525 gốc)
-- ================================================================

-- ========== QUAY VỀ HOME ĐƠN GIẢN ==========
local function veHomeDonGian()
    log("🏠 Đang quay về Home...")
    log("🏠 Quay ve Home (don gian)...")
    tapText("Home", 5)
    sleep(2)
    log("✅ Đã về Home")
    log("✅ Da quay ve Home")
end

-- ========== QUAY VỀ HOME NÂNG CAO ==========
local function veHomeNangCao()
    log("🏠 Đang quay về Home (xử lý Popup)...")
    log("🏠 Quay ve Home (nang cao - xu ly popup)...")

    local daThay = false
    while not daThay do
        if findImage("crop_1776734384932.png", 1, 1) then
            log("👉 PHAT HIEN HINH 932, xu ly...")
            tapImage("crop_1776734384932.png", 10, 1)
            sleep(1)

            local allFound = true
            local r1 = findColor(1603570, 1, {9, 621, 40, 40})
            if not r1 or #r1 == 0 then allFound = false end
            local r2 = findColor(1603570, 1, {14, 620, 40, 40})
            if not r2 or #r2 == 0 then allFound = false end
            local r3 = findColor(16777215, 1, {11, 627, 40, 40})
            if not r3 or #r3 == 0 then allFound = false end

            if allFound then
                log("👉 PHAT HIEN MULTI-COLOR, dang tap...")
                tap(29, 641)
                sleep(0.5)
                tap(29, 641)
                log("✅ Da tap 2 lan vao (29, 641)")
            end
            daThay = true

        elseif findImage("crop_1776735855245.png", 1, 1) then
            log("👉 ĐANG Ở HOME, tap thêm 2 lần để làm mới...")
            tapText("Home", 5)
            sleep(1)
            tapText("Home", 5)
            daThay = true

        else
            log("👉 KHONG CO HINH, tap back...")
            if findImage("crop_1776705682700.png", 1, 1) then
                tapImage("crop_1776705682700.png", 10, 1)
                log("✅ Da tap back")
                sleep(2)
            else
                log("⚠️ Khong tim thay nut back")
                break
            end
        end
        sleep(1)
    end

    tapText("Home", 5)
    sleep(2)
    log("✅ Da quay ve Home")
end

-- ========== HÀM LƯỚT NEWSFEED ==========
local function luotNewsfeed()
    logScreen("📜 BẮT ĐẦU LƯỚT NEWSFEED", true)
    log("👉 So lan luot: " .. SO_LAN_LUOT)

    for i = 1, SO_LAN_LUOT do
        logScreen("📜 Đang lướt Newsfeed (" .. i .. "/" .. SO_LAN_LUOT .. ")", true)
        swipe(200, 600, 200, 200, 0.8)
        log("   ✅ Da luot lan " .. i .. "/" .. SO_LAN_LUOT)

        if i < SO_LAN_LUOT then
            local nghi_nf = math.random(3, 8)
            nghi(nghi_nf, "Đang xem bài viết Newsfeed")
        end
    end

    logScreen("✅ ĐÃ LƯỚT XONG NEWSFEED", true)
end

-- ========== HÀM LƯỚT NEWSFEED CÓ LIKE (Dành cho Chạy Tổng Hợp) ==========
function luotNewsfeedCoLike(soBai, soLike, delayTruoc)
    local imageLike = "crop_1777213229157.png"
    local backImages = {
        "crop_1776705682700.png",
        "crop_1778663180047.png",
        "crop_1778663262935.png",
        "crop_1778663717879.png",
        "crop_1778669889326.png"
    }

    local sb = soBai or 50
    local sl = math.min(soLike or 10, sb)
    local dt = 5 -- Fix cứng 5s theo ý bạn
    local dg = delayTruoc or 2 -- Tham số thứ 3 dùng làm thời gian nghỉ giữa lần lướt

    -- KIỂM TRA LẠC MÀN HÌNH
    local function kiemTraLac()
        for _, img in ipairs(backImages) do
            local x, y = findImage(img, 1, 1)
            if x then
                tap(x, y)
                sleep(1)
                return true
            end
        end
        return false
    end

    -- TÌM NÚT LIKE CHÍNH XÁC (Ưu tiên nút bên trái màn hình)
    local function timLike()
        for i = 1, 3 do
            -- Tìm tối đa 5 kết quả để lọc
            local results = findImage(imageLike, 5, 1)
            if results and #results > 0 then
                for _, res in ipairs(results) do
                    local x, y = res[1], res[2]
                    if x < 200 and y > 150 and y < 1100 then
                        return x, y
                    end
                end
            end

            if i < 3 then
                swipe(200, 500, 200, 300, 0.5) 
                sleep(1)
            end
        end
        return nil, nil
    end

    local function viTriLike()
        local all = {}
        for i = 1, sb do all[i] = i end
        for i = #all, 2, -1 do
            local j = math.random(i)
            all[i], all[j] = all[j], all[i]
        end
        local vt = {}
        for i = 1, sl do table.insert(vt, all[i]) end
        table.sort(vt)
        return vt
    end

    -- LƯỚT
    local function luot()
        swipe(200, 550, 200, 250, 1)
        sleep(3)
    end

    -- Hàm phụ để lấy tọa độ Like hiện tại (không vuốt)
    local function layToaDoLike()
        local results = findImage(imageLike, 5, 1)
        if results and #results > 0 then
            for _, res in ipairs(results) do
                local curX, curY = res[1], res[2]
                if curX < 200 and curY > 150 and curY < 1150 then
                    return curX, curY
                end
            end
        end
        return nil, nil
    end

    logScreen("🚀 BẮT ĐẦU: LƯỚT " .. sb .. " - LIKE " .. sl)

    local vtLike = viTriLike()
    local done = 0
    local idx = 1

    for i = 1, sb do
        logScreen("🔹 " .. i .. "/" .. sb)

        kiemTraLac()
        luot()
        if i < sb then nghi(dg, "💤") end
        kiemTraLac()

        if idx <= #vtLike and i == vtLike[idx] then
            logScreen("🎯 BÀI " .. i .. " → LIKE")
            idx = idx + 1

            local x, y = timLike()
            if x then
                nghi(dt, "⏸️ CHỜ")
                -- Xác minh lại vị trí x, y mới nhất bằng hình ảnh
                local x2, y2 = layToaDoLike()
                if x2 then
                    tap(x2, y2)
                    sleep(0.5)
                    done = done + 1
                    logScreen("👍 ĐÃ LIKE (" .. done .. "/" .. sl .. ")", true)
                else
                    logScreen("⚠️ Mất dấu nút Like sau khi chờ", true)
                end

                kiemTraLac()
                nghi(3, "💤")
            end
        end
    end

    logScreen("✅ HOÀN TẤT - LIKE " .. done .. "/" .. sl)
end

-- ========== HÀM KIỂM TRA MÀU VÀ ẤN MORE ==========
local function anMore()
    logScreen("📂 Đang mở thư viện ảnh...", true)
    log("🔍 Kiem tra mau de an More...")
    local r1 = findColor(3832790, 1, {302, 130, 40, 40})
    local r2 = findColor(1532879, 1, {312, 129, 40, 40})
    local r3 = findColor(1532879, 1, {325, 133, 40, 40})

    if r1 and #r1 > 0 and r2 and #r2 > 0 and r3 and #r3 > 0 then
        log("✅ Da thay mau, tap More")
        tap(322, 150)
        return true
    else
        log("❌ Khong tim thay mau More")
        return false
    end
end

-- ========== HÀM VUỐT CHỌN ẢNH RANDOM (AVATAR/BIA) ==========
local function vuotChonAnh(loaiAnh)
    local soLanVuot = math.random(5, 20)
    log("👉 Đang lướt " .. soLanVuot .. " lần để chọn " .. loaiAnh)

    for i = 1, soLanVuot do
        logScreen("📜 Đang lướt chọn " .. loaiAnh .. " (" .. i .. "/" .. soLanVuot .. ")", true)
        swipe(200, 600, 200, 200, 0.6)
        sleep(1.5)
    end

    sleep(5)

    local daTapDuoc = false
    local soLanThu = 0
    while not daTapDuoc do
        soLanThu = soLanThu + 1
        local x = math.random(50, 350)
        local y = math.random(100, 700)
        log("👉 Lan thu " .. soLanThu .. ": Tap chon anh tai (" .. x .. ", " .. y .. ")")
        tap(x, y)
        sleep(5)

        if findText("Camera Roll", 2) then
            logScreen("⚠️ Chưa chọn được ảnh, đang thử lại...", true)
            log("⚠️ Van con 'Camera Roll' -> tap chua trung, tap lai...")
        else
            daTapDuoc = true
            log("✅ Da tap duoc " .. loaiAnh .. " thanh cong!")
        end
    end
    sleep(2)
end

-- ========== HÀM VUỐT CHỌN ẢNH (DANG BAI) ==========
local function vuotChoDangBai()
    log("🔄 Dang vuot chon anh de dang bai...")
    local soLanVuot = math.random(5, 20)
    log("👉 So lan vuot: " .. soLanVuot)

    for i = 1, soLanVuot do
        logScreen("📜 Đang lướt tìm ảnh (" .. i .. "/" .. soLanVuot .. ")", true)
        swipe(200, 600, 200, 200, 0.6)
        sleep(1.5)
    end

    log("🔍 Dang tim anh...")
    sleep(5)

    local daTapDuoc = false
    while not daTapDuoc do
        local x = math.random(50, 350)
        local y = math.random(100, 700)
        log("👉 Tap vao toa do: (" .. x .. ", " .. y .. ")")
        tap(x, y)
        sleep(2)

        if findText("Done", 2) then
            log("✅ Da thay nut Done!")
            daTapDuoc = true
        else
            log("⚠️ Chua thay nut Done, thu lai...")
        end
    end

    tapText("Done", 30)
    log("✅ Da tap nut Done")
    sleep(10)
end

-- ========== HÀM VUỐT CHỌN ẢNH STORY ==========
local function vuotChonAnhChoStory(loaiAnh)
    log("🔄 Dang vuot chon " .. loaiAnh .. " cho Story...")
    local soLanVuot = math.random(5, 20)
    log("👉 So lan vuot random: " .. soLanVuot)

    for i = 1, soLanVuot do
        logScreen("📜 Đang lướt chọn " .. loaiAnh .. " (" .. i .. "/" .. soLanVuot .. ")", true)
        swipe(188, 516, 188, 200, 0.6)
        sleep(1.5)
    end

    log("🔍 Đang tìm ảnh Story để chọn...")
    sleep(5)

    local daTapDuoc = false
    while not daTapDuoc do
        local x = math.random(50, 350)
        local y = math.random(100, 700)
        log("👉 Tap thu vao toa do Story: (" .. x .. ", " .. y .. ")")
        tap(x, y)
        sleep(5)

        if findText("Create story", 2) then
            log("⚠️ Chua chon duoc anh Story, thu lai...")
        else
            log("✅ Da chon duoc anh Story")
            daTapDuoc = true
        end
    end
    sleep(5)
end

-- ========== HÀM VUỐT TÌM TEXT ==========
local function vuotTimText(text, soLanVuotToiDa)
    soLanVuotToiDa = soLanVuotToiDa or 5
    log("🔍 Dang tim text: " .. text .. " (max " .. soLanVuotToiDa .. " lan)...")

    for i = 1, soLanVuotToiDa do
        if findText(text, 2) then
            log("✅ Da tim thay text: " .. text)
            return true
        end
        log("👉 Luot lan " .. i .. "...")
        swipe(200, 600, 200, 300, 0.5)
        sleep(1)
    end

    log("❌ Khong tim thay text: " .. text)
    return false
end

-- ========== HÀM THÊM AVATAR VÀ ẢNH BÌA (DÙNG CHUNG) ==========
local function chucNangChungAvatarBia()
    logScreen("🖼️ BẮT ĐẦU CHỨC NĂNG CHUNG: AVATAR & BÌA", true)
    openURL("fb://profile")
    nghi(5, "Đang mở trang cá nhân...")

    if findImage("crop_1776589445092.png", 1, 0.85) then
        log("⚠️ PHÁT HIỆN LỖI trang cá nhân")
        tapText("Go Back", 10)
        sleep(2)
    end

    if findText("Edit profile", 5) then
        tapText("Edit profile", 10)
        sleep(3)
    else
        log("⚠️ Không tìm thấy Edit profile")
        return false
    end

    local coThayTrong = false

    logScreen("🔍 Kiểm tra trạng thái Avatar...", true)
    if findImage("crop_1778066735295.png", 1, 0.9) then
        log("👉 PHÁT HIỆN CHƯA CÓ AVATAR: Tap vào ảnh trống")
        tapImage("crop_1778066735295.png", 1, 0.9)
        sleep(3)
        tapText("Select", 10)
        sleep(2)
        anMore()
        sleep(4)
        logScreen("🖼️ Đang chọn ảnh đại diện...", true)
        vuotChonAnh("anh avatar")
        tapText("Save", 10)
        logScreen("⌛ Đang tải Avatar lên...", true)
        sleep(20)
        coThayTrong = true
    end

    logScreen("🔍 Kiểm tra trạng thái Ảnh bìa...", true)
    if findImage("crop_1778066846695.png", 1, 0.9) then
        log("👉 PHÁT HIỆN CHƯA CÓ ẢNH BÌA: Tap vào ảnh trống")
        tapImage("crop_1778066846695.png", 1, 0.9)
        sleep(3)
        tapText("Upload Photo", 10)
        sleep(4)
        anMore()
        sleep(4)
        logScreen("🖼️ Đang chọn ảnh bìa...", true)
        vuotChonAnh("anh bia")
        tapText("Save", 20)
        logScreen("⌛ Đang tải Ảnh bìa lên...", true)
        sleep(10)
        coThayTrong = true
    end

    if not coThayTrong then
        log("✅ Avatar va Anh bia da co san, bo qua")
        return "ALREADY_SET"
    end

    return true
end

-- ========== HÀM THÊM AVATAR ==========
local function themAvatar()
    logScreen("🖼️ BẮT ĐẦU THÊM AVATAR", true)
    openURL("fb://profile")
    nghi(5, "Đang mở trang cá nhân...")

    if findImage("crop_1776589445092.png", 1, 0.85) then
        log("⚠️ PHÁT HIỆN LỖI trang cá nhân")
        tapText("Go Back", 10)
        sleep(2)
    end

    if findText("Edit profile", 5) then
        tapText("Edit profile", 10)
        sleep(3)
    else
        log("⚠️ Không tìm thấy Edit profile")
    end

    logScreen("🔍 Kiểm tra trạng thái Avatar...", true)
    if findImage("crop_1778066735295.png", 1, 0.9) then
        log("👉 PHÁT HIỆN CHƯA CÓ AVATAR: Tap vào ảnh trống")
        tapImage("crop_1778066735295.png", 1, 0.9)
    else
        log("👉 ĐÃ CÓ AVATAR (hoặc không thấy hình mặc định). Bỏ qua việc thêm!")
        return false
    end

    sleep(3)
    tapText("Select", 10)
    sleep(2)
    anMore()
    sleep(4)
    logScreen("🖼️ Đang chọn ảnh đại diện...", true)
    vuotChonAnh("anh avatar")
    tapText("Save", 10)
    logScreen("⌛ Đang tải Avatar lên...", true)
    sleep(20)
end

-- ========== HÀM THÊM ẢNH BÌA ==========
local function themAnhBia()
    logScreen("🖼️ BẮT ĐẦU THÊM ẢNH BÌA", true)
    openURL("fb://profile")
    nghi(5, "Đang mở trang cá nhân...")

    if findImage("crop_1776589445092.png", 1, 0.85) then
        log("⚠️ PHÁT HIỆN LỖI trang cá nhân")
        tapText("Go Back", 10)
        sleep(2)
    end

    if findText("Edit profile", 5) then
        tapText("Edit profile", 10)
        sleep(3)
    else
        log("⚠️ Không tìm thấy Edit profile")
    end

    logScreen("🔍 Kiểm tra trạng thái Ảnh bìa...", true)
    if findImage("crop_1778066846695.png", 1, 0.9) then
        log("👉 PHÁT HIỆN CHƯA CÓ ẢNH BÌA: Tap vào ảnh trống")
        tapImage("crop_1778066846695.png", 1, 0.9)
    else
        log("👉 ĐÃ CÓ ẢNH BÌA (hoặc không thấy hình mặc định). Bỏ qua việc thêm!")
        return false
    end

    sleep(3)
    tapText("Upload Photo", 10)
    sleep(4)
    anMore()
    sleep(4)
    vuotChonAnh("anh bia")
    tapText("Save", 20)
    logScreen("⌛ Đang tải Ảnh bìa lên...", true)
    sleep(10)
    return true
end

-- ========== HÀM ĐĂNG BÀI ==========
local function dangBai()
    logScreen("📝 BẮT ĐẦU ĐĂNG BÀI", true)
    log("👉 Dang mo man hinh dang bai...")

    local daTapDuoc = false
    local maxLanThu = 3

    for soLanThu = 1, maxLanThu do
        logScreen("🔍 Đang tìm ô soạn bài (Lần " .. soLanThu .. ")...", true)
        if tapText("What's on your mind?", 10) then
            log("✅ Đã bấm vào What's on your mind?")
            sleep(4)
            if findText("Create post", 5) or findText("Post", 5) then
                daTapDuoc = true
                log("✅ Đã mở ô soạn bài thành công!")
                break
            else
                log("⚠️ Chưa thấy ô soạn bài, thử lại...")
            end
        else
            log("⚠️ Không thấy chữ 'What's on your mind?', đang thử lại...")
            swipe(200, 400, 200, 600, 0.5)
            sleep(2)
        end
    end

    if not daTapDuoc then
        logScreen("❌ KHÔNG THỂ BẮT ĐẦU ĐĂNG BÀI!", true)
        log("❌ Khong the tap vao 'What's on your mind?' sau 3 lan thu")
        return false
    end

    -- Chỉnh quyền riêng tư (nếu cần)
    log("🔍 Kiem tra quyen rieng tu...")
    local timThayFriends = tapText("Friends", 5)
    sleep(1)

    if timThayFriends == true then
        log("👉 Dang doi thanh Public...")
        tapText("Friends", 10)
        sleep(2)

        local allFound = true
        local r1 = findColor(13553359, 1, {326, 271, 40, 40})
        if not r1 or #r1 == 0 then allFound = false end

        if allFound then
            log("✅ Da thay nut Public (color)")
            tap(346, 291)
        else
            log("👉 Tim bang text Public...")
            tapText("Public", 10)
        end

        sleep(2)
        tapText("Done", 10)
        sleep(3)
        tapText("What's on your mind?", 10)
        sleep(3)
    else
        log("✅ Quyen rieng tu da ok")
        tapText("What's on your mind?", 10)
        sleep(3)
    end

    -- Nhập nội dung
    log("📝 Dang nhap noi dung...")
    local soThuTu = math.random(1, #NOI_DUNG_BAI_VIET)
    log("👉 Noi dung random: " .. NOI_DUNG_BAI_VIET[soThuTu])
    inputText(NOI_DUNG_BAI_VIET[soThuTu])
    sleep(2)

    -- Chọn ảnh
    log("📸 Dang chon anh...")
    if findText("Add to your post", 3) then
        tapText("Add to your post", 10)
        sleep(3)
        for i = 1, 3 do
            if tapText("Photo/video", 10) then
                sleep(3)
                break
            end
        end
    else
        log("👉 Tap bang hinh anh Photo icon...")
        tapImage("crop_1776655087982.png", 10, 1)
        sleep(3)
    end

    vuotChoDangBai()

    -- Nhấn Đăng
    log("🚀 Dang nhan nut Dang (Post)...")
    tapImage("crop_1776655431621.png", 10, 1)

    nghi(15, "Đang tải bài viết lên")
    logScreen("✅ ĐÃ ĐĂNG BÀI THÀNH CÔNG", true)
end

-- ========== ĐĂNG BÀI TEXT (THEO CODE USER GỬI) ==========
local function dangBaiText()
    logScreen("📝 BẮT ĐẦU ĐĂNG BÀI TEXT", true)

    openURL("fb://composer")
    log("✅ Đã mở trình soạn bài (fb://composer)")
    sleep(2)

    -- CHỈ KHI TÌM THẤY "Friends" MỚI XỬ LÝ, KHÔNG THÌ BỎ QUA
    if findText("Friends", 3) then
        log("🔍 Tìm thấy Friends -> đang xử lý...")
        tapText("Friends", 10, 1)
        sleep(1.5)

        log("🔍 Đang tìm nút Public...")
        tapText("Public", 10, 1)
        sleep(1.5)

        log("🔍 Đang tìm nút Done...")
        tapText("Done", 10, 1)
        sleep(2)
    else
        log("⏭️ Không tìm thấy Friends hoặc đã ở chế độ Public, bỏ qua")
    end

    log("🔍 Đang tìm ô soạn bài...")
    tapText("What's on your mind?", 10, 1)
    sleep(1.5)

    -- Nhập nội dung random
    local soThuTu = math.random(1, #NOI_DUNG_BAI_VIET)
    local noiDung = NOI_DUNG_BAI_VIET[soThuTu]
    log("📝 Đang nhập nội dung: " .. noiDung)
    inputText(noiDung)
    sleep(2)

    -- Nhấn Đăng (Dùng ảnh nút Đăng của User)
    log("🚀 Đang nhấn nút Đăng...")
    tapImage("crop_1776655431621.png", 10, 1)

    nghi(10, "Đang tải bài viết lên")
    logScreen("🎉 ĐĂNG BÀI TEXT THÀNH CÔNG!", true)
    return true
end

-- Entry point cho Chạy tổng hợp
function thucHienDangBaiText()
    logScreen("🚀 CHẠY ĐĂNG BÀI TEXT LIÊN HOÀN", true)
    local danhSachNick = layDanhSachCrane()
    local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
    -- Trong chạy tổng hợp, thường chỉ chạy 1 nick hiện tại
    -- Nhưng nếu gọi riêng lẻ, nó sẽ chạy theo SO_NICK_UID (giống kết bạn)
    local slNick = 1
    if not _G.DANG_CHAY_LIEN_HOAN then
        slNick = SO_NICK_UID
    end

    for nickIndex = 1, slNick do
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[((nickIndex - 1 + offset) % #danhSachNick) + 1]
        else
            tenPhanVung = danhSachNick[((nickIndex - 1 + offset) % #danhSachNick) + 1]
        end

        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. slNick .. " | 📂 " .. tenPhanVung, true)

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            chuyenNick(tenPhanVung)
        end

        if not moFacebook() then
            log("⚠️ Loi mo Facebook, bo qua nick nay")
        else
            nghi(10, "Đợi Facebook ổn định")
            dangBaiText()
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < slNick then
                nghi(5, "Nghỉ đổi nick")
            end
        end
    end
end

-- ========== CHUYỂN CHẾ ĐỘ CÔNG KHAI CHO STORY ==========
local function chuyenCheDoCongKhaiChoStory()
    log("--- CHUYEN CHE DO CONG KHAI CHO STORY ---")

    if findText("Privacy") then
        log("✅ Tim thay chu Privacy!")
        tap(35, 617)
    else
        logScreen("❌ KHÔNG TÌM THẤY CÀI ĐẶT QUYỀN RIÊNG TƯ", true)
        log("❌ Khong tim thay chu Privacy!")
        return false
    end
    sleep(2)

    local allFound1 = true
    local r1 = findColor(16777215, 1, {326, 160, 40, 40})
    if not r1 or #r1 == 0 then allFound1 = false end
    local r2 = findColor(14211289, 1, {321, 166, 40, 40})
    if not r2 or #r2 == 0 then allFound1 = false end
    local r3 = findColor(16777215, 1, {328, 166, 40, 40})
    if not r3 or #r3 == 0 then allFound1 = false end
    local r4 = findColor(16777215, 1, {333, 168, 40, 40})
    if not r4 or #r4 == 0 then allFound1 = false end
    local r5 = findColor(16777215, 1, {330, 170, 40, 40})
    if not r5 or #r5 == 0 then allFound1 = false end

    if allFound1 then
        tap(346, 180)
        log("✅ Da chon Cong khai")
    else
        tapText("Public", 10)
    end
    sleep(2)

    tapText("Save", 10)
    sleep(3)

    local allFound2 = true
    local r1_2 = findColor(1603570, 1, {220, 380, 40, 40})
    if not r1_2 or #r1_2 == 0 then allFound2 = false end
    local r2_2 = findColor(1603570, 1, {233, 380, 40, 40})
    if not r2_2 or #r2_2 == 0 then allFound2 = false end
    local r3_2 = findColor(16777215, 1, {210, 380, 40, 40})
    if not r3_2 or #r3_2 == 0 then allFound2 = false end
    local r4_2 = findColor(2523123, 1, {215, 384, 40, 40})
    if not r4_2 or #r4_2 == 0 then allFound2 = false end

    if allFound2 then
        tap(240, 400)
        log("✅ Da tap kiem tra")
    end

    tapText("Share", 10)
    nghi(15, "Đang tải Story lên")
    log("✅ Da tap Share")
    sleep(2)
    return true
end

-- ========== HÀM ĐĂNG STORY ==========
local function dangStory()
    logScreen("🎬 BẮT ĐẦU ĐĂNG STORY", true)

    local maxRefresh = 3
    local found = false

    for refreshCount = 1, maxRefresh do
        log("👉 LAN REFRESH " .. refreshCount .. "/" .. maxRefresh)
        swipe(200, 200, 200, 600, 0.5)
        sleep(3)
        swipe(148, 231, 400, 231, 0.5)
        sleep(7)

        if findImage("crop_1776662877397.png", 1, 1) then
            logScreen("✅ Đã thấy nút tạo Story", true)
            log("✅ Tim thay nut tao Story!")
            tapImage("crop_1776662877397.png", 10, 1)
            found = true
            break
        end
    end

    if not found then
        logScreen("❌ KHÔNG TÌM THẤY NÚT TẠO STORY", true)
        log("❌ Khong tim thay nut tao Story")
        return false
    end

    sleep(3)
    sleep(2)

    logScreen("🖼️ Đang chọn ảnh Story...", true)
    vuotChonAnhChoStory("anh story")

    tapText("Next", 5)
    sleep(3)

    chuyenCheDoCongKhaiChoStory()

    logScreen("✅ ĐÃ ĐĂNG STORY THÀNH CÔNG", true)
    return true
end

-- ========== HÀM THÊM TIỂU SỬ ==========
local function themTieuSu()
    logScreen("📝 Bắt đầu thêm tiểu sử...", true)
    log("📝 Bắt đầu thêm tiểu sử...")

    if findText("Describe yourself...") then
        logScreen("✅ Tìm thấy nút Thêm tiểu sử", true)
        log("✅ Tim thay nut Them tieu su")
        tapText("Describe yourself...", 10)
        sleep(2)
        local tieuSu = TIEU_SU_RANDOM[math.random(1, #TIEU_SU_RANDOM)]
        log("📝 Nhap tieu su: " .. tieuSu)
        inputText(tieuSu)
        sleep(2)
        if findText("Save") then
            tapText("Save", 10)
        else
            tapText("Done", 10)
        end
        log("✅ Da luu tieu su")
        sleep(3)
        return true
    end
    log("✅ Tiep tuc (da co tieu su)")
    return false
end

-- ========== HÀM THÊM CÔNG VIỆC ==========
local function themWork()
    log("💼 Dang kiem tra Them cong viec...")
    local ok = false
    for i = 1, 10 do
        if findText("Details", 3) then ok = true break end
        swipe(200, 550, 200, 450, 1.5)
        sleep(1)
    end
    if not ok then return false end

    local allFound = false
    local r_quick = findColor(1532879, 1, {315, 635, 45, 45})
    if r_quick and #r_quick > 0 then
        log("✅ Tim thay nut Add (nhanh)")
        allFound = true
        tap(335, 659)
    else
        for attempt = 1, 5 do
            log("🔍 Tim nut Add... (" .. attempt .. "/5)")
            swipe(200, 550, 200, 450, 1.5)
            sleep(1.5)
            if findText("Add", 3) then
                tapText("Add", 10)
                allFound = true
                break
            end
        end
    end

    if not allFound then return false end
    sleep(2)

    if findText("Add work") then
        tapText("Add work", 10)
    else
        return false
    end

    sleep(2)
    if findText("Workplace Name") then
        tapText("Workplace Name", 10)
        sleep(2)
        tap(81, 88)
        sleep(2)
    else
        return false
    end

    local work = DANH_SACH_CONG_VIEC[math.random(1, #DANH_SACH_CONG_VIEC)]
    log("📝 Nhap cong viec: " .. work)
    inputText(work)
    sleep(2)
    tap(175, 134)
    sleep(2)
    sleep(2)

    if findText("Save") then tapText("Save", 10) else tapText("Done", 10) end

    -- Quay lại màn hình chính của Edit Profile
    for i = 1, 20 do
        if findImage("crop_1776696576554.png", 1, 1) then
            tapImage("crop_1776696576554.png", 1, 1)
            break
        end
        sleep(1)
    end
    return true
end

-- ========== HÀM THÊM TRƯỜNG HỌC ==========
local function themHighSchool()
    log("🎓 Dang kiem tra Them truong hoc...")
    local timThay = false
    for i = 1, 5 do
        if findText("Add high school", 3) then
            tapText("Add high school", 10)
            timThay = true
            break
        end
        swipe(200, 500, 200, 300, 0.5)
        sleep(1)
    end

    if not timThay then return false end
    sleep(2)

    if findText("High School Name") then
        tapText("High School Name", 10)
        sleep(2)
        tap(81, 88)
        sleep(1)
    else
        return false
    end

    sleep(2)
    for lanThu = 1, 5 do
        if lanThu > 1 then tap(360, 89) sleep(1) end
        local school = DANH_SACH_TRUONG[math.random(1, #DANH_SACH_TRUONG)]
        log("📝 Nhap truong: " .. school)
        inputText(school)
        sleep(2)
        tap(175, 134)
        sleep(2)
        if not (findText("no results found", 2) or findText("No results found", 2)) then break end
    end

    sleep(2)
    if findText("Save") then tapText("Save", 10) else tapText("Done", 10) end

    for i = 1, 20 do
        if findImage("crop_1776696576554.png", 1, 1) then
            tapImage("crop_1776696576554.png", 1, 1)
            break
        end
        sleep(1)
    end
    return true
end

-- ========== HÀM THÊM THÀNH PHỐ HIỆN TẠI ==========
local function themCurrentCity()
    log("🏠 Dang kiem tra Them thanh pho hien tai...")
    local found = false
    if findText("Add current city") then
        tapText("Add current city", 10)
        found = true
    else
        for i = 1, 10 do
            swipe(200, 500, 200, 300, 0.3)
            sleep(1)
            if findText("Add current city") then
                tapText("Add current city", 10)
                found = true
                break
            end
        end
    end

    if not found then return false end
    sleep(2)

    if findText("Add Current City (Required)") then
        tapText("Add Current City (Required)", 10)
        sleep(2)
        tap(81, 88)
        sleep(1)
    end

    sleep(2)
    for lanThu = 1, 5 do
        if lanThu > 1 then tap(360, 89) sleep(1) end
        local city = DANH_SACH_THANH_PHO[math.random(1, #DANH_SACH_THANH_PHO)]
        log("📝 Nhap thanh pho: " .. city)
        inputText(city)
        sleep(2)
        tap(175, 134)
        sleep(2)
        if not (findText("no results found", 2) or findText("No results found", 2)) then break end
    end

    sleep(2)
    if findText("Save") then tapText("Save", 10) else tapText("Done", 10) end

    for i = 1, 20 do
        if findImage("crop_1776696576554.png", 1, 1) then
            tapImage("crop_1776696576554.png", 1, 1)
            break
        end
        sleep(1)
    end
    return true
end

-- ========== HÀM THÊM QUÊ QUÁN ==========
local function themHometown()
    log("🏠 Dang kiem tra Them que quan...")
    local found = false
    if findText("Add hometown") then
        tapText("Add hometown", 10)
        found = true
    else
        for i = 1, 10 do
            swipe(200, 500, 200, 300, 0.3)
            sleep(1)
            if findText("Add hometown") then
                tapText("Add hometown", 10)
                found = true
                break
            end
        end
    end

    if not found then return false end
    sleep(2)

    if findText("Hometown Name (Required)") then
        tapText("Hometown Name (Required)", 10)
        sleep(2)
        tap(81, 88)
        sleep(1)
    end

    sleep(2)
    for lanThu = 1, 5 do
        if lanThu > 1 then tap(360, 89) sleep(1) end
        local city = DANH_SACH_THANH_PHO[math.random(1, #DANH_SACH_THANH_PHO)]
        log("📝 Nhap que quan: " .. city)
        inputText(city)
        sleep(2)
        tap(175, 134)
        sleep(2)
        if not (findText("no results found", 2) or findText("No results found", 2)) then break end
    end

    sleep(2)
    if findText("Save") then tapText("Save", 10) else tapText("Done", 10) end

    for i = 1, 20 do
        if findImage("crop_1776696576554.png", 1, 1) then
            tapImage("crop_1776696576554.png", 1, 1)
            break
        end
        sleep(1)
    end
    return true
end

-- ========== HÀM THÊM TÌNH TRẠNG HÔN NHÂN ==========
local function themRelationship()
    log("💞 Dang kiem tra Them tinh trang hon nhan...")
    for lanThu = 1, 3 do
        if vuotTimText("Add a relationship status", 5) then
            tapText("Add a relationship status", 10)
            break
        elseif lanThu == 3 then
            return false
        end
        sleep(2)
    end

    sleep(2)
    for lanThu = 1, 3 do
        if vuotTimText("relationship status", 5) then
            tapText("relationship status", 10)
            break
        elseif lanThu == 3 then
            return false
        end
        sleep(2)
    end

    sleep(2)
    local statusChon = DANH_SACH_RELATIONSHIP[math.random(1, #DANH_SACH_RELATIONSHIP)]
    log("📝 Chon tinh trang: " .. statusChon)
    for lanThu = 1, 3 do
        if vuotTimText(statusChon, 5) then
            tapText(statusChon, 10)
            break
        elseif lanThu == 3 then
            return false
        end
        sleep(2)
    end

    sleep(2)
    if findText("Save", 3) then tapText("Save", 10) end

    for i = 1, 20 do
        if findImage("crop_1776696576554.png", 1, 1) then
            tapImage("crop_1776696576554.png", 1, 1)
            break
        end
        sleep(1)
    end
    return true
end

-- ========== HÀM EDIT PROFILE TỔNG HỢP ==========
local function editProfile()
    logScreen("✏️ BẮT ĐẦU CHỈNH SỬA HỒ SƠ", true)

    openURL("fb://profile")
    nghi(5, "Đang mở trang cá nhân...")

    if findImage("crop_1776589445092.png", 1, 0.85) then
        log("⚠️ PHAT HIEN LOI trang ca nhan")
        tapText("Go Back", 10)
        sleep(2)
    end

    if findText("Edit profile", 5) then
        log("✅ Tim thay 'Edit profile'!")
        tapText("Edit profile", 10)
    else
        log("❌ Khong tim thay 'Edit profile'!")
        return false
    end

    sleep(3)

    -- Thực hiện tuần tự các bước edit
    themTieuSu()
    themWork()
    themHighSchool()
    themCurrentCity()
    themHometown()
    themRelationship()

    logScreen("✅ HOÀN TẤT CHỈNH SỬA HỒ SƠ", true)
    return true
end

-- ========== HÀM THỰC HIỆN FARM ==========
function thucHienFarm()
    -- Load lại nội dung từ file trước khi chạy
    _G.NOI_DUNG_BAI_VIET = readLinesFromFile(POST_FILE_PATH, _G.NOI_DUNG_BAI_VIET)
    _G.TIEU_SU_RANDOM = readLinesFromFile(BIO_FILE_PATH, _G.TIEU_SU_RANDOM)
    _G.DANH_SACH_CONG_VIEC = readLinesFromFile(WORK_FILE_PATH, _G.DANH_SACH_CONG_VIEC)
    _G.DANH_SACH_TRUONG = readLinesFromFile(SCHOOL_FILE_PATH, _G.DANH_SACH_TRUONG)
    _G.DANH_SACH_THANH_PHO = readLinesFromFile(CITY_FILE_PATH, _G.DANH_SACH_THANH_PHO)
    _G.DANH_SACH_RELATIONSHIP = readLinesFromFile(RELA_FILE_PATH, _G.DANH_SACH_RELATIONSHIP)

    logScreen("🚀 BẮT ĐẦU FARM", true)
    logScreen("📂 CHẠY TỪ NICK " .. NICK_BAT_DAU .. " ĐẾN NICK " .. (NICK_BAT_DAU + SO_LAN_LAP), true)
    log("=== SO LAN LAP: " .. SO_LAN_LAP .. " ===")
    log("=== BAT AVATAR: " .. (BAT_AVATAR == 1 and "BAT" or "TAT") .. " ===")
    log("=== BAT ANH BIA: " .. (BAT_ANH_BIA == 1 and "BAT" or "TAT") .. " ===")
    log("=== BAT DANG BAI: " .. (BAT_DANG_BAI == 1 and "BAT" or "TAT") .. " ===")
    log("=== BAT DANG STORY: " .. (BAT_DANG_STORY == 1 and "BAT" or "TAT") .. " ===")
    log("=== BAT LUOT NEWSFEED: " .. (BAT_LUOT_NEWSFEED == 1 and "BAT" or "TAT") .. " ===")
    log("=== BAT EDIT PROFILE: " .. (BAT_EDIT_PROFILE == 1 and "BAT" or "TAT") .. " ===")
    log("========================================")

    local danhSachNick = layDanhSachCrane()
    if #danhSachNick == 0 then
        logScreen("❌ KHÔNG LẤY ĐƯỢC DANH SÁCH CRANE!", true)
        log("❌ Loi: Khong co danh sach Crane")
        return
    end

    for lan = 1, SO_LAN_LAP do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((lan - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = ""
        if _G.DANG_CHAY_LIEN_HOAN then
            tenPhanVung = layPhanVungHienTai() or danhSachNick[idx_in_list]
        else
            tenPhanVung = danhSachNick[idx_in_list]
        end

        log("")
        logScreen("🚀 LẦN " .. lan .. "/" .. SO_LAN_LAP .. " | 📂 " .. tenPhanVung, true)
        log("👉 Dang xu ly phan vung: " .. tenPhanVung)

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            chuyenNick(tenPhanVung)
        end

        if not moFacebook() then
            log("❌ Khong mo duoc Facebook, bo qua lan nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
        else
            -- 1. Xử lý Avatar & Ảnh bìa
            local canVeHome = (BAT_AVATAR == 1 or BAT_ANH_BIA == 1 or BAT_EDIT_PROFILE == 1)

            if BAT_AVATAR == 1 and BAT_ANH_BIA == 1 then
                chucNangChungAvatarBia()
            else
                if BAT_AVATAR == 1 then themAvatar() end
                if BAT_ANH_BIA == 1 then themAnhBia() end
            end

            -- 2. Edit Profile
            if BAT_EDIT_PROFILE == 1 then
                editProfile()
            end

            -- 3. Quay về Home (nếu cần sau khi edit profile)
            if canVeHome then
                veHomeNangCao()
            end

            -- 4. Đăng bài
            if BAT_DANG_BAI == 1 then
                dangBai()
            end

            -- 4.1 Đăng bài Text Only
            if BAT_DANG_BAI_TEXT == 1 then
                dangBaiText()
            end

            -- 5. Đăng Story
            if BAT_DANG_STORY == 1 then
                dangStory()
            end

            -- 6. Lướt Newsfeed
            if BAT_LUOT_NEWSFEED == 1 then
                luotNewsfeed()
            end

            -- 7. Xem Watch
            farmWatch()
            if not _G.DANG_CHAY_LIEN_HOAN then
                dongFacebook()
            end
        end

        logScreen("✅ HOÀN THÀNH LẦN " .. lan .. "/" .. SO_LAN_LAP, true)
        log("✅ Da xong " .. lan .. " phan vung")

        if not _G.DANG_CHAY_LIEN_HOAN then
            if lan < SO_LAN_LAP then
                nghi(THOI_GIAN_NGHI, "Nghỉ giải lao giữa các hiệp Farm")
            end
        end
    end

    logScreen("🎉 HOÀN THÀNH TOÀN BỘ " .. SO_LAN_LAP .. " LẦN", true)
    log("🎉 CHAY XONG TOAN BO")
end

print("✅ farm.lua đã nạp")