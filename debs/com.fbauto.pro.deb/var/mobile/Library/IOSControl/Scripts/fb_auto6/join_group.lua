-- ================================================================
-- FILE: join_group.lua - THAM GIA NHÓM THEO UID
-- ================================================================

-- ========== GHI LOG THAM GIA NHÓM ==========
function ghiLogJoinGroup(msg)
    local f = io.open(GROUP_LOG_FILE, "a")
    if f then
        f:write(os.date("%H:%M:%S") .. " " .. msg .. "\n")
        f:close()
    end
end

-- ========== ĐẾM UID NHÓM TRONG FILE ==========
function demUIDNhomTrongFile()
    local soUID = 0
    local f = io.open(GROUP_UID_FILE, "r")
    if f then
        for line in f:lines() do
            if line ~= "" then soUID = soUID + 1 end
        end
        f:close()
    end
    return soUID
end

-- ========== ĐỌC UID ĐẦU TIÊN VÀ XÓA KHỎI FILE ==========
local function layUIDNhomVaXoa()
    local file = io.open(GROUP_UID_FILE, "r")
    if not file then return nil end

    local content = file:read("*all")
    file:close()

    if not content or content == "" then return nil end

    local allLines = {}
    for line in string.gmatch(content, "[^\r\n]+") do
        if line ~= "" then table.insert(allLines, line) end
    end

    if #allLines == 0 then return nil end

    local firstLine = allLines[1]:match("^%s*(.-)%s*$")

    local remaining = {}
    for i = 2, #allLines do
        table.insert(remaining, allLines[i])
    end

    local newContent = table.concat(remaining, "\n")
    if newContent ~= "" then newContent = newContent .. "\n" end

    local fileWrite = io.open(GROUP_UID_FILE, "w")
    if fileWrite then
        fileWrite:write(newContent)
        fileWrite:close()
    end

    return firstLine
end

-- ========== HÀM TRẢ LỜI CÂU HỎI (Logic của user) ==========
function traLoiCauHoiNhom()
    log("🔍 Kiểm tra có câu hỏi cần trả lời...")
    sleep(3)

    -- Chỉ xử lý "Write an answer" / "Write your answer"
    if findText("Write your answer", 2) or findText("Write an answer", 2) then
        log("📝 Tìm thấy ô trả lời -> đang tap...")
        if findText("Write your answer", 1) then
            tapText("Write your answer", 5, 1)
        else
            tapText("Write an answer", 5, 1)
        end
        sleep(2)

        -- Nhập nội dung tham gia
        local noiDung = "Tôi muốn tham gia nhóm để học hỏi và giao lưu ạ!"
        log("📝 Đang nhập: " .. noiDung)
        inputText(noiDung)
        sleep(2)

        -- Tìm nút Submit / Gửi / Send
        local buttons = {"Submit", "Send", "Gửi", "Done", "Hoàn tất"}
        for _, btn in ipairs(buttons) do
            if findText(btn, 1) then
                tapText(btn, 5, 1)
                log("✅ Đã gửi câu trả lời (" .. btn .. ")")
                sleep(2)
                return true
            end
        end
    end

    log("ℹ️ Nhóm này không thấy câu hỏi bắt buộc")
    return false
end

-- ========== MENU THAM GIA NHÓM ==========
function menuJoinGroup()
    while true do
        local soUIDCon = demUIDNhomTrongFile()
        local filename = GROUP_UID_FILE:match("([^/]+)$") or GROUP_UID_FILE
        local title = "🌐 Tham gia nhóm theo UID (Chạy lẻ)\n"
            .. "· Nick: " .. JG_SO_NICK .. "  · Nhóm/nick: " .. JG_SL_SA .. "\n"
            .. "· Nghỉ: " .. JG_TG_SA .. "s  · Xóa UID: " .. (BAT_XOA_UID_NHOM == 1 and "bật" or "tắt") .. "\n"
            .. "· Danh sách: " .. soUIDCon .. " UID  · File: " .. filename

        local choice = dialogChoice(title,
            "📋 Dán list UID nhóm", "👁️ Xem danh sách nhóm", "🗑️ Xóa tất cả UID nhóm",
            "──────────────",
            "🗑️ Bật/Tắt xóa UID khi chạy", "🚩 Nick bắt đầu: " .. NICK_BAT_DAU,
            "👥 Đổi số nick cần chạy", "🔢 Đổi số nhóm mỗi nick",
            "⏳ Đổi thời gian nghỉ", "📂 Đổi đường dẫn file",
            "──────────────", "📜 Xem Log tham gia", "🧹 Xóa Log tham gia",
            "──────────────", "🚀 BẮT ĐẦU THAM GIA", "◀️ Quay lại"
        )

        if not choice or choice:find("Quay lại") then return "back"
        elseif choice:find("Dán list UID") then
            local clip = getClipboard() or ""
            if clip == "" then toast("⚠️ Clipboard trống!")
            else
                local lines = {}
                for line in string.gmatch(clip, "[^\r\n]+") do
                    local uid = line:match("^%s*(.-)%s*$")
                    if uid ~= "" then table.insert(lines, uid) end
                end
                if #lines > 0 then
                    local confirm = dialogChoice("📋 PHÁT HIỆN " .. #lines .. " UID NHÓM\n\nThêm toàn bộ?", "✅ Có, thêm ngay!", "◀️ Hủy")
                    if confirm and confirm:find("thêm ngay") then
                        local f = io.open(GROUP_UID_FILE, "a")
                        if f then
                            for _, uid in ipairs(lines) do f:write(uid .. "\n") end
                            f:close()
                            toast("✅ Đã thêm " .. #lines .. " UID!")
                        end
                    end
                else toast("⚠️ Không tìm thấy UID hợp lệ!") end
            end
        elseif choice:find("Xem danh sách") then
            local allLines = {}
            local f = io.open(GROUP_UID_FILE, "r")
            if f then for line in f:lines() do if line ~= "" then table.insert(allLines, line) end end f:close() end
            if #allLines == 0 then dialogChoice("📂 FILE UID\n\n📭 File rỗng!", "OK ✅")
            else
                local page = 1 local pageSize = 50
                while true do
                    local startIdx = (page - 1) * pageSize + 1
                    local endIdx = math.min(page * pageSize, #allLines)
                    local displayLines = {} for i = startIdx, endIdx do table.insert(displayLines, i .. ". " .. allLines[i]) end
                    local preview = table.concat(displayLines, "\n")
                    local totalPage = math.ceil(#allLines / pageSize)
                    local buttons = {"OK ✅"} if page < totalPage then table.insert(buttons, "Trang tiếp ➡️") end if page > 1 then table.insert(buttons, "⬅️ Trang trước") end
                    local c = dialogChoice("📂 DANH SÁCH NHÓM\n📄 Trang: " .. page .. "/" .. totalPage .. "\n📊 Tổng: " .. #allLines .. " UID\n────────────────\n" .. preview, unpack(buttons))
                    if not c or c:find("OK") then break elseif c:find("Trang tiếp") then page = page + 1 elseif c:find("Trang trước") then page = page - 1 end
                end
            end
        elseif choice:find("Xóa tất cả UID") then
            local confirm = dialogChoice("🗑️ XÓA TẤT CẢ UID NHÓM?\n\nHành động này không thể hoàn tác.", "🗑️ Xóa hết!", "◀️ Hủy")
            if confirm and confirm:find("Xóa hết") then
                local f = io.open(GROUP_UID_FILE, "w") if f then f:close() toast("✅ Đã xóa!") end
            end
        elseif choice:find("Bật/Tắt xóa UID") then BAT_XOA_UID_NHOM = (BAT_XOA_UID_NHOM == 1) and 0 or 1
        elseif choice:find("Nick bắt đầu") then
            local input = dialogInput("Nick bắt đầu", "STT (Bắt đầu từ 1):", tostring(NICK_BAT_DAU))
            if input and tonumber(input) then NICK_BAT_DAU = math.max(1, math.floor(tonumber(input))) end
        elseif choice:find("Đổi số nick") then
            local input = dialogInput("Số nick chạy", "Nhập số lượng:", tostring(JG_SO_NICK))
            if input and tonumber(input) then JG_SO_NICK = math.floor(tonumber(input)) end
        elseif choice:find("Đổi số nhóm") then
            local input = dialogInput("Số nhóm mỗi nick", "Nhập số lượng:", tostring(JG_SL_SA))
            if input and tonumber(input) then JG_SL_SA = math.floor(tonumber(input)) end
        elseif choice:find("Đổi thời gian") then
            local input = dialogInput("Thời gian nghỉ", "Nhập số giây:", tostring(JG_TG_SA))
            if input and tonumber(input) then JG_TG_SA = math.floor(tonumber(input)) end
        elseif choice:find("Đổi đường dẫn") then
            local input = dialogInput("Đường dẫn file", "Nhập đường dẫn:", GROUP_UID_FILE)
            if input and input ~= "" then GROUP_UID_FILE = input end
        elseif choice:find("Xem Log") then
            local f = io.open(GROUP_LOG_FILE, "r")
            if not f then dialogChoice("📜 LOG\n\n❌ Chưa có log!", "OK ✅")
            else
                local lines = {} for line in f:lines() do table.insert(lines, line) if #lines > 100 then table.remove(lines, 1) end end f:close()
                dialogChoice("📜 LOG THAM GIA NHÓM (100 dòng mới nhất)\n\n" .. table.concat(lines, "\n"), "OK ✅")
            end
        elseif choice:find("Xóa Log") then
            local f = io.open(GROUP_LOG_FILE, "w") if f then f:close() toast("✅ Đã xóa log!") end
        elseif choice:find("BẮT ĐẦU THAM GIA") then
            if soUIDCon == 0 then toast("⚠️ Danh sách rỗng!")
            else
                luuCauHinh()
                return "join_group"
            end
        end
    end
end

-- ========== THỰC HIỆN THAM GIA NHÓM ==========
function thucHienJoinGroup(mode)
    logScreen("🚀 BẮT ĐẦU THAM GIA NHÓM UID (" .. (mode or "Standalone") .. ")", true)

    -- Lấy thông số theo mode
    local soNhomMoiNick = JG_SL_SA
    local delayJoin = JG_TG_SA

    if mode == "LH" then
        soNhomMoiNick = JG_SL_LH
        delayJoin = JG_TG_LH
    end

    local ALL_GROUPS = {}
    local f = io.open(GROUP_UID_FILE, "r")
    if f then
        for line in f:lines() do
            local u = line:match("^%s*(.-)%s*$")
            if u and u ~= "" then table.insert(ALL_GROUPS, u) end
        end
        f:close()
    end

    local currentIdx = 1
    local danhSachNick = layDanhSachCrane()

    local totalNicks = JG_SO_NICK
    if _G.DANG_CHAY_LIEN_HOAN then totalNicks = 1 end

    for nickIndex = 1, totalNicks do
        local offset = (NICK_BAT_DAU > 0) and (NICK_BAT_DAU - 1) or 0
        local idx_in_list = ((nickIndex - 1 + offset) % #danhSachNick) + 1
        local tenPhanVung = (#danhSachNick > 0) and danhSachNick[idx_in_list] or "Default"

        log("")
        logScreen("👤 NICK " .. nickIndex .. "/" .. totalNicks .. " | 📂 " .. tenPhanVung, true)

        if currentIdx > #ALL_GROUPS then
            log("⚠️ Đã hết danh sách UID nhóm!")
            break
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            _G.DA_CHECK_LOGIN = false -- Chỉ reset khi chạy đơn lẻ
        end

        if not _G.DANG_CHAY_LIEN_HOAN then
            resetMang()
            chuyenNick(tenPhanVung)
        end

        if not moFacebook() then
            log("⚠️ Loi mo Facebook hoac Nick bi out, bo qua nick nay")
            if _G.DANG_CHAY_LIEN_HOAN then _G.CO_LOI_SOMETHING = true end
            goto tiep_tuc_nick
        else
            nghi(10, "Đợi Facebook ổn định")

            for gIndex = 1, soNhomMoiNick do
                if currentIdx > #ALL_GROUPS then break end

                local uidNhom = ALL_GROUPS[currentIdx]
                currentIdx = currentIdx + 1

                if BAT_XOA_UID_NHOM == 1 then layUIDNhomVaXoa() end

                log("")
                log("👉 Nhóm " .. gIndex .. "/" .. soNhomMoiNick .. ": " .. uidNhom)
                logScreen("🌐 Nhóm " .. gIndex .. "/" .. soNhomMoiNick .. " | UID: " .. uidNhom, true)

                openURL("https://www.facebook.com/groups/" .. uidNhom)
                sleep(5)

                local daXuLy = false
                local batDau = os.time()

                while os.time() - batDau < 15 and not daXuLy do
                    if findText("Joined", 1) then
                        logScreen("⚠️ Đã tham gia nhóm này rồi", true)
                        ghiLogJoinGroup("UID " .. uidNhom .. " | Da tham gia")
                        daXuLy = true
                        break
                    end

                    if findText("Cancel Request", 1) then
                        logScreen("⏳ Đang chờ duyệt", true)
                        ghiLogJoinGroup("UID " .. uidNhom .. " | Dang cho duyet")
                        daXuLy = true
                        break
                    end

                    if findText("Join Group", 1) or findText("Join", 1) then
                        local btnText = findText("Join Group", 1) and "Join Group" or "Join"
                        tapText(btnText, 2, 1)
                        logScreen("✅ Đã tap " .. btnText, true)
                        sleep(2)

                        -- Xử lý câu hỏi
                        if findText("Write your answer", 2) or findText("Write an answer", 2) then
                            logScreen("📝 Đang trả lời câu hỏi nhóm...", true)
                            traLoiCauHoiNhom()
                        end

                        ghiLogJoinGroup("UID " .. uidNhom .. " | Thanh cong")
                        daXuLy = true
                        break
                    end
                    sleep(1)
                end

                if not daXuLy then
                    log("❌ Không tìm thấy nút Join cho nhóm " .. uidNhom)
                    ghiLogJoinGroup("UID " .. uidNhom .. " | That bai")
                end

                if gIndex < soNhomMoiNick and currentIdx <= #ALL_GROUPS then
                    nghi(delayJoin, "Nghỉ giữa các nhóm")
                end
            end
        end

        ::tiep_tuc_nick::
        if not _G.DANG_CHAY_LIEN_HOAN then
            dongFacebook()
            if nickIndex < totalNicks then
                nghi(5, "Nghỉ đổi nick")
            end
        end
    end

    logScreen("✅ HOÀN TẤT THAM GIA NHÓM", true)
end

print("✅ join_group.lua đã nạp")