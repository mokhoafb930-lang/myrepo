-- ================================================================
-- FILE: crane.lua - ĐIỀU KHIỂN CRANE
-- Nguồn: fb_auto_new.lua dòng 31-56, 298-337
-- ================================================================

-- ========== CẤU HÌNH CRANE (TỰ ĐỘNG) ========== (dòng 31-39)
function getCranePath()
    local paths = {"/usr/bin/cranectl", "/var/jb/usr/bin/cranectl", "/usr/local/bin/cranectl"}
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then f:close() return p end
    end
    return "cranectl"
end
CRANE_PATH = getCranePath()

-- ========== HÀM SẮP XẾP ƯU TIÊN DEFAULT ==========
function naturalSortCrane(a, b)
    local lowA, lowB = a:lower(), b:lower()
    if lowA == "default" then return true end
    if lowB == "default" then return false end

    local function padDigits(s) 
        return s:gsub("(%d+)", function(n) return string.format("%010d", tonumber(n)) end) 
    end
    return padDigits(lowA) < padDigits(lowB)
end

-- (dòng 41-56)
function layDanhSachCrane()
    local tmpFile = "/var/mobile/Documents/crane_list_auto.txt"
    os.execute(string.format("%s --list com.facebook.Facebook > %s 2>&1", CRANE_PATH, tmpFile))
    local list = {}
    local f = io.open(tmpFile, "r")
    if f then
        for line in f:lines() do
            local name = line:match("^%s*%*?%s*(.-)%s*%(") or line:match("^%s*%*?%s*(.-)%s*$")
            if name and name ~= "" and not name:find("Container") and not name:find(":") and not name:find("Active") then
                table.insert(list, (name:gsub("^%s*(.-)%s*$", "%1")))
            end
        end
        f:close()
    end
    -- Sắp xếp để Default luôn lên đầu, sau đó mới đến các số/chữ khác
    table.sort(list, naturalSortCrane)
    return list
end

-- ========== CHUYỂN NICK (SMART CRANE) ========== (dòng 301-337)
function chuyenNick(tenPhanVung)
    local danhSach = layDanhSachCrane()
    if #danhSach == 0 then
        logScreen("❌ KHÔNG CÓ PHÂN VÙNG CRANE!", true)
        return false
    end

    local target = tenPhanVung
    if not target then
        local f = io.open(CRANE_IDX_FILE, "r")
        local idx = 1
        if f then
            idx = tonumber(f:read("*all")) or 1
            f:close()
        end

        target = danhSach[((idx - 1) % #danhSach) + 1]

        local f2 = io.open(CRANE_IDX_FILE, "w")
        if f2 then
            f2:write(tostring(idx + 1))
            f2:close()
        end
    end

    logScreen("🔄 Crane: " .. target, true)
    local cmd = string.format("%s --switch com.facebook.Facebook name:\"%s\"", CRANE_PATH, target)
    os.execute(cmd)
    for i = 5, 1, -1 do
        logScreen("🔄 Đợi thiết bị Crane ổn định... " .. i .. "s", true)
        sleep(1)
    end
    return true
end

-- ========== LẤY TÊN PHÂN VÙNG ĐANG ACTIVE ==========
function layPhanVungHienTai()
    local tmpFile = "/var/mobile/Documents/crane_active.txt"
    os.execute(string.format("%s --list com.facebook.Facebook > %s 2>&1", CRANE_PATH, tmpFile))
    local activeName = nil
    local f = io.open(tmpFile, "r")
    if f then
        for line in f:lines() do
            if line:find("^%s*%*") then -- Tìm dòng có dấu * (Active)
                activeName = line:match("^%s*%*%s*(.-)%s*%(") or line:match("^%s*%*%s*(.-)%s*$")
                if activeName then 
                    activeName = activeName:gsub("^%s*(.-)%s*$", "%1")
                    break 
                end
            end
        end
        f:close()
    end
    return activeName
end

print("✅ crane.lua đã nạp")