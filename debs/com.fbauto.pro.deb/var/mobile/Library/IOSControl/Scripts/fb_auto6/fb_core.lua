-- ================================================================
-- FILE: fb_core.lua - MỞ/ĐÓNG FACEBOOK
-- Nguồn: fb_auto_new.lua dòng 339-384
-- ================================================================

-- ========== ĐÓNG FACEBOOK ==========
function dongFacebook()
    appKill("com.facebook.Facebook")
    sleep(3)
end

-- ========== MỞ FACEBOOK ==========
function moFacebook()
    logScreen("📱 Đang mở Facebook...", true)
    appRun("com.facebook.Facebook")
    nghi(10, "Đang đợi Facebook khởi động")

    -- BƯỚC 1 & 2: CHỈ KIỂM TRA LẦN ĐẦU CHO MỖI NICK
    -- CHỈ KIỂM TRA LẦN ĐẦU CHO MỖI NICK
    if not _G.DA_CHECK_LOGIN then
        -- BƯỚC 1: KIỂM TRA CHƯA ĐĂNG NHẬP
        if findText("Create new account", 5) then
            logScreen("⚠️ PHÁT HIỆN CHƯA CÓ NICK ĐĂNG NHẬP!", true)
            dongFacebook()
            return false
        end

        -- BƯỚC 2: KIỂM TRA NICK OUT
        local xOut, yOut = findImage("crop_1777996534001.png", 1, 0.85)
        if xOut and xOut >= 0 then
            logScreen("⚠️ PHÁT HIỆN NICK BỊ OUT, ĐANG NHẤN VÀO LẠI...", true)
            tap(183, 285)
            sleep(5)
        end

        -- BƯỚC 3: XỬ LÝ CÁC POPUP (OK, Continue...)
        if findText("OK", 2) then
            tapText("OK", 5)
            sleep(2)
        end

        swipe(200, 200, 200, 600, 0.5)
        sleep(3)

        local errorKeywords = {"Something Went Wrong", "Stories couldn't load", "Try Again"}
        for _, keyword in ipairs(errorKeywords) do
            if findText(keyword, 2) then
                logScreen("❌ LỖI FACEBOOK: " .. keyword, true)
                dongFacebook()
                return false
            end
        end

        if findText("Menu", 2) or findText("Search", 2) or findImage("crop_1776574976548.png", 1, 0.8) then
            logScreen("✅ FACEBOOK ĐÃ SẴN SÀNG", true)
            _G.DA_CHECK_LOGIN = true -- Ghi nhớ đã đăng nhập thành công cho Nick này
            return true
        else
            logScreen("❌ KHÔNG VÀO ĐƯỢC NEWSFEED, BỎ QUA...", true)
            dongFacebook()
            return false
        end
    else
        logScreen("⚡ Nick đã verify, vào nhanh tác vụ...", true)
        return true
    end
end

print("✅ fb_core.lua đã cập nhật bản logic ổn định")