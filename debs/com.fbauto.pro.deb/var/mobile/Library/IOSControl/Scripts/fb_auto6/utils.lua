-- ================================================================
-- FILE: utils.lua - CÁC HÀM TIỆN ÍCH
-- Nguồn: fb_auto_new.lua dòng 11-296, 1993-2057
-- ================================================================

-- Tương thích Lua 5.1 / 5.3+ (dòng 11-13)
unpack = unpack or table.unpack
math.randomseed(os.time())

-- ========== HÀM HIỂN THỊ LOG LÊN MÀN HÌNH ========== (dòng 15-23)
function logScreen(msg, quanTrong)
    if quanTrong then
        toast(msg, 2, 0, 0, 7)
        log("📢 [Screen] " .. msg)
    else
        log("🔹 " .. msg)
    end
end

-- ========== HÀM NGHỈ CÓ THÔNG BÁO (ĐẾM NGƯỢC) ========== (dòng 231-246)
function nghi(giay, tinNhan)
    log("⏳ " .. tinNhan .. " (" .. giay .. "s)")
    if giay <= 3 then
        logScreen("⏳ " .. tinNhan .. " (" .. giay .. "s)", true)
        sleep(giay)
    else
        for i = giay, 1, -1 do
            if i == giay or i % 5 == 0 or i <= 3 then
                logScreen("⏳ " .. tinNhan .. " (" .. i .. "s)", true)
            end
            sleep(1)
        end
    end
end

-- ========== HÀM LẤY IP HIỆN TẠI ========== (dòng 248-258)
function getIP()
    local success, content = pcall(function()
        return httpGet("http://api.ipify.org")
    end)
    if success and content then
        return content:match("^%s*(.-)%s*$")
    end
    return "Không xác định"
end

-- ========== RESET MẠNG ========== (dòng 262-296)
function resetMang()
    if _G.DANG_CHAY_LIEN_HOAN and _G.DA_RESET_MANG then
        log("🔄 Đã reset mạng cho nick này trước đó, bỏ qua.")
        return
    end
    _G.DA_RESET_MANG = true
    while true do
        log("📡 Đang thực hiện Reset mạng (Cú pháp: true, 3)...")
        setAirplaneMode(true, 3)

        nghi(12, "ĐANG ĐỢI MẠNG HỒI PHỤC")

        local newIP = "Không xác định"
        for retry = 1, 6 do
            newIP = getIP()
            if newIP ~= "Không xác định" then break end
            logScreen("⏳ Đang chờ lấy IP mới (" .. (retry*5) .. "s)...", true)
            sleep(5)
        end

        if newIP ~= "Không xác định" then
            logScreen("✅ ĐỔI IP THÀNH CÔNG\n📡 IP Mới: " .. newIP, true)
            log("✅ IP mới: " .. newIP)
            sleep(2)
            break
        else
            logScreen("❌ KHÔNG LẤY ĐƯỢC IP, ĐANG RESET LẠI...", true)
            log("❌ Khong lay duoc IP, tien hanh reset mang lai tu dau...")
            sleep(2)
        end
    end
end

-- ========== KIỂM TRA ĐIỀU KHOẢN SỬ DỤNG ========== (dòng 184-217)
function kiemTraDieuKhoan()
    local termsFile = "/var/mobile/Documents/fb_terms_accepted.txt"
    local f = io.open(termsFile, "r")
    if f then
        f:close()
        return true 
    end

    local msg = "📜 CHÍNH SÁCH & QUY ĐỊNH SỬ DỤNG\n"
        .. "──────────────────────\n"
        .. "1. TRÁCH NHIỆM NGƯỜI DÙNG:\n"
        .. "· Người dùng chịu hoàn toàn trách nhiệm pháp lý về mọi hành vi, nội dung, thao tác khi sử dụng.\n"
        .. "· Script chỉ chạy theo LỆNH từ nội dung và thông số do người dùng nhập.\n\n"
        .. "2. MỤC ĐÍCH SỬ DỤNG:\n"
        .. "· Chỉ sử dụng cho mục đích: SEO, PR, MKT, kiểm thử ứng dụng... hợp pháp.\n"
        .. "· NGHIÊM CẤM: Phát tán mã độc, gian lận, lừa đảo, tấn công mạng, seeding vi phạm pháp luật.\n\n"
        .. "3. PHÁP LÝ & HỖ TRỢ:\n"
        .. "· Người dùng tự chịu trách nhiệm trước pháp luật khi cơ quan chức năng yêu cầu.\n"
        .. "· ADMIN có quyền TỐ GIÁC, hỗ trợ truy vết cùng cơ quan chức năng nếu người dùng PHẠM PHÁP.\n\n"
        .. "⚠️ Bằng cách ấn 'ĐỒNG Ý', bạn xác nhận đã đọc và chấp nhận toàn bộ điều khoản trên để vào Tool."

    local choice = dialogChoice(msg, "ĐỒNG Ý & VÀO TOOL ✅", "THOÁT ❌")
    if choice == "ĐỒNG Ý & VÀO TOOL ✅" then
        local fw = io.open(termsFile, "w")
        if fw then
            fw:write("accepted_at=" .. os.date("%Y-%m-%d %H:%M:%S"))
            fw:close()
        end
        return true
    else
        toast("Bạn cần chấp nhận điều khoản để sử dụng!")
        stop()
    end
end

-- ============================================
-- HỆ THỐNG QUẢN LÝ KEY ONLINE (SERVER API)
-- ============================================ (dòng 1993-2057)
API_URL = "https://script.google.com/macros/s/AKfycbwPxSXMEwL5MnuIxi1y_INFNtBcfGb_QI69nzucAgh5gNxTeTruQxeWNy0UFfRQ4S9dsw/exec"

function kiemTraMaMayOnline()
    local deviceID = "UNKNOWN"
    if getSN then deviceID = getSN() end

    local url = API_URL .. "?action=check&device_id=" .. deviceID

    local ok, r = pcall(function() return httpGet(url) end)
    if not ok or not r then return false, "Lỗi kết nối máy chủ quản lý Key!" end

    local response = ""
    if type(r) == "table" then response = r.body or r.data or r[1] or ""
    elseif type(r) == "string" then response = r end

    local status, message = response:match("^([^|]+)|(.*)$")
    if status == "OK" then
        return true, tonumber(message)
    else
        return false, message or "Lỗi từ máy chủ không xác định!" end
end

function xacThucKey()
    local deviceID = "UNKNOWN"
    if getSN then deviceID = getSN() end

    toast("🔄 Đang kiểm tra bản quyền...")
    local ok, msgOrTime = kiemTraMaMayOnline()

    if ok then
        local expDateStr = os.date("%d/%m/%Y %H:%M:%S", msgOrTime)
        _G.EXP_TIMESTAMP = msgOrTime
        toast("✅ BẢN QUYỀN HỢP LỆ\n⏳ HSD: " .. expDateStr, 3)
        return true
    end

    log("------------------------------------------")
    log("❌ LỖI BẢN QUYỀN: " .. tostring(msgOrTime))
    log("🆔 MÃ MÁY: " .. deviceID)
    log("------------------------------------------")

    local msg = "MÁY CHƯA ĐƯỢC KÍCH HOẠT!\n\n" ..
                "Mã máy: " .. deviceID .. "\n" ..
                "Lý do: " .. tostring(msgOrTime) .. "\n\n" ..
                "Hãy gửi mã trên cho Admin để kích hoạt."

    dialogInput("❌ CHƯA KÍCH HOẠT", msg, deviceID)

    if clipText then clipText(deviceID) elseif copyText then copyText(deviceID) end
    toast("📋 Đã copy Mã Máy vào bộ nhớ tạm!")
    return false
end

print("✅ utils.lua đã nạp")